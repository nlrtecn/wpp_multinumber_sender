document.addEventListener('DOMContentLoaded', () => {
    const socket = io();

    // Elementos do Formulário de Mensagem
    const clientSelect = document.getElementById('client-select');
    const numberInput = document.getElementById('number-input');
    const messageInput = document.getElementById('message-input');
    const sendMessageForm = document.getElementById('send-message-form');
    const sendMessageStatusDiv = document.getElementById('send-message-status');
    const contactSelect = document.getElementById('contact-select');
    const messageSelect = document.getElementById('message-select'); // Dropdown de mensagens

    // Elementos para o Card de QR Code Individual
    const qrClientSelect = document.getElementById('qr-client-select');
    const qrDisplayCard = document.getElementById('qr-display-card');

    // Armazena o estado completo de todos os clientes no front-end
    const clientsState = {}; 
    let currentSelectedQrClientId = null;

    // --- BASE DE DADOS FICTÍCIA DE CONTATOS ---
    const contacts = [
        { nome: 'Ana Silva', telefone: '5511912345678' },
        { nome: 'Bruno Costa', telefone: '5521923456789' },
        { nome: 'Carla Dias', telefone: '5531934567890' },
        { nome: 'Daniel Souza', telefone: '5541945678901' },
        { nome: 'Eduarda Lima', telefone: '5547956789012' },
        { nome: 'Fernando Santos', telefone: '5561967890123' },
        { nome: 'Giovana Pereira', telefone: '5571978901234' },
        { nome: 'Hugo Martins', telefone: '5581989012345' },
        { nome: 'Isabela Rocha', telefone: '5591990123456' },
        { nome: 'João Oliveira', telefone: '5585912345670' }
    ];

    // --- BASE DE DADOS FICTÍCIA DE MENSAGENS (COM CAMPO 'props' VAZIO) ---
    const messages = [
        { 
            id: 'saudacao_nova_compra', 
            mensagem: `Olá! 👋 Agradecemos sua recente compra conosco.
Sua satisfação é nossa prioridade.
Qualquer dúvida ou feedback, estamos à disposição.
Tenha um ótimo dia! ✨`,
            props: '' // Campo props adicionado
        },
        { 
            id: 'lembrete_pagamento', 
            mensagem: `🔔 Lembrete de pagamento: Sua fatura no valor de R$XX,XX vence em DD/MM.
Evite multas e juros.
Acesse nosso portal para mais detalhes ou entre em contato.
Obrigado! 🙏`,
            props: '' // Campo props adicionado
        },
        { 
            id: 'confirmacao_agendamento', 
            mensagem: `✅ Confirmação de agendamento:
Seu horário com [Nome do Profissional] foi marcado para DD/MM às HH:MM.
Pedimos que chegue com 10 minutos de antecedência.
Até breve! 🗓️`,
            props: '' // Campo props adicionado
        },
        { 
            id: 'oferta_especial', 
            mensagem: `🎉 Nova oferta exclusiva para você!
Use o código *DESCONTO20* e ganhe 20% OFF em sua próxima compra.
Válido até DD/MM. Não perca! 🎁
Acesse: [Link da Loja]`,
            props: '' // Campo props adicionado
        },
        { 
            id: 'suporte_tecnico', 
            mensagem: `🛠️ Olá! Recebemos sua solicitação de suporte.
Nosso time técnico está analisando seu caso (#ABC123).
Em breve entraremos em contato com uma solução.
Agradecemos a paciência! 🧑‍💻`,
            props: '' // Campo props adicionado
        },
        { 
            id: 'pesquisa_satisfacao', 
            mensagem: `Queremos ouvir você! 🗣️
Sua opinião é muito importante para melhorarmos nossos serviços.
Responda nossa breve pesquisa de satisfação:
[Link da Pesquisa]
Muito obrigado! 🙏`,
            props: '' // Campo props adicionado
        },
        { 
            id: 'boas_vindas_plataforma', 
            mensagem: `Bem-vindo(a) à nossa plataforma! 🚀
Estamos felizes em tê-lo(a) conosco.
Explore todas as funcionalidades e descubra como podemos te ajudar.
Se precisar de algo, é só chamar! 💡`,
            props: '' // Campo props adicionado
        },
        { 
            id: 'avisos_manutencao', 
            mensagem: `⚠️ Aviso Importante:
Informamos que haverá uma manutenção programada em nossos sistemas na data DD/MM, das HH:MM às HH:MM.
Durante este período, alguns serviços podem estar indisponíveis.
Agradecemos a compreensão. 🔧`,
            props: '' // Campo props adicionado
        },
        { 
            id: 'feliz_aniversario', 
            mensagem: `🥳 Feliz Aniversário, [Nome do Cliente]!
Que seu dia seja repleto de alegria e realizações.
Para celebrar, temos um presente especial para você: use o código *ANIVERSARIO10* para 10% de desconto! 🎂`,
            props: '' // Campo props adicionado
        },
        { 
            id: 'pedido_entregue', 
            mensagem: `📦 Seu pedido (#XYZ987) foi entregue com sucesso!
Esperamos que você aproveite seus novos itens.
Deixe sua avaliação e nos ajude a crescer! ⭐⭐⭐⭐⭐
Qualquer problema, estamos aqui!`,
            props: '' // Campo props adicionado
        }
    ];


    // Função para popular o dropdown de contatos
    function populateContactsDropdown() {
        contactSelect.innerHTML = '<option value="">Selecione um contato</option>'; // Opção padrão
        contacts.forEach(contact => {
            const option = document.createElement('option');
            option.value = contact.telefone;
            option.textContent = `${contact.nome} (${contact.telefone})`;
            contactSelect.appendChild(option);
        });
    }

    // Chamada inicial para popular o dropdown de contatos
    populateContactsDropdown();

    // Listener para o dropdown de contatos
    contactSelect.addEventListener('change', (event) => {
        numberInput.value = event.target.value; // Preenche o campo de número com o telefone selecionado
    });

    // Função para popular o dropdown de mensagens
    function populateMessagesDropdown() {
        messageSelect.innerHTML = '<option value="">Selecione uma mensagem</option>'; // Opção padrão
        messages.forEach(msg => {
            const option = document.createElement('option');
            option.value = msg.mensagem; // O valor da opção será o texto completo da mensagem
            // Para exibição no dropdown, podemos usar um resumo ou o ID
            option.textContent = msg.id.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase()); // Ex: "Saudacao Nova Compra"
            messageSelect.appendChild(option);
        });
    }

    // Chamada inicial para popular o dropdown de mensagens
    populateMessagesDropdown();

    // Listener para o dropdown de mensagens
    messageSelect.addEventListener('change', (event) => {
        messageInput.value = event.target.value; // Preenche o campo de mensagem com o texto selecionado
    });


    /**
     * Atualiza o card de exibição do QR Code/Status.
     * @param {object} clientInfo Informações do cliente a serem exibidas.
     */
    function updateQrDisplayCard(clientInfo) {
        if (!clientInfo) {
            qrDisplayCard.innerHTML = '<p>Selecione um cliente acima para ver seu status e QR Code.</p>';
            return;
        }

        const showAuthButton = ['QR_CODE', 'Desconectado', 'Falha na Autenticação', 'Erro de Inicialização', 'Erro ao Reautenticar', 'Erro de Comunicação'].includes(clientInfo.status);
        const buttonText = clientInfo.status === 'QR_CODE' ? 'Autenticar' : 'Reautenticar';

        qrDisplayCard.innerHTML = `
            <h3>Cliente ${clientInfo.id} (${clientInfo.name})</h3>
            <p>Status: <span class="status-${clientInfo.status.toLowerCase().replace(/ /g, '-')}">${clientInfo.status}</span></p>
            <p>Sessão: <code>${clientInfo.sessionDir || 'N/A'}</code></p>
            <div class="qr-code-area">
                ${clientInfo.status === 'QR_CODE' && clientInfo.qr
                    ? `<img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(clientInfo.qr)}" alt="QR Code para Cliente ${clientInfo.id}">`
                    : (clientInfo.status === 'QR_CODE' && !clientInfo.qr
                        ? '<p>Aguardando QR Code...</p>'
                        : ''
                    )
                }
            </div>
            ${showAuthButton 
                ? `<button class="auth-button" data-client-id="${clientInfo.id}">${buttonText}</button>`
                : ''
            }
        `;

        // Adiciona o event listener ao botão de autenticação/reautenticação no card único
        if (showAuthButton) {
            const authButton = qrDisplayCard.querySelector('.auth-button');
            if (authButton) {
                authButton.addEventListener('click', () => {
                    handleReauthenticate(clientInfo.id);
                });
            }
        }
    }

    /**
     * Lida com o clique no botão de reautenticação.
     * @param {number} clientId O ID do cliente a ser reautenticado.
     */
    async function handleReauthenticate(clientId) {
        const currentClientInfo = clientsState[clientId];
        if (currentClientInfo) {
            updateQrDisplayCard({ ...currentClientInfo, status: 'Reautenticando', qr: null });
        }

        try {
            const response = await fetch('/api/reauthenticate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ clientId: clientId }),
            });

            const result = await response.json();

            if (result.success) {
                console.log(result.message);
            } else {
                console.error(`Erro ao reautenticar cliente ${clientId}:`, result.message);
                if (currentClientInfo) {
                    updateQrDisplayCard({ ...currentClientInfo, status: 'Erro ao Reautenticar', qr: null });
                }
                alert(`Erro ao reautenticar Cliente ${clientId}: ${result.message}`);
            }
        } catch (error) {
            console.error(`Erro na requisição de reautenticação para o cliente ${clientId}:`, error);
            if (currentClientInfo) {
                updateQrDisplayCard({ ...currentClientInfo, status: 'Erro de Comunicação', qr: null });
            }
            alert(`Erro de comunicação ao tentar reautenticar Cliente ${clientId}. Verifique o console do navegador e do servidor.`);
        }
    }

    // --- Socket.IO Event Listeners ---

    // Recebe o status inicial de todos os clientes ao conectar
    socket.on('initialClientStatus', (initialData) => {
        qrClientSelect.innerHTML = '<option value="">Selecione um cliente</option>';
        clientSelect.innerHTML = '<option value="">Selecione um cliente pronto</option>';
        
        initialData.forEach(clientInfo => {
            clientsState[clientInfo.id] = clientInfo;
            
            const qrOption = document.createElement('option');
            qrOption.value = clientInfo.id;
            qrOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name}) - [${clientInfo.status}]`;
            qrClientSelect.appendChild(qrOption);

            const sendOption = document.createElement('option');
            sendOption.value = clientInfo.id;
            sendOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name})`;
            sendOption.disabled = (clientInfo.status !== 'Pronto');
            clientSelect.appendChild(sendOption);
        });

        if (initialData.length > 0) {
            currentSelectedQrClientId = initialData[0].id;
            qrClientSelect.value = currentSelectedQrClientId;
            updateQrDisplayCard(clientsState[currentSelectedQrClientId]);
        } else {
            updateQrDisplayCard(null);
        }
    });

    // Recebe atualizações de status de clientes individuais
    socket.on('clientStatusUpdate', (updatedClientInfo) => {
        clientsState[updatedClientInfo.id] = updatedClientInfo;

        let qrOption = qrClientSelect.querySelector(`option[value="${updatedClientInfo.id}"]`);
        if (!qrOption) {
            qrOption = document.createElement('option');
            qrOption.value = updatedClientInfo.id;
            qrClientSelect.appendChild(qrOption);
        }
        qrOption.textContent = `Cliente ${updatedClientInfo.id} (${updatedClientInfo.name}) - [${updatedClientInfo.status}]`;

        let sendOption = clientSelect.querySelector(`option[value="${updatedClientInfo.id}"]`);
        if (!sendOption) {
            sendOption = document.createElement('option');
            sendOption.value = updatedClientInfo.id;
            clientSelect.appendChild(sendOption);
        }
        sendOption.textContent = `Cliente ${updatedClientInfo.id} (${updatedClientInfo.name})`;
        sendOption.disabled = (updatedClientInfo.status !== 'Pronto');

        if (parseInt(currentSelectedQrClientId) === updatedClientInfo.id) {
            updateQrDisplayCard(updatedClientInfo);
        }
    });

    // --- Listener para o Dropdown de Seleção de QR Code ---
    qrClientSelect.addEventListener('change', (event) => {
        const selectedId = parseInt(event.target.value);
        currentSelectedQrClientId = selectedId;
        updateQrDisplayCard(clientsState[selectedId]);
    });

    // --- Formulário de Envio de Mensagem ---
    sendMessageForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        sendMessageStatusDiv.textContent = 'Enviando mensagem...';
        sendMessageStatusDiv.className = 'status-message info';

        const formData = new FormData(sendMessageForm);
        const clientId = formData.get('clientId');
        const number = formData.get('number');
        const message = formData.get('message');

        if (!clientId || !number || !message) {
            sendMessageStatusDiv.textContent = 'Por favor, preencha todos os campos para enviar a mensagem.';
            sendMessageStatusDiv.className = 'status-message error';
            return;
        }

        try {
            const response = await fetch('/api/send-message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ clientId, number, message }),
            });

            const result = await response.json();

            if (result.success) {
                sendMessageStatusDiv.textContent = result.message;
                sendMessageStatusDiv.className = 'status-message success';
                sendMessageForm.reset(); // Limpa o formulário
                contactSelect.value = ""; // Reseta o dropdown de contatos
                messageSelect.value = ""; // Reseta o dropdown de mensagens
            } else {
                sendMessageStatusDiv.textContent = `Erro: ${result.message}`;
                sendMessageStatusDiv.className = 'status-message error';
            }
        } catch (error) {
            console.error('Erro ao enviar mensagem:', error);
            sendMessageStatusDiv.textContent = `Erro ao conectar com o servidor: ${error.message}`;
            sendMessageStatusDiv.className = 'status-message error';
        }
    });

    // Requisição inicial para carregar o status dos clientes
    fetch('/api/clients/status')
        .then(response => response.json())
        .then(data => {
            if (Object.keys(clientsState).length === 0) { 
                qrClientSelect.innerHTML = '<option value="">Selecione um cliente</option>';
                clientSelect.innerHTML = '<option value="">Selecione um cliente pronto</option>';
                data.forEach(clientInfo => {
                    clientsState[clientInfo.id] = clientInfo;
                    
                    const qrOption = document.createElement('option');
                    qrOption.value = clientInfo.id;
                    qrOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name}) - [${clientInfo.status}]`;
                    qrClientSelect.appendChild(qrOption);

                    const sendOption = document.createElement('option');
                    sendOption.value = clientInfo.id;
                    sendOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name})`;
                    sendOption.disabled = (clientInfo.status !== 'Pronto');
                    clientSelect.appendChild(sendOption);
                });

                if (data.length > 0) {
                    currentSelectedQrClientId = data[0].id;
                    qrClientSelect.value = currentSelectedQrClientId;
                    updateQrDisplayCard(clientsState[currentSelectedQrClientId]);
                } else {
                    updateQrDisplayCard(null);
                }
            }
        })
        .catch(error => {
            console.error('Erro ao carregar status inicial dos clientes:', error);
            qrDisplayCard.innerHTML = '<p class="status-message error">Erro ao carregar status dos clientes. Verifique o servidor.</p>';
        });
});