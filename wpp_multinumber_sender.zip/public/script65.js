document.addEventListener('DOMContentLoaded', () => {
    const socket = io();

    const clientsContainer = document.getElementById('clients-container');
    // ... (outras declarações de variáveis e elementos) ...

    let allClients = {}; // Importante para o frontend manter o controle dos clientes exibidos

    // ... (funções utilitárias como appendRoutineLog, updateClientCard, etc.) ...

    // --- Listeners de Eventos Socket.IO ---

    socket.on('initialClientStatus', (clientsArray) => {
        console.log('[SOCKET] initialClientStatus recebido:', clientsArray);
        // PASSO 1: Limpar o container de clientes e o estado interno 'allClients'
        // Isso remove todos os cards existentes antes de redesenhá-los com o estado atual do backend.
        clientsContainer.innerHTML = ''; 
        allClients = {}; 

        // PASSO 2: Iterar sobre a array de clientes recebida e atualizar/criar os cards
        clientsArray.forEach(client => updateClientCard(client));
    });

    socket.on('clientStatusUpdate', (client) => {
        console.log(`[SOCKET] clientStatusUpdate recebido para Cliente: ${client.id} Status: ${client.status}`);
        // PASSO 3: Atualizar um cliente específico quando seu status muda
        updateClientCard(client);
    });

    // ... (outros listeners Socket.IO, como routineLogUpdate, routineStatus, readyClientsForRoutine) ...

    // --- Inicialização ao Carregar a Página ---
    // ... (fetch para /api/get-num-clients e /api/routine/status) ...

    // É CRUCIAL que esta linha esteja aqui para solicitar o estado inicial dos clientes
    // ao backend quando a página carrega.
    socket.emit('requestInitialClientStatus'); 
    socket.emit('requestReadyClients'); // Também importante para o dropdown de clientes
});