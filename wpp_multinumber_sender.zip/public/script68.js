document.addEventListener('DOMContentLoaded', () => {
    const socket = io();

    const clientsContainer = document.getElementById('clients-container');
    const setClientsForm = document.getElementById('set-clients-form');
    const numClientsInput = document.getElementById('numClients');
    
    const contactListInput = document.getElementById('contactList');
    const messageContentsInput = document.getElementById('messageContents');

    const startRoutineBtn = document.getElementById('startRoutineBtn');
    const stopRoutineBtn = document.getElementById('stopRoutineBtn');
    const routineLog = document.getElementById('routineLog');
    const saveLogBtn = document.getElementById('saveLogBtn');
    const routineStatusSpan = document.getElementById('routineStatus');
    const availableClientsSelect = document.getElementById('availableClients');
    const routineProgressBar = document.getElementById('routineProgressBar');
    const routineProgressText = document.getElementById('routineProgressText');
    const minDelayInput = document.getElementById('minDelay');
    const maxDelayInput = document.getElementById('maxDelay');

    let allClients = {};
    let readyClientsForRoutine = [];

    // --- Funções de Utilitário do Frontend ---
    function appendRoutineLog(logEntry) {
        const p = document.createElement('p');
        p.textContent = `[${logEntry.timestamp}] ${logEntry.message}`;
        p.classList.add(`log-${logEntry.type}`);
        routineLog.appendChild(p);
        routineLog.scrollTop = routineLog.scrollHeight;
        console.log(`[FRONTEND LOG] ${logEntry.timestamp} [${logEntry.type.toUpperCase()}] ${logEntry.message}`);
    }

    // AQUI A FUNÇÃO updateClientCard FOI ALTERADA
    function updateClientCard(clientData) { // Agora aceita clientData que inclui a flag isInitialRestore
        console.log(`[FRONTEND] Atualizando card para Cliente ${clientData.id}: Status=${clientData.status}, QR=${clientData.qr ? 'Sim' : 'Não'}, Telefone=${clientData.phoneNumber}, Carga Inicial Restaurada: ${clientData.isInitialRestore}`);

        let clientCard = document.getElementById(`client-card-${clientData.id}`);

        if (clientData.status === 'Removido') {
            if (clientCard) {
                clientCard.remove();
                console.log(`[FRONTEND] Cliente ${clientData.id} removido.`);
            }
            delete allClients[clientData.id];
            updateAvailableClientsForRoutine();
            return;
        }

        if (!clientCard) {
            clientCard = document.createElement('div');
            clientCard.id = `client-card-${clientData.id}`;
            clientCard.classList.add('client-card');
            clientsContainer.appendChild(clientCard);
            console.log(`[FRONTEND] Card Cliente ${clientData.id} criado.`);
        }

        // Atualiza o objeto global allClients para ter o estado mais recente
        allClients[clientData.id] = { ...allClients[clientData.id], ...clientData };

        let qrDisplayHtml = '';
        let currentStatusText = clientData.status; // Começa com o status bruto recebido

        // Lógica para adicionar "(Desatualizado)" ou "(Atualizado)"
        if (clientData.isInitialRestore && clientData.status !== 'Inicializando') {
             // Se é uma restauração inicial e o status não é 'Inicializando', marcamos como desatualizado.
             // Isso cobre 'Pronto', 'QR_CODE', 'Desconectado', etc. que o backend lembrou.
             currentStatusText = `${clientData.status} (Desatualizado)`;
        } else if (!clientData.isInitialRestore && clientData.status !== 'Inicializando' && !clientData.status.includes('(Atualizado)')) {
            // Se NÃO é uma restauração inicial e o status NÃO é 'Inicializando' (ou seja, é um evento real do w-w.js)
            // e ainda não tem o "(Atualizado)", adicionamos.
            currentStatusText = `${clientData.status} (Atualizado)`;
        }
        // Se o status for 'Inicializando' e não for uma carga inicial restaurada, ele apenas exibirá 'Inicializando'.
        // Se for um status de erro ('Erro', 'Falha na Autenticação'), ele exibirá o erro sem sufixo no initialRestore,
        // mas com '(Atualizado)' se for um evento em tempo real.

        // Lógica de exibição do QR Code e Status baseado no status *real* e no QR *atual*
        if (clientData.status === 'QR_CODE' && clientData.qr) {
            qrDisplayHtml = `<img src="${clientData.qr}" alt="QR Code para Cliente ${clientData.id}" style="width: 200px; height: 200px; display: block;">`;
        } else if (clientData.status === 'Pronto') {
            qrDisplayHtml = `<p>Conectado!</p>`;
        } else if (clientData.status === 'Autenticado') {
            qrDisplayHtml = `<p>Autenticado (Aguardando Pronto)...</p>`;
        } else if (clientData.status === 'Desconectado' || clientData.status === 'Falha na Autenticação' || clientData.status === 'Erro' || clientData.status === 'Erro QR') {
            qrDisplayHtml = `<p>${clientData.status}.</p>`;
        } else if (clientData.status === 'Inicializando' && !clientData.qr) {
            qrDisplayHtml = `<p>Inicializando...</p>`;
        } else if (clientData.qr) { // Caso especial: se há QR data, mesmo que o status não seja explicitamente 'QR_CODE'
             qrDisplayHtml = `<img src="${clientData.qr}" alt="QR Code para Cliente ${clientData.id}" style="width: 200px; height: 200px; display: block;">`;
             // Aqui, o currentStatusText já deve estar formatado corretamente por causa da lógica acima
        }

        clientCard.innerHTML = `
            <h3>Cliente ${clientData.id}</h3>
            <p><strong>Nome:</strong> ${clientData.name}</p>
            <p><strong>Status:</strong> <span id="status-${clientData.id}">${currentStatusText}</span></p>
            <p><strong>Telefone:</strong> <span id="phone-${clientData.id}">${clientData.phoneNumber || 'N/A'}</span></p>
            <div class="qr-code-area" id="qr-area-${clientData.id}">
                ${qrDisplayHtml}
            </div>
            <button class="reauthenticate-btn" data-client-id="${clientData.id}" ${clientData.status === 'Pronto' || clientData.status === 'Autenticado' ? '' : 'disabled'}>Reautenticar</button>
        `;

        const reauthenticateBtn = clientCard.querySelector(`.reauthenticate-btn`);
        if (reauthenticateBtn) {
            reauthenticateBtn.onclick = async () => {
                console.log(`[FRONTEND] Botão Reautenticar clicado para Cliente ${clientData.id}`);
                try {
                    const response = await fetch('/api/reauthenticate', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ clientId: clientData.id })
                    });
                    const result = await response.json();
                    if (!result.success) {
                        appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Falha na reautenticação para Cliente ${clientData.id}: ${result.message}`, type: 'error' });
                    }
                } catch (error) {
                    appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao reautenticar Cliente ${clientData.id}: ${error.message}`, type: 'error' });
                }
            };
        }
        updateAvailableClientsForRoutine();
    }


    function updateAvailableClientsForRoutine() {
        console.log('[FRONTEND] Atualizando lista de clientes disponíveis para rotina.');
        availableClientsSelect.innerHTML = '<option value="">Todos os Prontos (Rodízio)</option>';

        readyClientsForRoutine = Object.values(allClients).filter(client =>
            client.status && client.status.includes('Pronto') && client.phoneNumber && client.phoneNumber !== 'N/A' && client.phoneNumber !== 'Erro ao obter Telefone'
        );

        if (readyClientsForRoutine.length === 0) {
            startRoutineBtn.disabled = true;
            stopRoutineBtn.disabled = true;
            console.log('[FRONTEND] Nenhum cliente pronto para rotina, botões desabilitados.');
            return;
        }

        readyClientsForRoutine.forEach(client => {
            const option = document.createElement('option');
            option.value = client.id;
            option.textContent = `Cliente ${client.id} (${client.phoneNumber})`;
            availableClientsSelect.appendChild(option);
        });

        if (!routineStatusSpan.textContent.includes('Ativa')) {
             startRoutineBtn.disabled = false;
        }
    }

    async function saveLogManually() {
        const logContent = routineLog.innerText;
        if (!logContent) {
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: 'Não há conteúdo no log para salvar manualmente.', type: 'warning' });
            return;
        }
        try {
            const response = await fetch('/api/save-routine-log', { 
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ log: logContent })
            });
            const result = await response.json();
            if (result.success) {
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Log salvo manualmente com sucesso como ${result.filename}`, type: 'success' });
            } else {
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro ao salvar log manualmente: ${result.message}`, type: 'error' });
            }
        } catch (error) {
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao salvar log manualmente: ${error.message}`, type: 'error' });
        }
    }

    async function startRoutineHandler() {
        const selectedClientId = availableClientsSelect.value;
        const rawContacts = contactListInput.value.trim();
        const rawMessages = messageContentsInput.value.trim();
        const minDelay = parseInt(minDelayInput.value);
        const maxDelay = parseInt(maxDelayInput.value);

        if (!rawContacts || !rawMessages) {
            alert('Por favor, preencha a lista de contatos e o conteúdo das mensagens.');
            return;
        }
        if (isNaN(minDelay) || isNaN(maxDelay) || minDelay < 0 || maxDelay < minDelay) {
            alert('Por favor, defina um intervalo de atraso válido (Min >= 0, Max >= Min).');
            return;
        }

        const parsedContacts = rawContacts.split('\n')
                                    .map(line => {
                                        const parts = line.split(',');
                                        return {
                                            nome: parts[0] ? parts[0].trim() : '',
                                            numero: parts[1] ? parts[1].trim() : ''
                                        };
                                    })
                                    .filter(contact => contact.numero !== '');

        const parsedMessages = rawMessages.split('\n')
                                     .map(message => message.trim())
                                     .filter(message => message !== '');

        if (parsedContacts.length === 0) {
            alert('A lista de contatos está vazia ou no formato incorreto. Use: Nome,Número');
            return;
        }
        if (parsedMessages.length === 0) {
            alert('A lista de mensagens está vazia.');
            return;
        }

        console.log('[FRONTEND] Enviando requisição de início de rotina para o backend.');
        try {
            const response = await fetch('/api/routine/start', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contacts: parsedContacts,
                    messages: parsedMessages,
                    selectedClientId: selectedClientId || null,
                    minDelay: minDelay * 1000,
                    maxDelay: maxDelay * 1000
                })
            });
            const result = await response.json();
            if (result.success) {
                routineLog.innerHTML = '';
            } else {
                alert(`Erro ao iniciar rotina: ${result.message}`);
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Falha ao iniciar rotina: ${result.message}`, type: 'error' });
            }
        } catch (error) {
            alert(`Erro de rede ao iniciar rotina: ${error.message}`);
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao iniciar rotina: ${error.message}`, type: 'error' });
        }
    }

    async function stopRoutineHandler() {
        console.log('[FRONTEND] Enviando requisição de parada de rotina para o backend.');
        try {
            const response = await fetch('/api/routine/stop', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            });
            const result = await response.json();
            if (!result.success) {
                alert(`Erro ao parar rotina: ${result.message}`);
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Falha ao parar rotina: ${result.message}`, type: 'error' });
            }
        } catch (error) {
            alert(`Erro de rede ao parar rotina: ${error.message}`);
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao parar rotina: ${error.message}`, type: 'error' });
        }
    }

    function updateProgressBar(currentIndex, totalContacts) {
        if (totalContacts === 0) {
            routineProgressBar.style.width = '0%';
            routineProgressText.textContent = '0/0 (0%)';
            return;
        }
        const percentage = (currentIndex / totalContacts) * 100;
        routineProgressBar.style.width = `${percentage}%`;
        routineProgressText.textContent = `${currentIndex}/${totalContacts} (${percentage.toFixed(2)}%)`;
    }

    function handleRoutineStatusUpdate(status) {
        console.log('[FRONTEND] Recebida atualização de status da rotina:', status);
        startRoutineBtn.disabled = status.isRunning;
        stopRoutineBtn.disabled = !status.isRunning;

        routineStatusSpan.textContent = status.isRunning ? 'Ativa' : 'Inativa';
        routineStatusSpan.className = status.isRunning ? 'status-active' : 'status-inactive';

        updateProgressBar(status.currentIndex, status.totalContacts);
    }

    // --- Listeners de Eventos Socket.IO ---
    socket.on('initialClientStatus', (clientsArray) => {
        console.log('[FRONTEND - SOCKET] initialClientStatus recebido:', clientsArray);
        clientsContainer.innerHTML = ''; // Limpa clientes existentes
        allClients = {}; // Limpa o objeto de clientes interno do frontend
        clientsArray.forEach(client => updateClientCard(client)); // A flag isInitialRestore já vem no client
        console.log('[FRONTEND - SOCKET] Clientes iniciais renderizados.');
    });

    socket.on('clientStatusUpdate', (client) => {
        console.log(`[FRONTEND - SOCKET] clientStatusUpdate recebido para Cliente: ${client.id}. Novo Status: ${client.status}`);
        updateClientCard(client); // A flag isInitialRestore já vem no client
    });

    socket.on('routineLogUpdate', (logEntry) => {
        appendRoutineLog(logEntry);
    });

    socket.on('routineStatus', (status) => {
        handleRoutineStatusUpdate(status);
    });

    socket.on('readyClientsForRoutine', (clients) => {
        readyClientsForRoutine = clients;
        updateAvailableClientsForRoutine();
        console.log('[FRONTEND - SOCKET] Lista de clientes prontos para rotina atualizada.');
    });

    // --- Listeners de Eventos do DOM ---
    setClientsForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const newNumClients = parseInt(numClientsInput.value);
        console.log(`[FRONTEND] Botão 'Definir Clientes' clicado. Novo número: ${newNumClients}`);

        if (isNaN(newNumClients) || newNumClients < 1 || newNumClients > 10) {
            alert('Por favor, insira um número válido de clientes entre 1 e 10.');
            return;
        }

        try {
            const response = await fetch('/api/set-num-clients', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ numClients: newNumClients })
            });
            const result = await response.json();
            if (!result.success) {
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Falha ao definir número de clientes: ${result.message}`, type: 'error' });
            }
        } catch (error) {
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao definir número de clientes: ${error.message}`, type: 'error' });
        }
    });

    startRoutineBtn.addEventListener('click', startRoutineHandler);
    stopRoutineBtn.addEventListener('click', stopRoutineHandler);
    saveLogBtn.addEventListener('click', saveLogManually); 

    // --- Inicialização ao Carregar a Página ---
    fetch('/api/get-num-clients')
        .then(response => response.json())
        .then(data => {
            if (data && typeof data.numClients === 'number') {
                numClientsInput.value = data.numClients;
                console.log(`[FRONTEND] Número de clientes inicial carregado: ${data.numClients}`);
            }
        })
        .catch(error => {
            console.error('[FRONTEND] Erro ao obter número de clientes:', error);
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro ao obter número de clientes: ${error.message}`, type: 'error' });
        });

    fetch('/api/routine/status')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.status) {
                const status = data.status;
                if (status.isRunning) {
                    contactListInput.value = status.contactsList.map(c => `${c.nome},${c.numero}`).join('\n');
                    messageContentsInput.value = status.messagesList.join('\n');
                    minDelayInput.value = status.minDelay / 1000;
                    maxDelayInput.value = status.maxDelay / 1000;
                    availableClientsSelect.value = status.selectedClientId || '';

                    routineLog.innerHTML = '';
                    status.logMessages.forEach(logEntry => appendRoutineLog(logEntry));
                    
                    handleRoutineStatusUpdate(status);
                    appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: 'Rotina resgatada do servidor.', type: 'info' });
                    console.log('[FRONTEND] Rotina resgatada do servidor.');
                } else {
                    handleRoutineStatusUpdate(status);
                    console.log('[FRONTEND] Nenhuma rotina ativa para resgatar.');
                }
            }
        })
        .catch(error => {
            console.error('[FRONTEND] Erro ao resgatar status da rotina:', error);
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro ao resgatar status da rotina: ${error.message}`, type: 'error' });
        });

    // Solicita o status inicial dos clientes e clientes prontos para a rotina
    socket.emit('requestInitialClientStatus');
    socket.emit('requestReadyClients');
    console.log('[FRONTEND] Solicitadas informações iniciais do cliente e rotina via Socket.IO.');
});