const socket = io();

// Variáveis para armazenar o estado e os logs no frontend
let currentClients = [];
let frontendRoutineLogs = [];
let selectedClientId = null; // Para guardar o cliente selecionado para a rotina

// --- Funções de Atualização da UI ---

function displayClients(clientsData) {
    const clientsContainer = document.getElementById('clients-container');
    clientsContainer.innerHTML = ''; // Limpa antes de adicionar

    const clientSelect = document.getElementById('selected-client-id');
    clientSelect.innerHTML = '<option value="">Automático (alternar entre prontos)</option>'; // Opção padrão

    clientsData.sort((a, b) => parseInt(a.id) - parseInt(b.id)); // Ordena por ID

    clientsData.forEach(client => {
        const clientCard = document.createElement('div');
        clientCard.className = 'client-card';
        clientCard.id = `client-${client.id}`;

        let statusText = client.status;
        let qrCodeDisplay = '';

        if (client.status === 'QR_CODE' && client.qr) {
            qrCodeDisplay = `<img src="${client.qr}" alt="QR Code para Cliente ${client.id}" class="qr-code-img">`;
            statusText = 'Escaneie o QR Code';
        } else if (client.status === 'Pronto') {
            statusText = 'Pronto';
        } else if (client.status === 'Desconectado' || client.status === 'Falha na Autenticação') {
            statusText = 'Desconectado / Erro de Autenticação';
        }

        const phoneNumberDisplay = client.phoneNumber && client.phoneNumber !== 'N/A' ? `(${client.phoneNumber})` : '';

        clientCard.innerHTML = `
            <h4>Cliente ${client.id}</h4>
            <p>Status: <span class="status-${client.status.toLowerCase().replace(/ /g, '-') || 'unknown'}">${statusText} ${phoneNumberDisplay}</span></p>
            ${qrCodeDisplay}
            <button class="reauth-btn" data-client-id="${client.id}" ${client.status === 'Pronto' ? 'disabled' : ''}>Reautenticar</button>
            <button class="remove-btn" data-client-id="${client.id}">Remover Cliente</button>
        `;
        clientsContainer.appendChild(clientCard);

        // Adiciona ao seletor de cliente para a rotina
        const option = document.createElement('option');
        option.value = client.id;
        option.textContent = `Cliente ${client.id} ${phoneNumberDisplay ? `(${phoneNumberDisplay})` : ''} - ${statusText}`;
        clientSelect.appendChild(option);
    });

    // Atualiza a opção selecionada no dropdown se já houver uma rotina ativa com cliente específico
    if (selectedClientId) {
        clientSelect.value = selectedClientId;
    }

    attachClientButtonListeners(); // Re-adiciona listeners para os novos botões
    currentClients = clientsData; // Atualiza a lista de clientes no frontend
}

function attachClientButtonListeners() {
    document.querySelectorAll('.reauth-btn').forEach(button => {
        button.onclick = async (e) => {
            const clientId = parseInt(e.target.dataset.clientId);
            if (confirm(`Tem certeza que deseja reautenticar o Cliente ${clientId}? Isso desconectará a sessão atual.`)) {
                await fetch('/api/reauthenticate', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ clientId })
                });
            }
        };
    });

    document.querySelectorAll('.remove-btn').forEach(button => {
        button.onclick = async (e) => {
            const clientId = parseInt(e.target.dataset.clientId);
            if (confirm(`Tem certeza que deseja remover o Cliente ${clientId} e seus dados de sessão?`)) {
                await fetch(`/api/set-num-clients`, { // Reutiliza a API set-num-clients para remover
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ numClients: document.getElementById('num-clients-input').value })
                });
                // Uma maneira mais direta de remover se a API de remoção existir:
                // fetch('/api/remove-client', { /* ... */ });
            }
        };
    });
}

function updateReadyClientsDropdown(readyClients) {
    const clientSelect = document.getElementById('selected-client-id');
    const selectedValue = clientSelect.value; // Salva o valor atualmente selecionado

    // Limpa e recria as opções
    clientSelect.innerHTML = '<option value="">Automático (alternar entre prontos)</option>';

    readyClients.sort((a, b) => parseInt(a.id) - parseInt(b.id)); // Ordena por ID

    readyClients.forEach(client => {
        const option = document.createElement('option');
        option.value = client.id;
        option.textContent = `Cliente ${client.id} (${client.phoneNumber}) - Pronto`;
        clientSelect.appendChild(option);
    });

    // Tenta restaurar a seleção, se ainda for um cliente pronto
    if (readyClients.some(c => String(c.id) === selectedValue)) {
        clientSelect.value = selectedValue;
    } else {
        // Se o cliente selecionado não estiver mais pronto, resetar para "Automático"
        clientSelect.value = "";
    }
}


function updateRoutineUI(status) {
    if (!status) return;

    // Atualiza o painel de status da rotina
    document.getElementById('routine-status-display').textContent = status.isRunning ? 'Em Andamento' : 'Inativa';
    document.getElementById('routine-progress-display').textContent = `${status.currentIndex}/${status.totalContacts}`;
    document.getElementById('routine-success-display').textContent = status.successCount;
    document.getElementById('routine-fail-display').textContent = status.failCount;

    // Atualiza o estado dos botões Iniciar/Parar
    const startButton = document.getElementById('start-routine-btn');
    const stopButton = document.getElementById('stop-routine-btn');
    if (status.isRunning) {
        startButton.disabled = true;
        stopButton.disabled = false;
    } else {
        startButton.disabled = false;
        stopButton.disabled = true;
    }

    // --- Parte que preenche os inputs do "prompt" ---
    const contactsTextarea = document.getElementById('contacts-input');
    const messagesTextarea = document.getElementById('messages-input');
    const minDelayInput = document.getElementById('min-delay');
    const maxDelayInput = document.getElementById('max-delay');
    const selectedClientDropdown = document.getElementById('selected-client-id');

    if (status.isRunning) {
        // Preenche os campos de contatos, mensagens e delays
        // Apenas atualiza se o conteúdo for diferente para evitar sobrescrever edição manual (se a rotina já estiver rodando)
        const newContactsValue = status.contactsList.map(c => `${c.nome}:${c.numero}`).join('\n');
        if (contactsTextarea.value !== newContactsValue) {
             contactsTextarea.value = newContactsValue;
        }

        const newMessagesValue = status.messagesList.join('\n');
        if (messagesTextarea.value !== newMessagesValue) {
            messagesTextarea.value = newMessagesValue;
        }

        if (minDelayInput.value !== String(status.minDelay / 1000)) {
            minDelayInput.value = status.minDelay / 1000;
        }
        if (maxDelayInput.value !== String(status.maxDelay / 1000)) {
            maxDelayInput.value = status.maxDelay / 1000;
        }

        // Seleciona o cliente na dropdown
        selectedClientId = status.selectedClientId; // Armazena o ID do cliente selecionado da rotina
        if (selectedClientId && selectedClientDropdown.value !== String(selectedClientId)) {
            selectedClientDropdown.value = String(selectedClientId);
        } else if (!selectedClientId && selectedClientDropdown.value !== "") {
            selectedClientDropdown.value = ""; // Volta para "Automático"
        }

        // Desabilita os campos de input enquanto a rotina estiver rodando para evitar alterações
        contactsTextarea.disabled = true;
        messagesTextarea.disabled = true;
        minDelayInput.disabled = true;
        maxDelayInput.disabled = true;
        selectedClientDropdown.disabled = true;
        document.getElementById('set-num-clients-btn').disabled = true;
        document.getElementById('num-clients-input').disabled = true;


    } else {
        // Habilita os campos de input quando a rotina não estiver rodando
        contactsTextarea.disabled = false;
        messagesTextarea.disabled = false;
        minDelayInput.disabled = false;
        maxDelayInput.disabled = false;
        selectedClientDropdown.disabled = false;
        document.getElementById('set-num-clients-btn').disabled = false;
        document.getElementById('num-clients-input').disabled = false;
        selectedClientId = null; // Resetar
    }
}

// Função para adicionar um log ao "prompt" (console da UI)
function addRoutineLogToUI(logEntry) {
    const logContainer = document.getElementById('routine-log-output');
    const logElement = document.createElement('p');
    logElement.classList.add(`log-${logEntry.type}`);
    logElement.textContent = `[${logEntry.timestamp}] ${logEntry.message}`;
    logContainer.appendChild(logElement);
    logContainer.scrollTop = logContainer.scrollHeight; // Rolagem automática

    frontendRoutineLogs.push(logEntry); // Armazenar no frontend
}

// --- Eventos Socket.IO ---

socket.on('connect', () => {
    console.log('[FRONTEND - SOCKET.IO] Conectado ao servidor.');
    // O backend já envia o status inicial de clientes, rotina e logs na conexão.
    // Não precisamos solicitar aqui.
});

socket.on('disconnect', () => {
    console.log('[FRONTEND - SOCKET.IO] Desconectado do servidor.');
});

socket.on('initialClientStatus', (clientsData) => {
    console.log('[FRONTEND - SOCKET.IO] Initial Client Status Recebido:', clientsData);
    displayClients(clientsData);
});

socket.on('clientStatusUpdate', (clientData) => {
    console.log('[FRONTEND - SOCKET.IO] Client Status Update Recebido:', clientData);
    // Atualiza apenas o cliente específico na exibição
    const existingClientIndex = currentClients.findIndex(c => c.id === clientData.id);
    if (existingClientIndex > -1) {
        currentClients[existingClientIndex] = clientData;
    } else {
        currentClients.push(clientData);
    }
    displayClients(currentClients);
});

socket.on('readyClientsForRoutine', (readyClients) => {
    console.log('[FRONTEND - SOCKET.IO] Ready Clients for Routine Recebido:', readyClients);
    updateReadyClientsDropdown(readyClients);
});

// --- NOVO/REFORÇADO: Evento para receber o status completo da rotina ---
socket.on('routineStatus', (status) => {
    console.log('[FRONTEND - SOCKET.IO] Rotina Status Recebido:', status);
    updateRoutineUI(status);
    // Limpamos os logs *somente* quando recebemos o status inicial da rotina,
    // para evitar duplicação de logs históricos que virão em seguida.
    document.getElementById('routine-log-output').innerHTML = '';
    frontendRoutineLogs = [];
});

// --- NOVO/REFORÇADO: Evento para receber logs individuais da rotina ---
socket.on('routineLogUpdate', (logEntry) => {
    // Adiciona o log sem limpar o conteúdo anterior
    addRoutineLogToUI(logEntry);
});


// --- Listeners de Botões/Inputs ---

document.getElementById('set-num-clients-btn').addEventListener('click', async () => {
    const numClients = parseInt(document.getElementById('num-clients-input').value);
    if (isNaN(numClients) || numClients < 1 || numClients > 10) {
        alert('Por favor, insira um número válido de clientes (1 a 10).');
        return;
    }
    await fetch('/api/set-num-clients', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ numClients })
    });
});

document.getElementById('start-routine-btn').addEventListener('click', async () => {
    const contactsInput = document.getElementById('contacts-input').value;
    const messagesInput = document.getElementById('messages-input').value;
    const minDelay = parseInt(document.getElementById('min-delay').value * 1000); // Converter para ms
    const maxDelay = parseInt(document.getElementById('max-delay').value * 1000); // Converter para ms
    const selectedClientId = document.getElementById('selected-client-id').value;

    if (!contactsInput || !messagesInput) {
        alert('Por favor, preencha os contatos e as mensagens.');
        return;
    }

    if (isNaN(minDelay) || isNaN(maxDelay) || minDelay < 1000 || maxDelay < 1000 || minDelay > maxDelay) {
        alert('Por favor, insira um atraso mínimo e máximo válidos (em segundos, mínimo 1).');
        return;
    }

    const contacts = contactsInput.split('\n').map(line => {
        const parts = line.split(':');
        if (parts.length >= 2) {
            return { nome: parts[0].trim(), numero: parts[1].trim() };
        }
        return null;
    }).filter(c => c !== null);

    const messages = messagesInput.split('\n').map(msg => msg.trim()).filter(msg => msg !== '');

    if (contacts.length === 0 || messages.length === 0) {
        alert('As listas de contatos ou mensagens estão vazias ou mal formatadas.');
        return;
    }

    try {
        const response = await fetch('/api/routine/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contacts, messages, selectedClientId: selectedClientId || null, minDelay, maxDelay })
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao iniciar rotina: ' + (data.message || 'Erro desconhecido.'));
        }
    } catch (error) {
        console.error('Erro ao comunicar com o backend para iniciar rotina:', error);
        alert('Erro ao iniciar rotina. Verifique o console do servidor.');
    }
});

document.getElementById('stop-routine-btn').addEventListener('click', async () => {
    try {
        const response = await fetch('/api/routine/stop', {
            method: 'POST'
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao parar rotina: ' + (data.message || 'Erro desconhecido.'));
        }
    } catch (error) {
        console.error('Erro ao comunicar com o backend para parar rotina:', error);
        alert('Erro ao parar rotina. Verifique o console do servidor.');
    }
});

// --- Inicialização ao carregar a página ---
document.addEventListener('DOMContentLoaded', () => {
    // Solicita o número de clientes configurados no backend
    fetch('/api/get-num-clients')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('num-clients-input').value = data.numClients;
            }
        })
        .catch(error => console.error('Erro ao obter número de clientes:', error));

    // O status inicial de clientes, rotina e logs será enviado automaticamente pelo backend na conexão do socket.
    // Não precisamos fazer requisições GET adicionais aqui para a rotina.
});