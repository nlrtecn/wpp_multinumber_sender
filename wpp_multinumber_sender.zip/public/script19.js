document.addEventListener('DOMContentLoaded', () => {
    const socket = io();

    // ... (restante do seu código JavaScript existente) ...

    // Elementos de Configuração de Clientes
    const numClientsSelect = document.getElementById('num-clients-select');
    const saveNumClientsButton = document.getElementById('save-num-clients-button');
    const clientConfigStatusDiv = document.getElementById('client-config-status');

    // ... (restante do seu código JavaScript existente, incluindo as bases de dados de contatos e mensagens) ...

    // --- NOVO: Listener para o botão Salvar Configuração de Clientes ---
    saveNumClientsButton.addEventListener('click', async () => {
        const numClients = parseInt(numClientsSelect.value);
        if (isNaN(numClients) || numClients < 1 || numClients > 10) {
            clientConfigStatusDiv.textContent = 'Por favor, selecione um número válido de clientes (1-10).';
            clientConfigStatusDiv.className = 'status-message error';
            return;
        }

        // Antes de enviar, mostra a mensagem de reinício
        clientConfigStatusDiv.textContent = `Salvando configuração para ${numClients} clientes... O servidor será reiniciado automaticamente.`;
        clientConfigStatusDiv.className = 'status-message info';
        saveNumClientsButton.disabled = true; // Desabilita o botão enquanto salva

        try {
            const response = await fetch('/api/set-num-clients', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ numClients: numClients }),
            });
            const result = await response.json();

            if (result.success) {
                // A mensagem inicial já avisa sobre o reinício.
                // Após o reinício (e recarregamento da página/reconexão do socket),
                // a função de carregamento inicial vai buscar o valor atualizado.
                console.log(result.message); // Log para o console do navegador
                // Não precisamos mais setar uma mensagem final aqui, pois a página vai recarregar/reemitir o status
            } else {
                clientConfigStatusDiv.textContent = `Erro: ${result.message}`;
                clientConfigStatusDiv.className = 'status-message error';
            }
        } catch (error) {
            console.error('Erro ao salvar configuração:', error);
            clientConfigStatusDiv.textContent = `Erro de comunicação: ${error.message}. Verifique o console do servidor.`;
            clientConfigStatusDiv.className = 'status-message error';
        } finally {
            // O botão será reativado quando a página recarregar ou, se não recarregar,
            // poderíamos reativá-lo aqui (mas para nodemon, o recarregamento é esperado).
            // saveNumClientsButton.disabled = false; // Descomente se não houver recarga de página completa
        }
    });

    // --- Requisição inicial para carregar o status dos clientes e configurar o dropdown de numClients ---
    // Este bloco deve ser ajustado para garantir que a mensagem de status da configuração seja atualizada
    // COM o valor *real* após o carregamento da página/reconexão.
    fetch('/api/clients/status')
        .then(response => response.json())
        .then(data => {
            // ... (código existente para popular clientSelect e qrClientSelect) ...
        })
        .catch(error => {
            console.error('Erro ao carregar status inicial dos clientes:', error);
            qrDisplayCard.innerHTML = '<p class="status-message error">Erro ao carregar status dos clientes. Verifique o servidor.</p>';
        });

    // NOVO: Requisição para obter o NUM_CLIENTS atual do servidor e pré-selecionar no dropdown
    // E ATUALIZAR A MENSAGEM DE STATUS DA CONFIGURAÇÃO INICIALMENTE.
    fetch('/api/get-num-clients')
        .then(response => response.json())
        .then(data => {
            if (data.numClients !== undefined) {
                numClientsSelect.value = data.numClients;
                // ATUALIZAÇÃO AQUI: Define a mensagem inicial com o valor lido do servidor
                clientConfigStatusDiv.textContent = `Configuração de NUM_CLIENTS atual: ${data.numClients}`;
                clientConfigStatusDiv.className = 'status-message info'; // ou 'status-message success' se preferir
            }
        })
        .catch(error => {
            console.error('Erro ao carregar NUM_CLIENTS atual:', error);
            clientConfigStatusDiv.textContent = 'Não foi possível carregar a configuração atual de clientes.';
            clientConfigStatusDiv.className = 'status-message error';
        });

    socket.emit('requestRoutineStatus');
    socket.emit('requestReadyClients');
});