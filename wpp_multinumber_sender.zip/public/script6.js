document.addEventListener('DOMContentLoaded', () => {
    const socket = io(); // Conecta ao Socket.IO
    const clientListDiv = document.getElementById('client-list');
    const clientSelect = document.getElementById('client-select');
    const sendMessageForm = document.getElementById('send-message-form');
    const sendMessageStatusDiv = document.getElementById('send-message-status');

    // Elementos do Modal
    const qrModalOverlay = document.getElementById('qr-modal-overlay');
    const modalClientName = document.getElementById('modal-client-name');
    const modalQrCodeImg = document.getElementById('modal-qr-code-img');
    const modalQrMessage = document.getElementById('modal-qr-message');
    const closeModalButton = document.querySelector('.close-button');


    // Armazena o estado dos clientes no front-end
    const clientsState = {};

    /**
     * Renderiza ou atualiza o card de um cliente na interface.
     * @param {object} clientInfo Informações do cliente (id, name, status, qr)
     */
    function renderClientCard(clientInfo) {
        let clientCard = document.getElementById(`client-card-${clientInfo.id}`);
        if (!clientCard) {
            clientCard = document.createElement('div');
            clientCard.id = `client-card-${clientInfo.id}`;
            clientCard.classList.add('client-card');
            clientListDiv.appendChild(clientCard);
        }

        // Determina se o botão "Autenticar/Reautenticar" deve ser mostrado
        const showAuthButton = ['QR_CODE', 'Desconectado', 'Falha na Autenticação', 'Erro de Inicialização', 'Erro ao Reconectar', 'Erro de Comunicação'].includes(clientInfo.status);
        const buttonText = clientInfo.status === 'QR_CODE' ? 'Autenticar' : 'Reautenticar';


        clientCard.innerHTML = `
            <h3>${clientInfo.name}</h3>
            <p>Status: <span class="status-${clientInfo.status.toLowerCase().replace(/ /g, '-')}">${clientInfo.status}</span></p>
            <div class="qr-code-area" id="qr-code-area-${clientInfo.id}">
                </div>
            ${showAuthButton
                ? `<button class="auth-button" data-client-id="${clientInfo.id}">${buttonText}</button>`
                : ''
            }
        `;

        // Adiciona o event listener ao botão, se ele existir
        if (showAuthButton) {
            const authButton = clientCard.querySelector('.auth-button');
            authButton.addEventListener('click', () => {
                if (clientInfo.status === 'QR_CODE' && clientInfo.qr) {
                    openQrModal(clientInfo.id, clientInfo.name, clientInfo.qr);
                } else {
                    handleReauthenticate(clientInfo.id);
                }
            });
        }

        // Adiciona/atualiza a opção no select de envio de mensagem
        let option = clientSelect.querySelector(`option[value="${clientInfo.id}"]`);
        if (!option) {
            option = document.createElement('option');
            option.value = clientInfo.id;
            clientSelect.appendChild(option);
        }
        option.textContent = clientInfo.name;
        // Habilita/desabilita a opção no select
        option.disabled = (clientInfo.status !== 'Pronto');
    }

    /**
     * Lida com o clique no botão de reautenticação.
     * @param {number} clientId O ID do cliente a ser reautenticado.
     */
    async function handleReauthenticate(clientId) {
        const clientCard = document.getElementById(`client-card-${clientId}`);
        const authButton = clientCard.querySelector('.auth-button');
        if (authButton) {
            authButton.disabled = true; // Desabilita o botão para evitar múltiplos cliques
            authButton.textContent = 'Reautenticando...';
        }

        // Atualiza o status visualmente para "Reautenticando"
        const currentClientInfo = clientsState[clientId];
        if (currentClientInfo) {
            renderClientCard({ ...currentClientInfo, status: 'Reautenticando', qr: null });
        }

        try {
            const response = await fetch('/api/reauthenticate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ clientId: clientId }),
            });

            const result = await response.json();

            if (result.success) {
                console.log(result.message);
                // O status real será atualizado pelo Socket.IO (QR_CODE, Pronto, etc.)
            } else {
                console.error(`Erro ao reautenticar cliente ${clientId}:`, result.message);
                // Reverte o botão para habilitado e mostra erro
                if (authButton) {
                    authButton.disabled = false;
                    authButton.textContent = 'Reautenticar';
                }
                renderClientCard({ ...currentClientInfo, status: 'Erro ao Reautenticar', qr: null });
                alert(`Erro ao reautenticar Cliente ${clientId}: ${result.message}`);
            }
        } catch (error) {
            console.error(`Erro na requisição de reautenticação para o cliente ${clientId}:`, error);
            if (authButton) {
                authButton.disabled = false;
                authButton.textContent = 'Reautenticar';
            }
            renderClientCard({ ...currentClientInfo, status: 'Erro de Comunicação', qr: null });
            alert(`Erro de comunicação ao tentar reautenticar Cliente ${clientId}. Verifique o console do navegador e do servidor.`);
        }
    }

    /**
     * Abre o modal de QR Code.
     * @param {number} clientId O ID do cliente.
     * @param {string} clientName O nome do cliente.
     * @param {string} qrData O dado do QR Code.
     */
    function openQrModal(clientId, clientName, qrData) {
        modalClientName.textContent = `Cliente ${clientName} (#${clientId})`;
        modalQrCodeImg.src = `https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${encodeURIComponent(qrData)}`;
        modalQrMessage.textContent = 'Escaneie este QR Code com seu WhatsApp para autenticar o cliente.';
        qrModalOverlay.style.display = 'flex'; // Exibe o modal
    }

    /**
     * Fecha o modal de QR Code.
     */
    function closeQrModal() {
        qrModalOverlay.style.display = 'none'; // Esconde o modal
        modalQrCodeImg.src = ''; // Limpa a imagem do QR code
    }

    // Event listener para o botão de fechar do modal
    closeModalButton.addEventListener('click', closeQrModal);
    // Fecha o modal se clicar fora do conteúdo do modal
    qrModalOverlay.addEventListener('click', (event) => {
        if (event.target === qrModalOverlay) {
            closeQrModal();
        }
    });


    // --- Socket.IO Event Listeners ---

    // Recebe o status inicial de todos os clientes ao conectar
    socket.on('initialClientStatus', (initialData) => {
        clientListDiv.innerHTML = ''; // Limpa a mensagem de carregamento
        clientSelect.innerHTML = '<option value="">Selecione um cliente</option>'; // Limpa as opções
        initialData.forEach(clientInfo => {
            clientsState[clientInfo.id] = clientInfo; // Armazena o estado
            renderClientCard(clientInfo);
            // Se um cliente já estiver em status QR_CODE na inicialização, abre o modal
            if (clientInfo.status === 'QR_CODE' && clientInfo.qr) {
                openQrModal(clientInfo.id, clientInfo.name, clientInfo.qr);
            }
        });
    });

    // Recebe atualizações de status de clientes individuais
    socket.on('clientStatusUpdate', (updatedClientInfo) => {
        clientsState[updatedClientInfo.id] = updatedClientInfo; // Atualiza o estado
        renderClientCard(updatedClientInfo);

        // Se o status for QR_CODE, abre o modal
        if (updatedClientInfo.status === 'QR_CODE' && updatedClientInfo.qr) {
            openQrModal(updatedClientInfo.id, updatedClientInfo.name, updatedClientInfo.qr);
        } else if (updatedClientInfo.status === 'Pronto' || updatedClientInfo.status === 'Autenticado') {
            // Se o cliente autenticou, fecha o modal (caso ele esteja aberto para este cliente)
            const currentModalClientName = modalClientName.textContent;
            // Verifica se o modal está aberto e se o cliente atual do modal é este que autenticou
            if (qrModalOverlay.style.display === 'flex' && currentModalClientName.includes(`(#${updatedClientInfo.id})`)) {
                 closeQrModal();
            }
        }
    });

    // --- Formulário de Envio de Mensagem ---
    sendMessageForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        sendMessageStatusDiv.textContent = 'Enviando mensagem...';
        sendMessageStatusDiv.className = 'status-message info';

        const formData = new FormData(sendMessageForm);
        const clientId = formData.get('clientId');
        const number = formData.get('number');
        const message = formData.get('message');

        try {
            const response = await fetch('/api/send-message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ clientId, number, message }),
            });

            const result = await response.json();

            if (result.success) {
                sendMessageStatusDiv.textContent = result.message;
                sendMessageStatusDiv.className = 'status-message success';
                sendMessageForm.reset(); // Limpa o formulário
            } else {
                sendMessageStatusDiv.textContent = `Erro: ${result.message}`;
                sendMessageStatusDiv.className = 'status-message error';
            }
        } catch (error) {
            console.error('Erro ao enviar mensagem:', error);
            sendMessageStatusDiv.textContent = `Erro ao conectar com o servidor: ${error.message}`;
            sendMessageStatusDiv.className = 'status-message error';
        }
    });

    // Requisição inicial para carregar o status dos clientes caso o socket não tenha emitido ainda
    fetch('/api/clients/status')
        .then(response => response.json())
        .then(data => {
            if (Object.keys(clientsState).length === 0) { // Se o socket ainda não preencheu
                clientListDiv.innerHTML = '';
                clientSelect.innerHTML = '<option value="">Selecione um cliente</option>';
                data.forEach(clientInfo => {
                    clientsState[clientInfo.id] = clientInfo;
                    renderClientCard(clientInfo);
                    // Abre o modal se já estiver no status QR_CODE na carga inicial
                    if (clientInfo.status === 'QR_CODE' && clientInfo.qr) {
                        openQrModal(clientInfo.id, clientInfo.name, clientInfo.qr);
                    }
                });
            }
        })
        .catch(error => {
            console.error('Erro ao carregar status inicial dos clientes:', error);
            clientListDiv.innerHTML = '<p class="status-message error">Erro ao carregar status dos clientes.</p>';
        });
});