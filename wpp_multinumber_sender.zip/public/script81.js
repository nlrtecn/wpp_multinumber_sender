const socket = io();

let currentClients = [];
let frontendRoutineLogs = [];
let selectedClientId = null;

// --- Funções de Atualização da UI ---

function displayClients(clientsData) {
    const clientsContainer = document.getElementById('clients-container');
    clientsContainer.innerHTML = '';

    // Ordena os clientes por ID para exibição consistente
    clientsData.sort((a, b) => parseInt(a.id) - parseInt(b.id));

    clientsData.forEach(client => {
        const clientCard = document.createElement('div');
        clientCard.className = 'client-card';
        clientCard.id = `client-${client.id}`;

        let statusText = client.status;
        let qrCodeDisplay = '';
        if (client.status === 'QR_CODE' && client.qr) {
            qrCodeDisplay = `<img src="${client.qr}" alt="QR Code para Cliente ${client.id}" class="qr-code-img">`;
            statusText = 'Escaneie o QR Code';
        } else if (client.status === 'Pronto') {
            statusText = 'Pronto';
        } else if (client.status === 'Desconectado' || client.status === 'Falha na Autenticação' || client.status === 'Erro') {
            statusText = 'Desconectado / Erro';
        } else if (client.status === 'Removido') {
             statusText = 'Removido'; // Status para clientes que foram removidos
        }


        const phoneNumberDisplay = client.phoneNumber && client.phoneNumber !== 'N/A' ? `(${client.phoneNumber})` : '';

        clientCard.innerHTML = `
            <h4>Cliente ${client.id}</h4>
            <p>Status: <span class="status-${client.status.toLowerCase().replace(/ /g, '-').replace('á', 'a').replace('ç', 'c') || 'unknown'}">${statusText} ${phoneNumberDisplay}</span></p>
            ${qrCodeDisplay}
            <button class="reauth-btn" data-client-id="${client.id}" ${client.status === 'Pronto' ? 'disabled' : ''}>Reautenticar</button>
            <button class="remove-btn" data-client-id="${client.id}">Remover Cliente</button>
        `;
        clientsContainer.appendChild(clientCard);
    });

    attachClientButtonListeners();
    currentClients = clientsData;
}

function attachClientButtonListeners() {
    document.querySelectorAll('.reauth-btn').forEach(button => {
        button.removeEventListener('click', handleReauthenticateClick);
        button.addEventListener('click', handleReauthenticateClick);
    });

    document.querySelectorAll('.remove-btn').forEach(button => {
        button.removeEventListener('click', handleRemoveClientClick);
        button.addEventListener('click', handleRemoveClientClick);
    });
}

async function handleReauthenticateClick(e) {
    const clientId = parseInt(e.target.dataset.clientId);
    if (confirm(`Tem certeza que deseja reautenticar o Cliente ${clientId}? Isso desconectará a sessão atual e exigirá um novo QR Code.`)) {
        try {
            const response = await fetch('/api/reauthenticate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ clientId })
            });
            const data = await response.json();
            if (!data.success) {
                alert('Erro ao reautenticar: ' + data.message);
            }
        } catch (error) {
            console.error('Erro de rede ao reautenticar:', error);
            alert('Erro de comunicação com o servidor ao reautenticar.');
        }
    }
}

async function handleRemoveClientClick(e) {
    const clientId = parseInt(e.target.dataset.clientId);
    if (confirm(`Tem certeza que deseja remover o Cliente ${clientId} e seus dados de sessão? Esta ação é irreversível.`)) {
        try {
            // Ao invés de recalcular o numClients no frontend, apenas sinalizamos a remoção
            // e deixamos o backend gerenciar a lista de clientes.
            const response = await fetch(`/api/set-num-clients`, { // Reusar a rota set-num-clients
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                // Envia o número de clientes atual menos o que será removido
                body: JSON.stringify({ numClients: currentClients.length - 1 }) 
            });
            const data = await response.json();
            if (!data.success) {
                alert('Erro ao remover cliente: ' + data.message);
            }
        } catch (error) {
            console.error('Erro de rede ao remover cliente:', error);
            alert('Erro de comunicação com o servidor ao remover cliente.');
        }
    }
}


function updateReadyClientsDropdown(readyClients) {
    const clientSelect = document.getElementById('selected-client-id');
    const previousSelectedValue = clientSelect.value;

    clientSelect.innerHTML = '<option value="">Automático (alternar entre prontos)</option>';

    readyClients.sort((a, b) => parseInt(a.id) - parseInt(b.id));

    readyClients.forEach(client => {
        const option = document.createElement('option');
        option.value = client.id;
        option.textContent = `Cliente ${client.id} (${client.phoneNumber}) - Pronto`;
        clientSelect.appendChild(option);
    });

    if (selectedClientId && readyClients.some(c => String(c.id) === String(selectedClientId))) {
        clientSelect.value = String(selectedClientId);
    } else if (readyClients.some(c => String(c.id) === previousSelectedValue)) {
        clientSelect.value = previousSelectedValue;
    } else {
        clientSelect.value = "";
    }
}

function updateRoutineUI(status) {
    if (!status) return;

    document.getElementById('routine-status-display').textContent = status.isRunning ? 'Em Andamento' : 'Inativa';
    document.getElementById('routine-progress-display').textContent = `${status.currentIndex}/${status.totalContacts}`;
    document.getElementById('routine-success-display').textContent = status.successCount;
    document.getElementById('routine-fail-display').textContent = status.failCount;

    const startButton = document.getElementById('start-routine-btn');
    const stopButton = document.getElementById('stop-routine-btn');

    const contactsInput = document.getElementById('contacts-input');
    const messagesInput = document.getElementById('messages-input');
    const minDelayInput = document.getElementById('min-delay');
    const maxDelayInput = document.getElementById('max-delay');
    const selectedClientDropdown = document.getElementById('selected-client-id');
    const setNumClientsBtn = document.getElementById('set-num-clients-btn');
    const numClientsInput = document.getElementById('num-clients-input');

    const elementsToDisable = [
        contactsInput, messagesInput, minDelayInput, maxDelayInput,
        selectedClientDropdown, setNumClientsBtn, numClientsInput
    ];

    if (status.isRunning) {
        startButton.disabled = true;
        stopButton.disabled = false;

        elementsToDisable.forEach(el => {
            if (el) el.disabled = true;
        });

        // Preenche os campos com os dados da rotina em andamento
        contactsInput.value = status.contactsList.map(c => `${c.nome}:${c.numero}`).join('\n');
        messagesInput.value = status.messagesList.join('\n');
        minDelayInput.value = status.minDelay / 1000;
        maxDelayInput.value = status.maxDelay / 1000;
        
        selectedClientId = status.selectedClientId; // Atualiza a variável global
        if (selectedClientId) {
            selectedClientDropdown.value = String(selectedClientId);
        } else {
            selectedClientDropdown.value = "";
        }

    } else {
        startButton.disabled = false;
        stopButton.disabled = true;

        elementsToDisable.forEach(el => {
            if (el) el.disabled = false;
        });
        selectedClientId = null; // Limpa a seleção do cliente após a rotina terminar
    }
}

function addRoutineLogToUI(logEntry) {
    const logContainer = document.getElementById('routine-log-output');
    const logElement = document.createElement('p');
    logElement.classList.add(`log-${logEntry.type}`);
    logElement.textContent = `[${logEntry.timestamp}] ${logEntry.message}`;
    logContainer.appendChild(logElement);
    logContainer.scrollTop = logContainer.scrollHeight;

    frontendRoutineLogs.push(logEntry);
}

// --- Eventos Socket.IO ---

socket.on('connect', () => {
    console.log('[FRONTEND - SOCKET.IO] Conectado ao servidor.');
    socket.emit('requestInitialClientStatus');
    socket.emit('requestRoutineStatus');
    socket.emit('requestReadyClients');
});

socket.on('disconnect', () => {
    console.log('[FRONTEND - SOCKET.IO] Desconectado do servidor.');
});

socket.on('initialClientStatus', (clientsData) => {
    console.log('[FRONTEND - SOCKET.IO] Initial Client Status Recebido:', clientsData);
    displayClients(clientsData);
});

socket.on('clientStatusUpdate', (clientData) => {
    console.log('[FRONTEND - SOCKET.IO] Client Status Update Recebido:', clientData);
    const existingClientIndex = currentClients.findIndex(c => c.id === clientData.id);
    if (existingClientIndex > -1) {
        // Se o status for "Removido", remove o cliente da lista local
        if (clientData.status === 'Removido') {
            currentClients.splice(existingClientIndex, 1);
        } else {
            currentClients[existingClientIndex] = clientData;
        }
    } else if (clientData.status !== 'Removido') { // Adiciona novo cliente se não for removido
        currentClients.push(clientData);
    }
    displayClients(currentClients);
});

socket.on('readyClientsForRoutine', (readyClients) => {
    console.log('[FRONTEND - SOCKET.IO] Ready Clients for Routine Recebido:', readyClients);
    updateReadyClientsDropdown(readyClients);
});

socket.on('routineStatus', (status) => {
    console.log('[FRONTEND - SOCKET.IO] Rotina Status Recebido:', status);
    updateRoutineUI(status);
    document.getElementById('routine-log-output').innerHTML = '';
    frontendRoutineLogs = [];
    if (status.logMessages && status.logMessages.length > 0) {
        status.logMessages.forEach(logEntry => addRoutineLogToUI(logEntry));
    }
});

socket.on('routineLogUpdate', (logEntry) => {
    addRoutineLogToUI(logEntry);
});

// --- Listeners de Eventos DOM (Botões/Inputs) ---

document.getElementById('set-num-clients-btn').addEventListener('click', async () => {
    const numClients = parseInt(document.getElementById('num-clients-input').value);
    if (isNaN(numClients) || numClients < 0 || numClients > 10) {
        alert('Por favor, insira um número válido de clientes (0 a 10).');
        return;
    }
    try {
        const response = await fetch('/api/set-num-clients', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ numClients })
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao definir clientes: ' + (data.message || 'Erro desconhecido.'));
        }
        // A atualização dos clientes na UI será tratada pelo Socket.IO 'clientStatusUpdate'
        // e 'initialClientStatus' ao se ajustar a lista.
    } catch (error) {
        console.error('Erro ao comunicar com o backend para definir clientes:', error);
        alert('Erro de comunicação com o servidor ao definir clientes.');
    }
});

document.getElementById('start-routine-btn').addEventListener('click', async () => {
    const contactsInput = document.getElementById('contacts-input');
    const messagesInput = document.getElementById('messages-input');
    const minDelayInput = document.getElementById('min-delay');
    const maxDelayInput = document.getElementById('max-delay');
    const selectedClientDropdown = document.getElementById('selected-client-id');

    const contactsText = contactsInput.value;
    const messagesText = messagesInput.value;
    const minDelay = parseInt(minDelayInput.value * 1000);
    const maxDelay = parseInt(maxDelayInput.value * 1000);
    const selectedClientIdRaw = selectedClientDropdown.value;
    selectedClientId = selectedClientIdRaw ? parseInt(selectedClientIdRaw) : null; // Atualiza a variável global

    if (!contactsText || !messagesText) {
        alert('Por favor, preencha os contatos e as mensagens.');
        return;
    }

    if (isNaN(minDelay) || isNaN(maxDelay) || minDelay < 1000 || maxDelay < 1000 || minDelay > maxDelay) {
        alert('Por favor, insira um atraso mínimo e máximo válidos (em segundos, mínimo 1). O atraso mínimo deve ser menor ou igual ao máximo.');
        return;
    }

    const contacts = contactsText.split('\n').map(line => {
        const parts = line.split(':');
        if (parts.length >= 2) {
            return { nome: parts[0].trim(), numero: parts[1].trim() };
        }
        return null;
    }).filter(c => c !== null && c.nome && c.numero);

    const messages = messagesText.split('\n').map(msg => msg.trim()).filter(msg => msg !== '');

    if (contacts.length === 0 || messages.length === 0) {
        alert('As listas de contatos ou mensagens estão vazias ou mal formatadas. Verifique o formato Nome:Número para contatos.');
        return;
    }

    try {
        const response = await fetch('/api/routine/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contacts, messages, selectedClientId, minDelay, maxDelay })
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao iniciar rotina: ' + (data.message || 'Erro desconhecido.'));
        }
    } catch (error) {
        console.error('Erro ao comunicar com o backend para iniciar rotina:', error);
        alert('Erro ao iniciar rotina. Verifique o console do servidor.');
    }
});

document.getElementById('stop-routine-btn').addEventListener('click', async () => {
    try {
        const response = await fetch('/api/routine/stop', {
            method: 'POST'
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao parar rotina: ' + (data.message || 'Erro desconhecido.'));
        }
    } catch (error) {
        console.error('Erro ao comunicar com o backend para parar rotina:', error);
        alert('Erro ao parar rotina. Verifique o console do servidor.');
    }
});

// --- Inicialização ao Carregar a Página ---
document.addEventListener('DOMContentLoaded', () => {
    fetch('/api/get-num-clients')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('num-clients-input').value = data.numClients;
            }
        })
        .catch(error => console.error('Erro ao obter número de clientes:', error));

    attachClientButtonListeners();
});