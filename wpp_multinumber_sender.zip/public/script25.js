const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const fs = require('fs');

// Módulos personalizados
const whatsappClientManager = require('./whatsappClientManager');
const routineManager = require('./routineManager');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

// --- Configuração ---
const configPath = path.join(__dirname, 'config.json');

// Função para carregar a configuração
const loadConfig = () => {
    if (fs.existsSync(configPath)) {
        const configData = fs.readFileSync(configPath, 'utf8');
        return JSON.parse(configData);
    }
    return { NUM_CLIENTS: 1 }; // Valor padrão
};

// Função para salvar a configuração
const saveConfig = (config) => {
    fs.writeFileSync(configPath, JSON.stringify(config, null, 2), 'utf8');
};

// Carregar configuração inicial
let appConfig = loadConfig();

// --- Middlewares ---
app.use(express.json()); // Para parsing de application/json
app.use(express.static(path.join(__dirname, 'public'))); // Servir arquivos estáticos do diretório public

// --- Inicialização dos Gerenciadores ---
// Passa a instância do io para os gerenciadores
whatsappClientManager.init(io, appConfig.NUM_CLIENTS);
routineManager.init(io);

// Garante que os clientes sejam inicializados ou reinicializados com base na configuração
// Isso pode ser chamado no início ou quando a configuração NUM_CLIENTS muda.
whatsappClientManager.initializeClients(appConfig.NUM_CLIENTS);


// --- Rotas da API ---

// Rota para obter o número atual de clientes configurado
app.get('/api/get-num-clients', (req, res) => {
    res.json({ numClients: appConfig.NUM_CLIENTS });
});

// Rota para definir o número de clientes
app.post('/api/set-num-clients', (req, res) => {
    const { numClients } = req.body;
    if (typeof numClients !== 'number' || numClients < 1 || numClients > 10) {
        return res.status(400).json({ success: false, message: 'Número de clientes inválido. Deve ser entre 1 e 10.' });
    }

    // Atualiza a configuração e salva
    appConfig.NUM_CLIENTS = numClients;
    saveConfig(appConfig);

    // Reinicializa os clientes com a nova configuração
    whatsappClientManager.initializeClients(appConfig.NUM_CLIENTS);

    res.json({ success: true, message: `Configuração de NUM_CLIENTS salva para ${numClients}. O servidor está sendo reiniciado para aplicar a mudança...` });
    // Nota: A "reinicialização" real aqui é o nodemon que detecta a mudança no arquivo,
    // ou você precisaria de um mecanismo de reinício programático para produção.
    // Para fins de desenvolvimento com nodemon, a mensagem já indica o comportamento esperado.
});

// Rota para obter o status de todos os clientes
app.get('/api/clients/status', (req, res) => {
    const clientsStatus = whatsappClientManager.getAllClientsStatus();
    res.json(clientsStatus);
});

// Rota para reautenticar um cliente específico
app.post('/api/reauthenticate', async (req, res) => {
    const { clientId } = req.body;
    if (typeof clientId !== 'number') {
        return res.status(400).json({ success: false, message: 'ID do cliente inválido.' });
    }
    try {
        const result = await whatsappClientManager.reauthenticateClient(clientId);
        if (result.success) {
            res.json({ success: true, message: `Reautenticação do Cliente ${clientId} solicitada com sucesso.` });
        } else {
            res.status(500).json({ success: false, message: result.message });
        }
    } catch (error) {
        console.error(`Erro na rota /api/reauthenticate para o cliente ${clientId}:`, error);
        res.status(500).json({ success: false, message: 'Erro interno ao tentar reautenticar o cliente.' });
    }
});

// Rota para enviar uma mensagem manual
app.post('/api/send-message', async (req, res) => {
    const { clientId, number, message } = req.body;

    if (!clientId || !number || !message) {
        return res.status(400).json({ success: false, message: 'ID do cliente, número e mensagem são obrigatórios.' });
    }

    try {
        const result = await whatsappClientManager.sendMessage(clientId, number, message);
        if (result.success) {
            res.json({ success: true, message: `Mensagem enviada com sucesso para ${number} via Cliente ${clientId}.` });
        } else {
            res.status(500).json({ success: false, message: result.message });
        }
    } catch (error) {
        console.error('Erro na rota /api/send-message:', error);
        res.status(500).json({ success: false, message: 'Erro interno ao enviar mensagem.' });
    }
});

// Rota para iniciar a rotina de envio
app.post('/api/start-routine', async (req, res) => {
    const { message, minTime, maxTime, contacts } = req.body;
    if (!message || !contacts || !Array.isArray(contacts) || contacts.length === 0 || !minTime || !maxTime) {
        return res.status(400).json({ success: false, message: 'Dados da rotina incompletos.' });
    }

    try {
        const readyClients = whatsappClientManager.getReadyClients();
        if (readyClients.length === 0) {
            return res.status(400).json({ success: false, message: 'Não há clientes "Prontos" disponíveis para iniciar a rotina.' });
        }

        routineManager.startRoutine(message, minTime, maxTime, contacts);
        res.json({ success: true, message: 'Rotina de envio iniciada.' });
    } catch (error) {
        console.error('Erro ao iniciar rotina:', error);
        res.status(500).json({ success: false, message: error.message });
    }
});

// --- Eventos Socket.IO ---
io.on('connection', (socket) => {
    console.log('Um cliente se conectou ao Socket.IO');

    // Envia o status inicial de todos os clientes quando um novo cliente se conecta
    socket.emit('initialClientStatus', whatsappClientManager.getAllClientsStatus());

    // Solicita o status da rotina ao conectar
    socket.emit('routineStatus', routineManager.getRoutineStatus());

    // Solicita os clientes prontos para a rotina
    socket.emit('readyClientsForRoutine', whatsappClientManager.getReadyClients());

    socket.on('requestRoutineStatus', () => {
        socket.emit('routineStatus', routineManager.getRoutineStatus());
    });

    socket.on('requestReadyClients', () => {
        socket.emit('readyClientsForRoutine', whatsappClientManager.getReadyClients());
    });

    socket.on('disconnect', () => {
        console.log('Um cliente se desconectou do Socket.IO');
    });
});

// --- Inicialização do Servidor ---
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
    console.log(`Acesse: http://localhost:${PORT}`);
});