document.addEventListener('DOMContentLoaded', () => {
    const socket = io(); // Conecta ao servidor Socket.IO

    const clientsContainer = document.getElementById('clients-container');
    const setClientsForm = document.getElementById('set-clients-form');
    const numClientsInput = document.getElementById('numClients');
    
    const contactListInput = document.getElementById('contactList');
    const messageContentsInput = document.getElementById('messageContents');

    const startRoutineBtn = document.getElementById('startRoutineBtn');
    const stopRoutineBtn = document.getElementById('stopRoutineBtn');
    const routineLog = document.getElementById('routineLog');
    const saveLogBtn = document.getElementById('saveLogBtn');
    const routineStatusSpan = document.getElementById('routineStatus');
    const availableClientsSelect = document.getElementById('availableClients');
    const routineProgressBar = document.getElementById('routineProgressBar');
    const routineProgressText = document.getElementById('routineProgressText');
    const minDelayInput = document.getElementById('minDelay');
    const maxDelayInput = document.getElementById('maxDelay');

    let allClients = {}; // Mantém o estado dos clientes para exibir na UI
    let readyClientsForRoutine = []; // Clientes prontos para preencher o select

    // --- Funções de Utilitário do Frontend ---
    function appendRoutineLog(logEntry) {
        const p = document.createElement('p');
        p.textContent = `[${logEntry.timestamp}] ${logEntry.message}`;
        p.classList.add(`log-${logEntry.type}`);
        routineLog.appendChild(p);
        routineLog.scrollTop = routineLog.scrollHeight;
        console.log(`[FRONTEND LOG] ${logEntry.timestamp} [${logEntry.type.toUpperCase()}] ${logEntry.message}`); // Para depuração
    }

    function updateClientCard(client) {
        console.log(`[FRONTEND] Atualizando card para Cliente ${client.id}: Status=${client.status}, QR=${client.qr ? 'Sim' : 'Não'}, Telefone=${client.phoneNumber}`); // Depuração

        let clientCard = document.getElementById(`client-card-${client.id}`);

        if (client.status === 'Removido') {
            if (clientCard) {
                clientCard.remove();
                console.log(`[FRONTEND] Cliente ${client.id} removido.`); // Depuração
            }
            delete allClients[client.id];
            updateAvailableClientsForRoutine();
            return;
        }

        if (!clientCard) {
            clientCard = document.createElement('div');
            clientCard.id = `client-card-${client.id}`;
            clientCard.classList.add('client-card');
            clientsContainer.appendChild(clientCard);
            console.log(`[FRONTEND] Card Cliente ${client.id} criado.`); // Depuração
        }

        allClients[client.id] = { ...allClients[client.id], ...client };

        clientCard.innerHTML = `
            <h3>Cliente ${client.id}</h3>
            <p><strong>Nome:</strong> ${client.name}</p>
            <p><strong>Status:</strong> <span id="status-${client.id}">${client.status}</span></p>
            <p><strong>Telefone:</strong> <span id="phone-${client.id}">${client.phoneNumber || 'N/A'}</span></p>
            <div class="qr-code-area" id="qr-area-${client.id}">
                ${client.status === 'QR_CODE' && client.qr ?
                    `<img src="${client.qr}" alt="QR Code para Cliente ${client.id}" style="width: 200px; height: 200px; display: block;">` :
                    `<p>${client.status === 'Pronto' ? 'Conectado!' : (client.status === 'Erro' ? 'Erro de Conexão' : 'Aguardando QR Code...')}</p>`
                }
            </div>
            <button class="reauthenticate-btn" data-client-id="${client.id}" ${client.status === 'Pronto' || client.status === 'Autenticado' ? '' : 'disabled'}>Reautenticar</button>
        `;

        const reauthenticateBtn = clientCard.querySelector(`.reauthenticate-btn`);
        if (reauthenticateBtn) {
            reauthenticateBtn.onclick = async () => {
                console.log(`[FRONTEND] Botão Reautenticar clicado para Cliente ${client.id}`); // Depuração
                try {
                    const response = await fetch('/api/reauthenticate', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ clientId: client.id })
                    });
                    const result = await response.json();
                    if (!result.success) {
                        appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Falha na reautenticação para Cliente ${client.id}: ${result.message}`, type: 'error' });
                    }
                } catch (error) {
                    appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao reautenticar Cliente ${client.id}: ${error.message}`, type: 'error' });
                }
            };
        }
        updateAvailableClientsForRoutine();
    }

    function updateAvailableClientsForRoutine() {
        console.log('[FRONTEND] Atualizando lista de clientes disponíveis para rotina.'); // Depuração
        availableClientsSelect.innerHTML = '<option value="">Todos os Prontos (Rodízio)</option>';

        readyClientsForRoutine = Object.values(allClients).filter(client =>
            client.status === 'Pronto' && client.phoneNumber && client.phoneNumber !== 'N/A' && client.phoneNumber !== 'Erro ao obter Telefone'
        );

        if (readyClientsForRoutine.length === 0) {
            startRoutineBtn.disabled = true;
            stopRoutineBtn.disabled = true;
            console.log('[FRONTEND] Nenhum cliente pronto para rotina, botões desabilitados.'); // Depuração
            return;
        }

        readyClientsForRoutine.forEach(client => {
            const option = document.createElement('option');
            option.value = client.id;
            option.textContent = `Cliente ${client.id} (${client.phoneNumber})`;
            availableClientsSelect.appendChild(option);
        });

        // Habilita os botões de rotina se houver clientes prontos e a rotina não estiver rodando (estado vem do backend)
        // O status da rotina é atualizado por handleRoutineStatusUpdate
        // Por enquanto, apenas garante que não estão permanentemente desabilitados
        if (!routineStatusSpan.textContent.includes('Ativa')) { // Checa o texto atual, que é atualizado por handleRoutineStatusUpdate
             startRoutineBtn.disabled = false;
        }
        // stopRoutineBtn.disabled é controlado por handleRoutineStatusUpdate
    }

    async function saveLogManually() {
        const logContent = routineLog.innerText;
        if (!logContent) {
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: 'Não há conteúdo no log para salvar manualmente.', type: 'warning' });
            return;
        }
        try {
            const response = await fetch('/api/save-routine-log', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ log: logContent })
            });
            const result = await response.json();
            if (result.success) {
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Log salvo manualmente com sucesso como ${result.filename}`, type: 'success' });
            } else {
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro ao salvar log manualmente: ${result.message}`, type: 'error' });
            }
        } catch (error) {
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao salvar log manualmente: ${error.message}`, type: 'error' });
        }
    }

    async function startRoutineHandler() {
        const selectedClientId = availableClientsSelect.value;
        const rawContacts = contactListInput.value.trim();
        const rawMessages = messageContentsInput.value.trim();
        const minDelay = parseInt(minDelayInput.value);
        const maxDelay = parseInt(maxDelayInput.value);

        if (!rawContacts || !rawMessages) {
            alert('Por favor, preencha a lista de contatos e o conteúdo das mensagens.');
            return;
        }
        if (isNaN(minDelay) || isNaN(maxDelay) || minDelay < 0 || maxDelay < minDelay) {
            alert('Por favor, defina um intervalo de atraso válido (Min >= 0, Max >= Min).');
            return;
        }

        const parsedContacts = rawContacts.split('\n')
                                    .map(line => {
                                        const parts = line.split(',');
                                        return {
                                            nome: parts[0] ? parts[0].trim() : '',
                                            numero: parts[1] ? parts[1].trim() : ''
                                        };
                                    })
                                    .filter(contact => contact.numero !== '');

        const parsedMessages = rawMessages.split('\n')
                                     .map(message => message.trim())
                                     .filter(message => message !== '');

        if (parsedContacts.length === 0) {
            alert('A lista de contatos está vazia ou no formato incorreto. Use: Nome,Número');
            return;
        }
        if (parsedMessages.length === 0) {
            alert('A lista de mensagens está vazia.');
            return;
        }

        console.log('[FRONTEND] Enviando requisição de início de rotina para o backend.'); // Depuração
        try {
            const response = await fetch('/api/routine/start', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contacts: parsedContacts,
                    messages: parsedMessages,
                    selectedClientId: selectedClientId || null,
                    minDelay: minDelay * 1000,
                    maxDelay: maxDelay * 1000
                })
            });
            const result = await response.json();
            if (result.success) {
                routineLog.innerHTML = ''; // Limpa o log no frontend para nova rotina
            } else {
                alert(`Erro ao iniciar rotina: ${result.message}`);
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Falha ao iniciar rotina: ${result.message}`, type: 'error' });
            }
        } catch (error) {
            alert(`Erro de rede ao iniciar rotina: ${error.message}`);
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao iniciar rotina: ${error.message}`, type: 'error' });
        }
    }

    async function stopRoutineHandler() {
        console.log('[FRONTEND] Enviando requisição de parada de rotina para o backend.'); // Depuração
        try {
            const response = await fetch('/api/routine/stop', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            });
            const result = await response.json();
            if (!result.success) {
                alert(`Erro ao parar rotina: ${result.message}`);
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Falha ao parar rotina: ${result.message}`, type: 'error' });
            }
        } catch (error) {
            alert(`Erro de rede ao parar rotina: ${error.message}`);
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao parar rotina: ${error.message}`, type: 'error' });
        }
    }

    function updateProgressBar(currentIndex, totalContacts) {
        if (totalContacts === 0) {
            routineProgressBar.style.width = '0%';
            routineProgressText.textContent = '0/0 (0%)';
            return;
        }
        const percentage = (currentIndex / totalContacts) * 100;
        routineProgressBar.style.width = `${percentage}%`;
        routineProgressText.textContent = `${currentIndex}/${totalContacts} (${percentage.toFixed(2)}%)`;
    }

    function handleRoutineStatusUpdate(status) {
        console.log('[FRONTEND] Recebida atualização de status da rotina:', status); // Depuração
        startRoutineBtn.disabled = status.isRunning;
        stopRoutineBtn.disabled = !status.isRunning;

        routineStatusSpan.textContent = status.isRunning ? 'Ativa' : 'Inativa';
        routineStatusSpan.className = status.isRunning ? 'status-active' : 'status-inactive';

        updateProgressBar(status.currentIndex, status.totalContacts);
    }

    // --- Listeners de Eventos Socket.IO ---
    socket.on('initialClientStatus', (clientsArray) => {
        console.log('[FRONTEND - SOCKET] initialClientStatus recebido:', clientsArray);
        // Limpa clientes existentes e redesenha
        clientsContainer.innerHTML = '';
        allClients = {}; // Limpa o objeto de clientes interno do frontend
        clientsArray.forEach(client => updateClientCard(client));
        console.log('[FRONTEND - SOCKET] Clientes iniciais renderizados.'); // Depuração
    });

    socket.on('clientStatusUpdate', (client) => {
        console.log(`[FRONTEND - SOCKET] clientStatusUpdate recebido para Cliente: ${client.id}. Novo Status: ${client.status}`); // Depuração
        updateClientCard(client);
    });

    socket.on('routineLogUpdate', (logEntry) => {
        appendRoutineLog(logEntry);
    });

    socket.on('routineStatus', (status) => {
        handleRoutineStatusUpdate(status);
    });

    socket.on('readyClientsForRoutine', (clients) => {
        readyClientsForRoutine = clients;
        updateAvailableClientsForRoutine();
        console.log('[FRONTEND - SOCKET] Lista de clientes prontos para rotina atualizada.'); // Depuração
    });

    // --- Listeners de Eventos do DOM ---
    setClientsForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const newNumClients = parseInt(numClientsInput.value);
        console.log(`[FRONTEND] Botão 'Definir Clientes' clicado. Novo número: ${newNumClients}`); // Depuração

        if (isNaN(newNumClients) || newNumClients < 1 || newNumClients > 10) {
            alert('Por favor, insira um número válido de clientes entre 1 e 10.');
            return;
        }

        try {
            const response = await fetch('/api/set-num-clients', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ numClients: newNumClients })
            });
            const result = await response.json();
            if (!result.success) {
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Falha ao definir número de clientes: ${result.message}`, type: 'error' });
            }
        } catch (error) {
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao definir número de clientes: ${error.message}`, type: 'error' });
        }
    });

    startRoutineBtn.addEventListener('click', startRoutineHandler);
    stopRoutineBtn.addEventListener('click', stopRoutineHandler);
    saveLogBtn.addEventListener('click', saveLogManually);

    // --- Inicialização ao Carregar a Página ---
    // Resgatar o número de clientes configurado
    fetch('/api/get-num-clients')
        .then(response => response.json())
        .then(data => {
            if (data && typeof data.numClients === 'number') {
                numClientsInput.value = data.numClients;
                console.log(`[FRONTEND] Número de clientes inicial carregado: ${data.numClients}`); // Depuração
            }
        })
        .catch(error => {
            console.error('[FRONTEND] Erro ao obter número de clientes:', error);
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro ao obter número de clientes: ${error.message}`, type: 'error' });
        });

    // NOVO: Resgatar o estado da rotina ao carregar a página
    fetch('/api/routine/status')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.status) {
                const status = data.status;
                if (status.isRunning) {
                    // Preenche os campos se a rotina estava ativa
                    contactListInput.value = status.contactsList.map(c => `${c.nome},${c.numero}`).join('\n');
                    messageContentsInput.value = status.messagesList.join('\n');
                    minDelayInput.value = status.minDelay / 1000;
                    maxDelayInput.value = status.maxDelay / 1000;
                    availableClientsSelect.value = status.selectedClientId || '';

                    routineLog.innerHTML = ''; // Limpa antes de repopular
                    status.logMessages.forEach(logEntry => appendRoutineLog(logEntry));
                    
                    handleRoutineStatusUpdate(status);
                    appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: 'Rotina resgatada do servidor.', type: 'info' });
                    console.log('[FRONTEND] Rotina resgatada do servidor.'); // Depuração
                } else {
                    handleRoutineStatusUpdate(status);
                    console.log('[FRONTEND] Nenhuma rotina ativa para resgatar.'); // Depuração
                }
            }
        })
        .catch(error => {
            console.error('[FRONTEND] Erro ao resgatar status da rotina:', error);
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro ao resgatar status da rotina: ${error.message}`, type: 'error' });
        });

    // Solicita o status inicial dos clientes e clientes prontos para a rotina
    socket.emit('requestInitialClientStatus');
    socket.emit('requestReadyClients');
    console.log('[FRONTEND] Solicitadas informações iniciais do cliente e rotina via Socket.IO.'); // Depuração
});