document.addEventListener('DOMContentLoaded', () => {
    const socket = io();

    // Elementos do Formulário de Mensagem Manual
    const clientSelect = document.getElementById('client-select');
    const numberInput = document.getElementById('number-input');
    const messageInput = document.getElementById('message-input');
    const sendMessageForm = document.getElementById('send-message-form');
    const sendMessageStatusDiv = document.getElementById('send-message-status');
    const contactSelect = document.getElementById('contact-select');
    const messageSelect = document.getElementById('message-select');

    // Elementos para o Card de QR Code Individual
    const qrClientSelect = document.getElementById('qr-client-select');
    const qrDisplayCard = document.getElementById('qr-display-card');

    // Elementos da Rotina de Envio
    const startRoutineButton = document.getElementById('start-routine-button');
    const routineMessageSelect = document.getElementById('routine-message-select');
    const minTimeInput = document.getElementById('min-time');
    const maxTimeInput = document.getElementById('max-time');
    const readyClientsPrompt = document.getElementById('ready-clients-prompt');
    const routineLog = document.getElementById('routine-log');
    const debugReadyClientsDiv = document.getElementById('debug-ready-clients'); // Elemento de debug

    // Elementos de Configuração de Clientes
    const numClientsSelect = document.getElementById('num-clients-select');
    const saveNumClientsButton = document.getElementById('save-num-clients-button');
    const clientConfigStatusDiv = document.getElementById('client-config-status');

    // Armazena o estado completo de todos os clientes no front-end
    let clientsState = {};
    let currentSelectedQrClientId = null;
    let routineIsRunning = false;
    let availableReadyClients = []; // Variável para armazenar os clientes prontos recebidos

    // Variável para a lógica de round-robin na rotina
    let lastUsedClientIndex = 0;
    // Constante para o número máximo de tentativas por contato antes de pular
    const MAX_RETRIES_PER_CONTACT = 3; 

    // --- BASE DE DADOS FICTÍCIA DE CONTATOS ---
    const contacts = [
        { nome: 'Move360', telefone: '554789168420' },
        { nome: 'NLR', telefone: '554784337343' },
        { nome: 'Errado', telefone: '554755555555' },
        { nome: 'Mae', telefone: '554797600064' },
    ];

    // --- BASE DE DADOS FICTÍCIA DE MENSAGENS (COM CAMPO 'props' VAZIO) ---
    const messages = [
        {
            id: 'saudacao_nova_compra',
            mensagem: `Olá! 👋 Agradecemos sua recente compra conosco.
Sua satisfação é nossa prioridade.
Qualquer dúvida ou feedback, estamos à disposição.
Tenha um ótimo dia! ✨`,
            props: ''
        },
        {
            id: 'lembrete_pagamento',
            mensagem: `🔔 Lembrete de pagamento: Sua fatura no valor de R$XX,XX vence em DD/MM.
Evite multas e juros.
Acesse nosso portal para mais detalhes ou entre em contato.
Obrigado! 🙏`,
            props: ''
        },
        {
            id: 'confirmacao_agendamento',
            mensagem: `✅ Confirmação de agendamento:
Seu horário com [Nome do Profissional] foi marcado para DD/MM às HH:MM.
Pedimos que chegue com 10 minutos de antecedência.
Até breve! 🗓️`,
            props: ''
        },
        {
            id: 'oferta_especial',
            mensagem: `🎉 Nova oferta exclusiva para você!
Use o código *DESCONTO20* e ganhe 20% OFF em sua próxima compra.
Válido até DD/MM. Não perca! 🎁
Acesse: [Link da Loja]`,
            props: ''
        },
        {
            id: 'suporte_tecnico',
            mensagem: `🛠️ Olá! Recebemos sua solicitação de suporte.
Nosso time técnico está analisando seu caso (#ABC123).
Em breve entraremos em contato com uma solução.
Agradecemos a paciência! 🧑‍💻`,
            props: ''
        },
        {
            id: 'pesquisa_satisfacao',
            mensagem: `Queremos ouvir você! 🗣️
Sua opinião é muito importante para melhorarmos nossos serviços.
Responda nossa breve pesquisa de satisfação:
[Link da Pesquisa]
Muito obrigado! 🙏`,
            props: ''
        },
        {
            id: 'boas_vindas_plataforma',
            mensagem: `Bem-vindo(a) à nossa plataforma! 🚀
Estamos felizes em tê-lo(a) conosco.
Explore todas as funcionalidades e descubra como podemos te ajudar.
Se precisar de algo, é só chamar! 💡`,
            props: ''
        },
        {
            id: 'avisos_manutencao',
            mensagem: `⚠️ Aviso Importante:
Informamos que haverá uma manutenção programada em nossos sistemas na data DD/MM, das HH:MM às HH:MM.
Durante este período, alguns serviços podem estar indisponíveis.
Agradecemos a compreensão. 🔧`,
            props: ''
        },
        {
            id: 'feliz_aniversario',
            mensagem: `🥳 Feliz Aniversário, [Nome do Cliente]!
Que seu dia seja repleto de alegria e realizações.
Para celebrar, temos um presente especial para você: use o código *ANIVERSARIO10* para 10% de desconto! 🎂`,
            props: ''
        },
        {
            id: 'pedido_entregue',
            mensagem: `📦 Seu pedido (#XYZ987) foi entregue com sucesso!
Esperamos que você aproveite seus novos itens.
Deixe sua avaliação e nos ajude a crescer! ⭐⭐⭐⭐⭐
Qualquer problema, estamos aqui!`,
            props: ''
        }
    ];

    // Funções para popular os dropdowns
    function populateContactsDropdown() {
        contactSelect.innerHTML = '<option value="">Selecione um contato</option>';
        contacts.forEach(contact => {
            const option = document.createElement('option');
            option.value = contact.telefone;
            option.textContent = `${contact.nome} (${contact.telefone})`;
            contactSelect.appendChild(option);
        });
    }

    function populateMessagesDropdowns() {
        messageSelect.innerHTML = '<option value="">Selecione uma mensagem</option>';
        routineMessageSelect.innerHTML = '<option value="">Selecione a mensagem da rotina</option>';

        messages.forEach(msg => {
            const optionManual = document.createElement('option');
            optionManual.value = msg.mensagem;
            optionManual.textContent = msg.id.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            messageSelect.appendChild(optionManual);

            const optionRoutine = document.createElement('option');
            optionRoutine.value = msg.mensagem;
            optionRoutine.textContent = msg.id.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            routineMessageSelect.appendChild(optionRoutine);
        });
    }

    // Chamadas iniciais para popular os dropdowns de contatos e mensagens
    populateContactsDropdown();
    populateMessagesDropdowns();

    // Listeners para os dropdowns de seleção
    contactSelect.addEventListener('change', (event) => {
        numberInput.value = event.target.value;
    });

    messageSelect.addEventListener('change', (event) => {
        messageInput.value = event.target.value;
    });

    /**
     * Atualiza o card de exibição do QR Code/Status.
     * @param {object} clientInfo Informações do cliente a serem exibidas.
     */
    function updateQrDisplayCard(clientInfo) {
        console.log('[SCRIPT][updateQrDisplayCard] Chamado para Cliente:', clientInfo ? clientInfo.id : 'N/A', 'Status:', clientInfo ? clientInfo.status : 'N/A');
        if (!clientInfo) {
            qrDisplayCard.innerHTML = '<p>Selecione um cliente acima para ver seu status e QR Code.</p>';
            return;
        }

        const showAuthButton = ['QR_CODE', 'Desconectado', 'Falha na Autenticação', 'Erro de Inicialização', 'Erro ao Reautenticar', 'Erro de Comunicação', 'Removido'].includes(clientInfo.status);
        const buttonText = clientInfo.status === 'QR_CODE' ? 'Autenticar' : 'Reautenticar';

        qrDisplayCard.innerHTML = `
            <h3>Cliente ${clientInfo.id} (${clientInfo.name})</h3>
            <p>Status: <span class="status-${clientInfo.status.toLowerCase().replace(/ /g, '-')}">${clientInfo.status}</span></p>
            <p>Sessão: <code>${clientInfo.sessionDir || 'N/A'}</code></p>
            <div class="qr-code-area">
                ${clientInfo.status === 'QR_CODE' && clientInfo.qr
                    ? `<img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(clientInfo.qr)}" alt="QR Code para Cliente ${clientInfo.id}">`
                    : (clientInfo.status === 'QR_CODE' && !clientInfo.qr
                        ? '<p>Aguardando QR Code...</p>'
                        : ''
                    )
                }
            </div>
            ${showAuthButton
                ? `<button class="auth-button" data-client-id="${clientInfo.id}">${buttonText}</button>`
                : ''
            }
        `;

        if (showAuthButton) {
            const authButton = qrDisplayCard.querySelector('.auth-button');
            if (authButton) {
                authButton.addEventListener('click', () => {
                    handleReauthenticate(clientInfo.id);
                });
            }
        }
    }

    /**
     * Lida com o clique no botão de reautenticação.
     * @param {number} clientId O ID do cliente a ser reautenticado.
     */
    async function handleReauthenticate(clientId) {
        console.log(`[SCRIPT][handleReauthenticate] Tentando reautenticar Cliente ${clientId}`);
        const currentClientInfo = clientsState[clientId];
        if (currentClientInfo) {
            updateQrDisplayCard({ ...currentClientInfo, status: 'Reautenticando', qr: null });
        }

        try {
            const response = await fetch('/api/reauthenticate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ clientId: clientId }),
            });

            const result = await response.json();

            if (result.success) {
                console.log(`[SCRIPT][handleReauthenticate] Sucesso: ${result.message}`);
                // A atualização do status virá via Socket.IO
            } else {
                console.error(`[SCRIPT][handleReauthenticate] Erro ao reautenticar cliente ${clientId}:`, result.message);
                if (currentClientInfo) {
                    updateQrDisplayCard({ ...currentClientInfo, status: 'Erro ao Reautenticar', qr: null });
                }
                alert(`Erro ao reautenticar Cliente ${clientId}: ${result.message}`);
            }
        } catch (error) {
            console.error(`[SCRIPT][handleReauthenticate] Erro na requisição de reautenticação para o cliente ${clientId}:`, error);
            if (currentClientInfo) {
                updateQrDisplayCard({ ...currentClientInfo, status: 'Erro de Comunicação', qr: null });
            }
            alert(`Erro de comunicação ao tentar reautenticar Cliente ${clientId}. Verifique o console do navegador e do servidor.`);
        }
    }

    /**
     * Atualiza os dropdowns de seleção de cliente.
     * @param {Array} clientsData Array de objetos de status de cliente.
     */
    function updateClientDropdowns(clientsData) {
        console.log('[SCRIPT][updateClientDropdowns] Chamado com', clientsData.length, 'clientes.');
        // Limpa os dropdowns antes de repopular
        qrClientSelect.innerHTML = '<option value="">Selecione um cliente</option>';
        clientSelect.innerHTML = '<option value="">Selecione um cliente pronto</option>';

        clientsState = {}; // Reinicia o objeto clientsState

        if (clientsData.length === 0) {
            qrClientSelect.innerHTML = '<option value="">Nenhum cliente disponível</option>';
            clientSelect.innerHTML = '<option value="">Nenhum cliente pronto</option>';
            updateQrDisplayCard(null); // Limpa o card
            return; // Sai da função
        }

        clientsData.forEach(clientInfo => {
            clientsState[clientInfo.id] = clientInfo;

            const qrOption = document.createElement('option');
            qrOption.value = clientInfo.id;
            qrOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name}) - [${clientInfo.status}]`;
            qrClientSelect.appendChild(qrOption);

            const sendOption = document.createElement('option');
            sendOption.value = clientInfo.id;
            sendOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name})`;
            sendOption.disabled = (clientInfo.status !== 'Pronto');
            clientSelect.appendChild(sendOption);
        });

        // Restaura a seleção se o cliente ainda existir, ou seleciona o primeiro
        if (currentSelectedQrClientId && clientsState[currentSelectedQrClientId]) {
            qrClientSelect.value = currentSelectedQrClientId;
        } else if (clientsData.length > 0) {
            currentSelectedQrClientId = clientsData[0].id; // Seleciona o primeiro cliente como padrão
            qrClientSelect.value = currentSelectedQrClientId;