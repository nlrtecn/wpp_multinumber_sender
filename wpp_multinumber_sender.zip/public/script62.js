document.addEventListener('DOMContentLoaded', () => {
    const socket = io(); // Conecta ao servidor Socket.IO

    const clientsContainer = document.getElementById('clients-container');
    const setClientsForm = document.getElementById('set-clients-form');
    const numClientsInput = document.getElementById('numClients');
    
    const contactListInput = document.getElementById('contactList');
    const messageContentsInput = document.getElementById('messageContents');

    const startRoutineBtn = document.getElementById('startRoutineBtn');
    const stopRoutineBtn = document.getElementById('stopRoutineBtn');
    const routineLog = document.getElementById('routineLog');
    const saveLogBtn = document.getElementById('saveLogBtn'); // Manter para salvamento manual, se desejar
    const routineStatusSpan = document.getElementById('routineStatus');
    const availableClientsSelect = document.getElementById('availableClients');
    const routineProgressBar = document.getElementById('routineProgressBar');
    const routineProgressText = document.getElementById('routineProgressText');
    const minDelayInput = document.getElementById('minDelay');
    const maxDelayInput = document.getElementById('maxDelay');

    let allClients = {}; // Mantém o estado dos clientes para exibir na UI
    let readyClientsForRoutine = []; // Clientes prontos para preencher o select

    // --- Funções de Utilitário do Frontend ---

    /**
     * Adiciona uma mensagem ao log da rotina.
     * @param {object} logEntry - Objeto { timestamp, message, type }.
     */
    function appendRoutineLog(logEntry) {
        const p = document.createElement('p');
        p.textContent = `[${logEntry.timestamp}] ${logEntry.message}`;
        p.classList.add(`log-${logEntry.type}`);
        routineLog.appendChild(p);
        routineLog.scrollTop = routineLog.scrollHeight;
    }

    /**
     * Atualiza a exibição de um card de cliente individual.
     * @param {object} client - O objeto cliente com as informações atualizadas.
     */
    function updateClientCard(client) {
        let clientCard = document.getElementById(`client-card-${client.id}`);

        if (!clientCard) {
            clientCard = document.createElement('div');
            clientCard.id = `client-card-${client.id}`;
            clientCard.classList.add('client-card');
            clientsContainer.appendChild(clientCard);
        }

        if (client.status === 'Removido') {
            if (clientCard) clientCard.remove();
            delete allClients[client.id];
            updateAvailableClientsForRoutine();
            // Nao emite log aqui, pois ja vem do backend ou eh acao local do frontend
            return;
        }

        allClients[client.id] = { ...allClients[client.id], ...client };

        clientCard.innerHTML = `
            <h3>Cliente ${client.id}</h3>
            <p><strong>Nome:</strong> ${client.name}</p>
            <p><strong>Status:</strong> <span id="status-${client.id}">${client.status}</span></p>
            <p><strong>Telefone:</strong> <span id="phone-${client.id}">${client.phoneNumber || 'N/A'}</span></p>
            <div class="qr-code-area" id="qr-area-${client.id}">
                ${client.status === 'QR_CODE' && client.qr ?
                    `<img src="${client.qr}" alt="QR Code para Cliente ${client.id}" style="width: 200px; height: 200px; display: block;">` :
                    `<p>${client.status === 'Pronto' ? 'Conectado!' : 'Aguardando QR Code...'}</p>`
                }
            </div>
            <button class="reauthenticate-btn" data-client-id="${client.id}" ${client.status === 'Conectado' || client.status === 'Autenticado' || client.status === 'Pronto' ? '' : 'disabled'}>Reautenticar</button>
        `;

        const reauthenticateBtn = clientCard.querySelector(`.reauthenticate-btn`);
        if (reauthenticateBtn) {
            reauthenticateBtn.onclick = async () => {
                // emitLog(`Solicitando reautenticação para Cliente ${client.id}...`, 'info'); // Log é feito no backend agora
                try {
                    const response = await fetch('/api/reauthenticate', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ clientId: client.id })
                    });
                    const result = await response.json();
                    // O log de sucesso/falha da reautenticação virá do backend via Socket.IO
                } catch (error) {
                    // Este erro é de rede/fetch, o backend nao recebeu a requisicao
                    appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao reautenticar Cliente ${client.id}: ${error.message}`, type: 'error' });
                }
            };
        }

        updateAvailableClientsForRoutine();
    }

    /**
     * Atualiza a lista de clientes disponíveis para a rotina de envio.
     */
    function updateAvailableClientsForRoutine() {
        availableClientsSelect.innerHTML = '<option value="">Todos os Prontos (Rodízio)</option>';

        readyClientsForRoutine = Object.values(allClients).filter(client =>
            client.status === 'Pronto' && client.phoneNumber && client.phoneNumber !== 'N/A' && client.phoneNumber !== 'Erro ao obter Telefone'
        );

        if (readyClientsForRoutine.length === 0) {
            // Log de warning deve vir do backend ou ser emitido apenas na inicializacao.
            // appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: 'Nenhum cliente pronto para a rotina de envio.', type: 'warning' });
            startRoutineBtn.disabled = true;
            stopRoutineBtn.disabled = true;
            return;
        }

        readyClientsForRoutine.forEach(client => {
            const option = document.createElement('option');
            option.value = client.id;
            option.textContent = `Cliente ${client.id} (${client.phoneNumber})`;
            availableClientsSelect.appendChild(option);
        });

        // Botões habilitados/desabilitados dependem do estado da rotina, que vem do backend
        // e é processado em handleRoutineStatusUpdate
    }

    /**
     * Função para salvar o log da rotina manualmente (se ainda for necessário).
     * Nota: O salvamento automático agora é feito no backend.
     */
    async function saveLogManually() {
        // Obter o conteúdo do log atual no frontend
        const logContent = routineLog.innerText;
        if (!logContent) {
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: 'Não há conteúdo no log para salvar manualmente.', type: 'warning' });
            return;
        }

        try {
            // Envia o conteúdo do log para o backend para salvar
            const response = await fetch('/api/save-routine-log', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ log: logContent }) // Envia o texto bruto do log
            });
            const result = await response.json();
            if (result.success) {
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Log salvo manualmente com sucesso como ${result.filename}`, type: 'success' });
            } else {
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro ao salvar log manualmente: ${result.message}`, type: 'error' });
            }
        } catch (error) {
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao salvar log manualmente: ${error.message}`, type: 'error' });
        }
    }


    /**
     * Lida com o início da rotina, enviando dados para o backend.
     */
    async function startRoutineHandler() {
        const selectedClientId = availableClientsSelect.value;
        const rawContacts = contactListInput.value.trim();
        const rawMessages = messageContentsInput.value.trim();
        const minDelay = parseInt(minDelayInput.value);
        const maxDelay = parseInt(maxDelayInput.value);

        if (!rawContacts || !rawMessages) {
            alert('Por favor, preencha a lista de contatos e o conteúdo das mensagens.');
            return;
        }
        if (isNaN(minDelay) || isNaN(maxDelay) || minDelay < 0 || maxDelay < minDelay) {
            alert('Por favor, defina um intervalo de atraso válido (Min >= 0, Max >= Min).');
            return;
        }

        const parsedContacts = rawContacts.split('\n')
                                    .map(line => {
                                        const parts = line.split(',');
                                        return {
                                            nome: parts[0] ? parts[0].trim() : '',
                                            numero: parts[1] ? parts[1].trim() : ''
                                        };
                                    })
                                    .filter(contact => contact.numero !== '');

        const parsedMessages = rawMessages.split('\n')
                                     .map(message => message.trim())
                                     .filter(message => message !== '');

        if (parsedContacts.length === 0) {
            alert('A lista de contatos está vazia ou no formato incorreto. Use: Nome,Número');
            return;
        }
        if (parsedMessages.length === 0) {
            alert('A lista de mensagens está vazia.');
            return;
        }

        try {
            const response = await fetch('/api/routine/start', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contacts: parsedContacts,
                    messages: parsedMessages,
                    selectedClientId: selectedClientId || null, // Envia null se for rodízio
                    minDelay: minDelay * 1000, // Converter para milissegundos
                    maxDelay: maxDelay * 1000  // Converter para milissegundos
                })
            });
            const result = await response.json();
            if (result.success) {
                // O log e o status serão atualizados pelo Socket.IO vindo do backend
                // Limpar o log aqui para a nova rotina
                routineLog.innerHTML = '';
            } else {
                alert(`Erro ao iniciar rotina: ${result.message}`);
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Falha ao iniciar rotina: ${result.message}`, type: 'error' });
            }
        } catch (error) {
            alert(`Erro de rede ao iniciar rotina: ${error.message}`);
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao iniciar rotina: ${error.message}`, type: 'error' });
        }
    }

    /**
     * Lida com a parada da rotina, enviando comando para o backend.
     */
    async function stopRoutineHandler() {
        try {
            const response = await fetch('/api/routine/stop', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' }
            });
            const result = await response.json();
            if (!result.success) {
                alert(`Erro ao parar rotina: ${result.message}`);
                appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Falha ao parar rotina: ${result.message}`, type: 'error' });
            }
            // O log e o status serão atualizados pelo Socket.IO vindo do backend
        } catch (error) {
            alert(`Erro de rede ao parar rotina: ${error.message}`);
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao parar rotina: ${error.message}`, type: 'error' });
        }
    }

    /**
     * Atualiza a barra de progresso da rotina.
     * @param {number} currentIndex - Índice atual.
     * @param {number} totalContacts - Total de contatos.
     */
    function updateProgressBar(currentIndex, totalContacts) {
        if (totalContacts === 0) {
            routineProgressBar.style.width = '0%';
            routineProgressText.textContent = '0/0 (0%)';
            return;
        }

        const percentage = (currentIndex / totalContacts) * 100;
        routineProgressBar.style.width = `${percentage}%`;
        routineProgressText.textContent = `${currentIndex}/${totalContacts} (${percentage.toFixed(2)}%)`;
    }

    /**
     * Lida com as atualizações de status da rotina vindas do backend.
     * @param {object} status - Objeto de status da rotina.
     */
    function handleRoutineStatusUpdate(status) {
        // Atualiza botões
        startRoutineBtn.disabled = status.isRunning;
        stopRoutineBtn.disabled = !status.isRunning;

        // Atualiza status text e classe
        routineStatusSpan.textContent = status.isRunning ? 'Ativa' : 'Inativa';
        routineStatusSpan.className = status.isRunning ? 'status-active' : 'status-inactive';

        // Atualiza barra de progresso
        updateProgressBar(status.currentIndex, status.totalContacts);
    }


    // --- Listeners de Eventos Socket.IO ---

    socket.on('initialClientStatus', (clientsArray) => {
        console.log('[SOCKET] initialClientStatus recebido:', clientsArray);
        // Limpa clientes existentes e redesenha
        clientsContainer.innerHTML = '';
        allClients = {}; // Limpa o objeto de clientes
        clientsArray.forEach(client => updateClientCard(client));
    });

    socket.on('clientStatusUpdate', (client) => {
        console.log(`[SOCKET] clientStatusUpdate recebido para Cliente: ${client.id} Status: ${client.status}`);
        updateClientCard(client);
    });

    // O frontend agora recebe objetos de log, não apenas strings
    socket.on('routineLogUpdate', (logEntry) => {
        appendRoutineLog(logEntry);
    });

    socket.on('routineStatus', (status) => {
        console.log('[SOCKET] routineStatus recebido:', status);
        handleRoutineStatusUpdate(status);
    });

    socket.on('readyClientsForRoutine', (clients) => {
        readyClientsForRoutine = clients;
        updateAvailableClientsForRoutine();
    });

    // --- Listeners de Eventos do DOM ---

    setClientsForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const newNumClients = parseInt(numClientsInput.value);
        if (isNaN(newNumClients) || newNumClients < 1 || newNumClients > 10) {
            alert('Por favor, insira um número válido de clientes entre 1 e 10.');
            return;
        }

        try {
            const response = await fetch('/api/set-num-clients', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ numClients: newNumClients })
            });
            const result = await response.json();
            // O log de sucesso/falha virá do backend via Socket.IO
        } catch (error) {
            appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro de rede ao definir número de clientes: ${error.message}`, type: 'error' });
        }
    });

    startRoutineBtn.addEventListener('click', startRoutineHandler);
    stopRoutineBtn.addEventListener('click', stopRoutineHandler);

    saveLogBtn.addEventListener('click', saveLogManually); // Opcional: manter o botão para salvar log manualmente

    // --- Inicialização ao Carregar a Página ---
    // Resgatar o número de clientes configurado
    fetch('/api/get-num-clients')
        .then(response => response.json())
        .then(data => {
            if (data && typeof data.numClients === 'number') {
                numClientsInput.value = data.numClients;
            }
        })
        .catch(error => console.error('Erro ao obter número de clientes:', error));

    // NOVO: Resgatar o estado da rotina ao carregar a página
    fetch('/api/routine/status')
        .then(response => response.json())
        .then(data => {
            if (data.success && data.status) {
                const status = data.status;
                // Preenche os campos se a rotina estava ativa
                if (status.isRunning) {
                    // O backend agora armazena contactsList e messagesList
                    contactListInput.value = status.contactsList.map(c => `${c.nome},${c.numero}`).join('\n');
                    messageContentsInput.value = status.messagesList.join('\n');
                    minDelayInput.value = status.minDelay / 1000; // Converte de ms para segundos
                    maxDelayInput.value = status.maxDelay / 1000; // Converte de ms para segundos
                    availableClientsSelect.value = status.selectedClientId || ''; // Seleciona o cliente

                    // Repopula o log com as mensagens salvas no estado do backend
                    routineLog.innerHTML = ''; // Limpa antes de repopular
                    status.logMessages.forEach(logEntry => appendRoutineLog(logEntry));
                    
                    // Atualiza a barra de progresso e o status
                    handleRoutineStatusUpdate(status);
                    appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: 'Rotina resgatada do servidor.', type: 'info' });
                } else {
                    // Se não estava rodando, apenas garante que a UI reflita isso
                    handleRoutineStatusUpdate(status);
                }
            }
        })
        .catch(error => appendRoutineLog({ timestamp: new Date().toLocaleTimeString(), message: `Erro ao resgatar status da rotina: ${error.message}`, type: 'error' }));


    // Solicita o status inicial dos clientes e clientes prontos para a rotina
    // Isso pode ser chamado após o resgate da rotina para garantir que os clientes estão atualizados
    socket.emit('requestInitialClientStatus');
    socket.emit('requestReadyClients');
});