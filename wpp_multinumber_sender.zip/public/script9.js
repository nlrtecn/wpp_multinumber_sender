document.addEventListener('DOMContentLoaded', () => {
    const socket = io();
    const clientListDiv = document.getElementById('client-list');
    const clientSelect = document.getElementById('client-select');
    const sendMessageForm = document.getElementById('send-message-form');
    const sendMessageStatusDiv = document.getElementById('send-message-status');

    // Armazena o estado dos clientes no front-end
    const clientsState = {}; 

    /**
     * Renderiza ou atualiza o card de um cliente na interface.
     * @param {object} clientInfo Informações do cliente (id, name, status, qr, sessionDir)
     */
    function renderClientCard(clientInfo) {
        let clientCard = document.getElementById(`client-card-${clientInfo.id}`);
        if (!clientCard) {
            clientCard = document.createElement('div');
            clientCard.id = `client-card-${clientInfo.id}`;
            clientCard.classList.add('client-card');
            // Remove a mensagem de "Carregando" se ainda estiver lá
            if (clientListDiv.querySelector('p')) {
                clientListDiv.innerHTML = '';
            }
            clientListDiv.appendChild(clientCard);
        }

        const showAuthButton = ['QR_CODE', 'Desconectado', 'Falha na Autenticação', 'Erro de Inicialização', 'Erro ao Reautenticar', 'Erro de Comunicação'].includes(clientInfo.status);
        const buttonText = clientInfo.status === 'QR_CODE' ? 'Autenticar' : 'Reautenticar';

        // Construção do HTML do card
        clientCard.innerHTML = `
            <h3>Cliente ${clientInfo.id} (${clientInfo.name})</h3>
            <p>Status: <span class="status-${clientInfo.status.toLowerCase().replace(/ /g, '-')}">${clientInfo.status}</span></p>
            <p>Sessão: <code>${clientInfo.sessionDir || 'N/A'}</code></p>
            <div class="auth-area">
                ${showAuthButton 
                    ? `<button class="auth-button" data-client-id="${clientInfo.id}">${buttonText}</button>`
                    : ''
                }
            </div>
            <div class="qr-image-display" id="qr-display-${clientInfo.id}">
                </div>
        `;

        // Lógica para o botão de autenticação/reautenticação
        if (showAuthButton) {
            const authButton = clientCard.querySelector('.auth-button');
            if (authButton) {
                authButton.addEventListener('click', () => {
                    // Ao clicar no botão, se for QR_CODE, exibe o QR no próprio card
                    if (clientInfo.status === 'QR_CODE' && clientInfo.qr) {
                        displayQrInCard(clientInfo.id, clientInfo.qr);
                    } else {
                        // Caso contrário (desconectado, falha, etc.), tenta reautenticar
                        handleReauthenticate(clientInfo.id);
                    }
                });
            }
        }
        
        // Se o cliente já está em QR_CODE e tem o QR, exibe-o imediatamente
        // Isso é útil se a página for recarregada e o cliente já estava esperando QR.
        if (clientInfo.status === 'QR_CODE' && clientInfo.qr) {
            displayQrInCard(clientInfo.id, clientInfo.qr);
        } else {
            // Se não é QR_CODE, limpa qualquer QR code que possa estar sendo exibido
            const qrDisplayArea = document.getElementById(`qr-display-${clientInfo.id}`);
            if (qrDisplayArea) {
                qrDisplayArea.innerHTML = '';
            }
        }


        // Adiciona/atualiza a opção no select de envio de mensagem
        let option = clientSelect.querySelector(`option[value="${clientInfo.id}"]`);
        if (!option) {
            option = document.createElement('option');
            option.value = clientInfo.id;
            clientSelect.appendChild(option);
        }
        option.textContent = `Cliente ${clientInfo.id} (${clientInfo.name}) - [${clientInfo.status}]`;
        option.disabled = (clientInfo.status !== 'Pronto'); // Desabilita se não estiver pronto
    }

    /**
     * Exibe o QR Code dentro do card do cliente.
     * @param {number} clientId O ID do cliente.
     * @param {string} qrData O dado do QR Code.
     */
    function displayQrInCard(clientId, qrData) {
        const qrDisplayArea = document.getElementById(`qr-display-${clientId}`);
        if (qrDisplayArea) {
            qrDisplayArea.innerHTML = `<img src="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(qrData)}" alt="QR Code para Cliente ${clientId}">`;
        }
    }


    /**
     * Lida com o clique no botão de reautenticação.
     * @param {number} clientId O ID do cliente a ser reautenticado.
     */
    async function handleReauthenticate(clientId) {
        const clientCard = document.getElementById(`client-card-${clientId}`);
        const authButton = clientCard ? clientCard.querySelector('.auth-button') : null;
        
        if (authButton) {
            authButton.disabled = true;
            authButton.textContent = 'Reautenticando...';
        }

        const currentClientInfo = clientsState[clientId];
        if (currentClientInfo) {
            renderClientCard({ ...currentClientInfo, status: 'Reautenticando', qr: null });
        }

        try {
            const response = await fetch('/api/reauthenticate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ clientId: clientId }),
            });

            const result = await response.json();

            if (result.success) {
                console.log(result.message);
                // O status real será atualizado pelo Socket.IO (QR_CODE, Pronto, etc.)
            } else {
                console.error(`Erro ao reautenticar cliente ${clientId}:`, result.message);
                if (authButton) {
                    authButton.disabled = false;
                    authButton.textContent = 'Reautenticar';
                }
                if (currentClientInfo) {
                    renderClientCard({ ...currentClientInfo, status: 'Erro ao Reautenticar', qr: null });
                }
                alert(`Erro ao reautenticar Cliente ${clientId}: ${result.message}`);
            }
        } catch (error) {
            console.error(`Erro na requisição de reautenticação para o cliente ${clientId}:`, error);
            if (authButton) {
                authButton.disabled = false;
                authButton.textContent = 'Reautenticar';
            }
            if (currentClientInfo) {
                renderClientCard({ ...currentClientInfo, status: 'Erro de Comunicação', qr: null });
            }
            alert(`Erro de comunicação ao tentar reautenticar Cliente ${clientId}. Verifique o console do navegador e do servidor.`);
        }
    }

    // Não há mais funções openQrModal e closeQrModal, pois o modal foi removido.
    // Nem listeners para fechar modal.

    // --- Socket.IO Event Listeners ---

    // Recebe o status inicial de todos os clientes ao conectar
    socket.on('initialClientStatus', (initialData) => {
        clientListDiv.innerHTML = ''; // Limpa a mensagem de carregamento inicial
        clientSelect.innerHTML = '<option value="">Selecione um cliente</option>'; // Limpa as opções
        initialData.forEach(clientInfo => {
            clientsState[clientInfo.id] = clientInfo; // Armazena o estado
            renderClientCard(clientInfo);
        });
    });

    // Recebe atualizações de status de clientes individuais
    socket.on('clientStatusUpdate', (updatedClientInfo) => {
        clientsState[updatedClientInfo.id] = updatedClientInfo; // Atualiza o estado
        renderClientCard(updatedClientInfo);
    });

    // --- Formulário de Envio de Mensagem ---
    sendMessageForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        sendMessageStatusDiv.textContent = 'Enviando mensagem...';
        sendMessageStatusDiv.className = 'status-message info';

        const formData = new FormData(sendMessageForm);
        const clientId = formData.get('clientId');
        const number = formData.get('number');
        const message = formData.get('message');

        try {
            const response = await fetch('/api/send-message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ clientId, number, message }),
            });

            const result = await response.json();

            if (result.success) {
                sendMessageStatusDiv.textContent = result.message;
                sendMessageStatusDiv.className = 'status-message success';
                sendMessageForm.reset();
            } else {
                sendMessageStatusDiv.textContent = `Erro: ${result.message}`;
                sendMessageStatusDiv.className = 'status-message error';
            }
        } catch (error) {
            console.error('Erro ao enviar mensagem:', error);
            sendMessageStatusDiv.textContent = `Erro ao conectar com o servidor: ${error.message}`;
            sendMessageStatusDiv.className = 'status-message error';
        }
    });

    // Requisição inicial para carregar o status dos clientes
    fetch('/api/clients/status')
        .then(response => response.json())
        .then(data => {
            // Só processa se o estado dos clientes ainda estiver vazio (evita duplicação se o socket já inicializou)
            if (Object.keys(clientsState).length === 0) { 
                clientListDiv.innerHTML = ''; 
                clientSelect.innerHTML = '<option value="">Selecione um cliente</option>'; 
                data.forEach(clientInfo => {
                    clientsState[clientInfo.id] = clientInfo;
                    renderClientCard(clientInfo);
                });
            }
        })
        .catch(error => {
            console.error('Erro ao carregar status inicial dos clientes:', error);
            clientListDiv.innerHTML = '<p class="status-message error">Erro ao carregar status dos clientes. Verifique o servidor.</p>';
        });
});