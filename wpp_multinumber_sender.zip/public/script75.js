const socket = io();

let currentClients = [];
let frontendRoutineLogs = [];
let selectedClientId = null; // Para guardar o cliente selecionado para a rotina

// --- Funções de Atualização da UI ---

function displayClients(clientsData) {
    const clientsContainer = document.getElementById('clients-container');
    clientsContainer.innerHTML = ''; // Limpa antes de adicionar

    clientsData.sort((a, b) => parseInt(a.id) - parseInt(b.id)); // Ordena por ID

    clientsData.forEach(client => {
        const clientCard = document.createElement('div');
        clientCard.className = 'client-card';
        clientCard.id = `client-${client.id}`;

        let statusText = client.status;
        let qrCodeDisplay = '';

        if (client.status === 'QR_CODE' && client.qr) {
            qrCodeDisplay = `<img src="${client.qr}" alt="QR Code para Cliente ${client.id}" class="qr-code-img">`;
            statusText = 'Escaneie o QR Code';
        } else if (client.status === 'Pronto') {
            statusText = 'Pronto';
        } else if (client.status === 'Desconectado' || client.status === 'Falha na Autenticação' || client.status === 'Erro') {
            statusText = 'Desconectado / Erro';
        }

        const phoneNumberDisplay = client.phoneNumber && client.phoneNumber !== 'N/A' ? `(${client.phoneNumber})` : '';

        clientCard.innerHTML = `
            <h4>Cliente ${client.id}</h4>
            <p>Status: <span class="status-${client.status.toLowerCase().replace(/ /g, '-') || 'unknown'}">${statusText} ${phoneNumberDisplay}</span></p>
            ${qrCodeDisplay}
            <button class="reauth-btn" data-client-id="${client.id}" ${client.status === 'Pronto' ? 'disabled' : ''}>Reautenticar</button>
            <button class="remove-btn" data-client-id="${client.id}">Remover Cliente</button>
        `;
        clientsContainer.appendChild(clientCard);
    });

    // CRÍTICO: Reanexar listeners após (re)criação dos elementos
    attachClientButtonListeners();
    currentClients = clientsData;
}

// Função para anexar/reanexar listeners aos botões de cliente
function attachClientButtonListeners() {
    document.querySelectorAll('.reauth-btn').forEach(button => {
        // Remover listener anterior para evitar duplicação (boa prática)
        button.removeEventListener('click', handleReauthenticateClick);
        button.addEventListener('click', handleReauthenticateClick);
    });

    document.querySelectorAll('.remove-btn').forEach(button => {
        // Remover listener anterior para evitar duplicação
        button.removeEventListener('click', handleRemoveClientClick);
        button.addEventListener('click', handleRemoveClientClick);
    });
}

// Funções de tratamento de clique separadas para reuso e remoção de listeners
async function handleReauthenticateClick(e) {
    const clientId = parseInt(e.target.dataset.clientId);
    if (confirm(`Tem certeza que deseja reautenticar o Cliente ${clientId}? Isso desconectará a sessão atual.`)) {
        try {
            const response = await fetch('/api/reauthenticate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ clientId })
            });
            const data = await response.json();
            if (!data.success) {
                alert('Erro ao reautenticar: ' + data.message);
            }
        } catch (error) {
            console.error('Erro de rede ao reautenticar:', error);
            alert('Erro de comunicação com o servidor ao reautenticar.');
        }
    }
}

async function handleRemoveClientClick(e) {
    const clientId = parseInt(e.target.dataset.clientId);
    if (confirm(`Tem certeza que deseja remover o Cliente ${clientId} e seus dados de sessão?`)) {
        try {
            // Obtem o número atual de clientes e filtra o cliente a ser removido
            const remainingClients = currentClients.filter(c => c.id !== clientId);
            // O novo número de clientes será o tamanho da lista filtrada
            const newNumClients = remainingClients.length;

            const response = await fetch(`/api/set-num-clients`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ numClients: newNumClients })
            });
            const data = await response.json();
            if (!data.success) {
                alert('Erro ao remover cliente: ' + data.message);
            }
            // A UI será atualizada via `initialClientStatus` e `readyClientsForRoutine`
        } catch (error) {
            console.error('Erro de rede ao remover cliente:', error);
            alert('Erro de comunicação com o servidor ao remover cliente.');
        }
    }
}

function updateReadyClientsDropdown(readyClients) {
    const clientSelect = document.getElementById('selected-client-id');
    const previousSelectedValue = clientSelect.value; // Salva o valor atualmente selecionado

    clientSelect.innerHTML = '<option value="">Automático (alternar entre prontos)</option>';

    readyClients.sort((a, b) => parseInt(a.id) - parseInt(b.id)); // Ordena por ID

    readyClients.forEach(client => {
        const option = document.createElement('option');
        option.value = client.id;
        option.textContent = `Cliente ${client.id} (${client.phoneNumber}) - Pronto`;
        clientSelect.appendChild(option);
    });

    // Tenta restaurar a seleção:
    // 1. Se a rotina está ativa e um cliente específico foi selecionado
    // 2. Ou se o valor previamente selecionado ainda estiver na lista de prontos
    if (selectedClientId && readyClients.some(c => String(c.id) === String(selectedClientId))) {
        clientSelect.value = String(selectedClientId);
    } else if (readyClients.some(c => String(c.id) === previousSelectedValue)) {
        clientSelect.value = previousSelectedValue;
    } else {
        clientSelect.value = ""; // Reseta para "Automático"
    }
}

function updateRoutineUI(status) {
    if (!status) return;

    // Atualiza o painel de status da rotina
    document.getElementById('routine-status-display').textContent = status.isRunning ? 'Em Andamento' : 'Inativa';
    document.getElementById('routine-progress-display').textContent = `${status.currentIndex}/${status.totalContacts}`;
    document.getElementById('routine-success-display').textContent = status.successCount;
    document.getElementById('routine-fail-display').textContent = status.failCount;

    // Atualiza o estado dos botões Iniciar/Parar
    const startButton = document.getElementById('start-routine-btn');
    const stopButton = document.getElementById('stop-routine-btn');

    // Referências aos elementos de input
    const contactsInput = document.getElementById('contacts-input');
    const messagesInput = document.getElementById('messages-input');
    const minDelayInput = document.getElementById('min-delay');
    const maxDelayInput = document.getElementById('max-delay');
    const selectedClientDropdown = document.getElementById('selected-client-id');
    const setNumClientsBtn = document.getElementById('set-num-clients-btn');
    const numClientsInput = document.getElementById('num-clients-input');

    // Array de elementos que podem ser desabilitados/habilitados
    const elementsToDisable = [
        contactsInput, messagesInput, minDelayInput, maxDelayInput,
        selectedClientDropdown, setNumClientsBtn, numClientsInput
    ];

    if (status.isRunning) {
        startButton.disabled = true;
        stopButton.disabled = false;

        // Desabilita os campos de input enquanto a rotina estiver rodando
        elementsToDisable.forEach(el => {
            if (el) el.disabled = true;
        });

        // Preenche os campos se os valores forem diferentes
        const newContactsValue = status.contactsList.map(c => `${c.nome}:${c.numero}`).join('\n');
        if (contactsInput.value !== newContactsValue) {
             contactsInput.value = newContactsValue;
        }

        const newMessagesValue = status.messagesList.join('\n');
        if (messagesInput.value !== newMessagesValue) {
            messagesInput.value = newMessagesValue;
        }

        if (minDelayInput.value !== String(status.minDelay / 1000)) {
            minDelayInput.value = status.minDelay / 1000;
        }
        if (maxDelayInput.value !== String(status.maxDelay / 1000)) {
            maxDelayInput.value = maxDelayInput.value = status.maxDelay / 1000;
        }
        
        // Atualiza a variável global do cliente selecionado pela rotina
        selectedClientId = status.selectedClientId;
        // E atualiza o dropdown para refletir isso
        if (selectedClientId && selectedClientDropdown.value !== String(selectedClientId)) {
            selectedClientDropdown.value = String(selectedClientId);
        } else if (!selectedClientId && selectedClientDropdown.value !== "") {
            selectedClientDropdown.value = ""; // Volta para "Automático"
        }

    } else { // Rotina Inativa
        startButton.disabled = false;
        stopButton.disabled = true;

        // Habilita os campos de input quando a rotina não estiver rodando
        elementsToDisable.forEach(el => {
            if (el) el.disabled = false;
        });
        
        selectedClientId = null; // Resetar a variável global
    }
}

// Função para adicionar um log ao "prompt" (console da UI)
function addRoutineLogToUI(logEntry) {
    const logContainer = document.getElementById('routine-log-output');
    const logElement = document.createElement('p');
    logElement.classList.add(`log-${logEntry.type}`);
    logElement.textContent = `[${logEntry.timestamp}] ${logEntry.message}`;
    logContainer.appendChild(logElement);
    logContainer.scrollTop = logContainer.scrollHeight; // Rolagem automática

    frontendRoutineLogs.push(logEntry); // Armazenar no frontend
}

// --- Eventos Socket.IO ---

socket.on('connect', () => {
    console.log('[FRONTEND - SOCKET.IO] Conectado ao servidor.');
    // O backend já envia todos os estados iniciais (clientes, rotina, logs, prontos) na conexão.
    // Não precisamos solicitar nada aqui.
});

socket.on('disconnect', () => {
    console.log('[FRONTEND - SOCKET.IO] Desconectado do servidor.');
});

socket.on('initialClientStatus', (clientsData) => {
    console.log('[FRONTEND - SOCKET.IO] Initial Client Status Recebido:', clientsData);
    displayClients(clientsData); // Re-renderiza e reanexa listeners
});

socket.on('clientStatusUpdate', (clientData) => {
    console.log('[FRONTEND - SOCKET.IO] Client Status Update Recebido:', clientData);
    const existingClientIndex = currentClients.findIndex(c => c.id === clientData.id);
    if (existingClientIndex > -1) {
        currentClients[existingClientIndex] = clientData;
    } else {
        currentClients.push(clientData);
    }
    displayClients(currentClients); // Re-renderiza e reanexa listeners
});

// Evento para receber a lista de clientes prontos e atualizar o dropdown
socket.on('readyClientsForRoutine', (readyClients) => {
    console.log('[FRONTEND - SOCKET.IO] Ready Clients for Routine Recebido:', readyClients);
    updateReadyClientsDropdown(readyClients);
});

// Evento para receber o status completo da rotina
socket.on('routineStatus', (status) => {
    console.log('[FRONTEND - SOCKET.IO] Rotina Status Recebido:', status);
    updateRoutineUI(status);
    // Limpamos os logs *somente* quando recebemos o status inicial da rotina (ou uma atualização completa),
    // para evitar duplicação de logs históricos que virão em seguida.
    document.getElementById('routine-log-output').innerHTML = '';
    frontendRoutineLogs = [];
});

// Evento para receber logs individuais da rotina
socket.on('routineLogUpdate', (logEntry) => {
    // Adiciona o log sem limpar o conteúdo anterior
    addRoutineLogToUI(logEntry);
});


// --- Listeners de Botões/Inputs Principais (Permanecem aqui) ---

document.getElementById('set-num-clients-btn').addEventListener('click', async () => {
    const numClients = parseInt(document.getElementById('num-clients-input').value);
    if (isNaN(numClients) || numClients < 1 || numClients > 10) {
        alert('Por favor, insira um número válido de clientes (1 a 10).');
        return;
    }
    try {
        const response = await fetch('/api/set-num-clients', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ numClients })
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao definir clientes: ' + (data.message || 'Erro desconhecido.'));
        }
    } catch (error) {
        console.error('Erro ao comunicar com o backend para definir clientes:', error);
        alert('Erro de comunicação com o servidor ao definir clientes.');
    }
});

document.getElementById('start-routine-btn').addEventListener('click', async () => {
    const contactsInput = document.getElementById('contacts-input');
    const messagesInput = document.getElementById('messages-input');
    const minDelayInput = document.getElementById('min-delay');
    const maxDelayInput = document.getElementById('max-delay');
    const selectedClientDropdown = document.getElementById('selected-client-id');

    const contactsText = contactsInput.value;
    const messagesText = messagesInput.value;
    const minDelay = parseInt(minDelayInput.value * 1000); // Converter para ms
    const maxDelay = parseInt(maxDelayInput.value * 1000); // Converter para ms
    const selectedClientIdRaw = selectedClientDropdown.value;
    const selectedClientId = selectedClientIdRaw ? parseInt(selectedClientIdRaw) : null;


    if (!contactsText || !messagesText) {
        alert('Por favor, preencha os contatos e as mensagens.');
        return;
    }

    if (isNaN(minDelay) || isNaN(maxDelay) || minDelay < 1000 || maxDelay < 1000 || minDelay > maxDelay) {
        alert('Por favor, insira um atraso mínimo e máximo válidos (em segundos, mínimo 1).');
        return;
    }

    const contacts = contactsText.split('\n').map(line => {
        const parts = line.split(':');
        if (parts.length >= 2) {
            return { nome: parts[0].trim(), numero: parts[1].trim() };
        }
        return null;
    }).filter(c => c !== null && c.nome && c.numero); // Garante que nome e numero não são vazios

    const messages = messagesText.split('\n').map(msg => msg.trim()).filter(msg => msg !== '');

    if (contacts.length === 0 || messages.length === 0) {
        alert('As listas de contatos ou mensagens estão vazias ou mal formatadas.');
        return;
    }

    try {
        const response = await fetch('/api/routine/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contacts, messages, selectedClientId, minDelay, maxDelay })
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao iniciar rotina: ' + (data.message || 'Erro desconhecido.'));
        }
    } catch (error) {
        console.error('Erro ao comunicar com o backend para iniciar rotina:', error);
        alert('Erro ao iniciar rotina. Verifique o console do servidor.');
    }
});

document.getElementById('stop-routine-btn').addEventListener('click', async () => {
    try {
        const response = await fetch('/api/routine/stop', {
            method: 'POST'
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao parar rotina: ' + (data.message || 'Erro desconhecido.'));
        }
    } catch (error) {
        console.error('Erro ao comunicar com o backend para parar rotina:', error);
        alert('Erro ao parar rotina. Verifique o console do servidor.');
    }
});

// --- Inicialização ao carregar a página ---
document.addEventListener('DOMContentLoaded', () => {
    // Solicita o número de clientes configurados no backend
    fetch('/api/get-num-clients')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('num-clients-input').value = data.numClients;
            }
        })
        .catch(error => console.error('Erro ao obter número de clientes:', error));

    // O status inicial de clientes, rotina e logs será enviado automaticamente pelo backend na conexão do socket.
    // Não precisamos fazer requisições GET adicionais aqui para a rotina.
});