document.addEventListener('DOMContentLoaded', () => {
    const socket = io();

    // Elementos do Formulário de Mensagem Manual
    const clientSelect = document.getElementById('client-select');
    const numberInput = document.getElementById('number-input');
    const messageInput = document.getElementById('message-input');
    const sendMessageForm = document.getElementById('send-message-form');
    const sendMessageStatusDiv = document.getElementById('send-message-status');
    const contactSelect = document.getElementById('contact-select');
    const messageSelect = document.getElementById('message-select');

    // Elementos para o Card de QR Code Individual
    const qrClientSelect = document.getElementById('qr-client-select');
    const qrDisplayCard = document.getElementById('qr-display-card');

    // Elementos da Rotina de Envio
    const startRoutineButton = document.getElementById('start-routine-button');
    const routineMessageSelect = document.getElementById('routine-message-select');
    const minTimeInput = document.getElementById('min-time');
    const maxTimeInput = document.getElementById('max-time');
    const readyClientsPrompt = document.getElementById('ready-clients-prompt');
    const routineLog = document.getElementById('routine-log');
    const debugReadyClientsDiv = document.getElementById('debug-ready-clients'); // Elemento de debug

    // Elementos de Configuração de Clientes
    const numClientsSelect = document.getElementById('num-clients-select');
    const saveNumClientsButton = document.getElementById('save-num-clients-button');
    const clientConfigStatusDiv = document.getElementById('client-config-status');

    // Armazena o estado completo de todos os clientes no front-end
    let clientsState = {};
    let currentSelectedQrClientId = null;
    let routineIsRunning = false;
    let availableReadyClients = []; // Variável para armazenar os clientes prontos recebidos

    // --- BASE DE DADOS FICTÍCIA DE CONTATOS ---
    const contacts = [
        { nome: 'Move360', telefone: '554789168420' },
        { nome: 'NLR', telefone: '554784337343' },
    ];

    // --- BASE DE DADOS FICTÍCIA DE MENSAGENS (COM CAMPO 'props' VAZIO) ---
    const messages = [
        {
            id: 'saudacao_nova_compra',
            mensagem: `Olá! 👋 Agradecemos sua recente compra conosco.
Sua satisfação é nossa prioridade.
Qualquer dúvida ou feedback, estamos à disposição.
Tenha um ótimo dia! ✨`,
            props: ''
        },
        {
            id: 'lembrete_pagamento',
            mensagem: `🔔 Lembrete de pagamento: Sua fatura no valor de R$XX,XX vence em DD/MM.
Evite multas e juros.
Acesse nosso portal para mais detalhes ou entre em contato.
Obrigado! 🙏`,
            props: ''
        },
        {
            id: 'confirmacao_agendamento',
            mensagem: `✅ Confirmação de agendamento:
Seu horário com [Nome do Profissional] foi marcado para DD/MM às HH:MM.
Pedimos que chegue com 10 minutos de antecedência.
Até breve! 🗓️`,
            props: ''
        },
        {
            id: 'oferta_especial',
            mensagem: `🎉 Nova oferta exclusiva para você!
Use o código *DESCONTO20* e ganhe 20% OFF em sua próxima compra.
Válido até DD/MM. Não perca! 🎁
Acesse: [Link da Loja]`,
            props: ''
        },
        {
            id: 'suporte_tecnico',
            mensagem: `🛠️ Olá! Recebemos sua solicitação de suporte.
Nosso time técnico está analisando seu caso (#ABC123).
Em breve entraremos em contato com uma solução.
Agradecemos a paciência! 🧑‍💻`,
            props: ''
        },
        {
            id: 'pesquisa_satisfacao',
            mensagem: `Queremos ouvir você! 🗣️
Sua opinião é muito importante para melhorarmos nossos serviços.
Responda nossa breve pesquisa de satisfação:
[Link da Pesquisa]
Muito obrigado! 🙏`,
            props: ''
        },
        {
            id: 'boas_vindas_plataforma',
            mensagem: `Bem-vindo(a) à nossa plataforma! 🚀
Estamos felizes em tê-lo(a) conosco.
Explore todas as funcionalidades e descubra como podemos te ajudar.
Se precisar de algo, é só chamar! 💡`,
            props: ''
        },
        {
            id: 'avisos_manutencao',
            mensagem: `⚠️ Aviso Importante:
Informamos que haverá uma manutenção programada em nossos sistemas na data DD/MM, das HH:MM às HH:MM.
Durante este período, alguns serviços podem estar indisponíveis.
Agradecemos a compreensão. 🔧`,
            props: ''
        },
        {
            id: 'feliz_aniversario',
            mensagem: `🥳 Feliz Aniversário, [Nome do Cliente]!
Que seu dia seja repleto de alegria e realizações.
Para celebrar, temos um presente especial para você: use o código *ANIVERSARIO10* para 10% de desconto! 🎂`,
            props: ''
        },
        {
            id: 'pedido_entregue',
            mensagem: `📦 Seu pedido (#XYZ987) foi entregue com sucesso!
Esperamos que você aproveite seus novos itens.
Deixe sua avaliação e nos ajude a crescer! ⭐⭐⭐⭐⭐
Qualquer problema, estamos aqui!`,
            props: ''
        }
    ];

    // Funções para popular os dropdowns
    function populateContactsDropdown() {
        contactSelect.innerHTML = '<option value="">Selecione um contato</option>';
        contacts.forEach(contact => {
            const option = document.createElement('option');
            option.value = contact.telefone;
            option.textContent = `${contact.nome} (${contact.telefone})`;
            contactSelect.appendChild(option);
        });
    }

    function populateMessagesDropdowns() {
        messageSelect.innerHTML = '<option value="">Selecione uma mensagem</option>';
        routineMessageSelect.innerHTML = '<option value="">Selecione a mensagem da rotina</option>';

        messages.forEach(msg => {
            const optionManual = document.createElement('option');
            optionManual.value = msg.mensagem;
            optionManual.textContent = msg.id.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            messageSelect.appendChild(optionManual);

            const optionRoutine = document.createElement('option');
            optionRoutine.value = msg.mensagem;
            optionRoutine.textContent = msg.id.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
            routineMessageSelect.appendChild(optionRoutine);
        });
    }

    // Chamadas iniciais para popular os dropdowns de contatos e mensagens
    populateContactsDropdown();
    populateMessagesDropdowns();

    // Listeners para os dropdowns de seleção
    contactSelect.addEventListener('change', (event) => {
        numberInput.value = event.target.value;
    });

    messageSelect.addEventListener('change', (event) => {
        messageInput.value = event.target.value;
    });

    /**
     * Atualiza o card de exibição do QR Code/Status.
     * @param {object} clientInfo Informações do cliente a serem exibidas.
     */
    function updateQrDisplayCard(clientInfo) {
        console.log('[SCRIPT][updateQrDisplayCard] Chamado para Cliente:', clientInfo ? clientInfo.id : 'N/A', 'Status:', clientInfo ? clientInfo.status : 'N/A');
        if (!clientInfo) {
            qrDisplayCard.innerHTML = '<p>Selecione um cliente acima para ver seu status e QR Code.</p>';
            return;
        }

        const showAuthButton = ['QR_CODE', 'Desconectado', 'Falha na Autenticação', 'Erro de Inicialização', 'Erro ao Reautenticar', 'Erro de Comunicação', 'Removido'].includes(clientInfo.status);
        const buttonText = clientInfo.status === 'QR_CODE' ? 'Autenticar' : 'Reautenticar';

        qrDisplayCard.innerHTML = `
            <h3>Cliente ${clientInfo.id} (${clientInfo.name})</h3>
            <p>Status: <span class="status-${clientInfo.status.toLowerCase().replace(/ /g, '-')}">${clientInfo.status}</span></p>
            <p>Sessão: <code>${clientInfo.sessionDir || 'N/A'}</code></p>
            <div class="qr-code-area">
                ${clientInfo.status === 'QR_CODE' && clientInfo.qr
                    ? `<img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(clientInfo.qr)}" alt="QR Code para Cliente ${clientInfo.id}">`
                    : (clientInfo.status === 'QR_CODE' && !clientInfo.qr
                        ? '<p>Aguardando QR Code...</p>'
                        : ''
                    )
                }
            </div>
            ${showAuthButton
                ? `<button class="auth-button" data-client-id="${clientInfo.id}">${buttonText}</button>`
                : ''
            }
        `;

        if (showAuthButton) {
            const authButton = qrDisplayCard.querySelector('.auth-button');
            if (authButton) {
                authButton.addEventListener('click', () => {
                    handleReauthenticate(clientInfo.id);
                });
            }
        }
    }

    /**
     * Lida com o clique no botão de reautenticação.
     * @param {number} clientId O ID do cliente a ser reautenticado.
     */
    async function handleReauthenticate(clientId) {
        console.log(`[SCRIPT][handleReauthenticate] Tentando reautenticar Cliente ${clientId}`);
        const currentClientInfo = clientsState[clientId];
        if (currentClientInfo) {
            updateQrDisplayCard({ ...currentClientInfo, status: 'Reautenticando', qr: null });
        }

        try {
            const response = await fetch('/api/reauthenticate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ clientId: clientId }),
            });

            const result = await response.json();

            if (result.success) {
                console.log(`[SCRIPT][handleReauthenticate] Sucesso: ${result.message}`);
                // A atualização do status virá via Socket.IO
            } else {
                console.error(`[SCRIPT][handleReauthenticate] Erro ao reautenticar cliente ${clientId}:`, result.message);
                if (currentClientInfo) {
                    updateQrDisplayCard({ ...currentClientInfo, status: 'Erro ao Reautenticar', qr: null });
                }
                alert(`Erro ao reautenticar Cliente ${clientId}: ${result.message}`);
            }
        } catch (error) {
            console.error(`[SCRIPT][handleReauthenticate] Erro na requisição de reautenticação para o cliente ${clientId}:`, error);
            if (currentClientInfo) {
                updateQrDisplayCard({ ...currentClientInfo, status: 'Erro de Comunicação', qr: null });
            }
            alert(`Erro de comunicação ao tentar reautenticar Cliente ${clientId}. Verifique o console do navegador e do servidor.`);
        }
    }

    /**
     * Atualiza os dropdowns de seleção de cliente.
     * @param {Array} clientsData Array de objetos de status de cliente.
     */
    function updateClientDropdowns(clientsData) {
        console.log('[SCRIPT][updateClientDropdowns] Chamado com', clientsData.length, 'clientes.');
        // Limpa os dropdowns antes de repopular
        qrClientSelect.innerHTML = '<option value="">Selecione um cliente</option>';
        clientSelect.innerHTML = '<option value="">Selecione um cliente pronto</option>';

        clientsState = {}; // Reinicia o objeto clientsState

        if (clientsData.length === 0) {
            qrClientSelect.innerHTML = '<option value="">Nenhum cliente disponível</option>';
            clientSelect.innerHTML = '<option value="">Nenhum cliente pronto</option>';
            updateQrDisplayCard(null); // Limpa o card
            return; // Sai da função
        }

        clientsData.forEach(clientInfo => {
            clientsState[clientInfo.id] = clientInfo;

            const qrOption = document.createElement('option');
            qrOption.value = clientInfo.id;
            qrOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name}) - [${clientInfo.status}]`;
            qrClientSelect.appendChild(qrOption);

            const sendOption = document.createElement('option');
            sendOption.value = clientInfo.id;
            sendOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name})`;
            sendOption.disabled = (clientInfo.status !== 'Pronto');
            clientSelect.appendChild(sendOption);
        });

        // Restaura a seleção se o cliente ainda existir, ou seleciona o primeiro
        if (currentSelectedQrClientId && clientsState[currentSelectedQrClientId]) {
            qrClientSelect.value = currentSelectedQrClientId;
        } else if (clientsData.length > 0) {
            currentSelectedQrClientId = clientsData[0].id; // Seleciona o primeiro cliente como padrão
            qrClientSelect.value = currentSelectedQrClientId;
        } else {
            currentSelectedQrClientId = null;
        }

        // Atualiza o card de QR Code para o cliente atualmente selecionado
        updateQrDisplayCard(clientsState[currentSelectedQrClientId]);
    }

    // Função para atualizar o status do botão Iniciar Rotina
    function updateStartRoutineButtonStatus() {
        const hasReadyClients = availableReadyClients && availableReadyClients.length > 0;
        console.log(`[SCRIPT][updateStartRoutineButtonStatus] routineIsRunning=${routineIsRunning}, hasReadyClients=${hasReadyClients}, availableReadyClients.length=${availableReadyClients.length}`);

        if (routineIsRunning) {
            startRoutineButton.textContent = 'Rotina em Andamento...';
            startRoutineButton.disabled = true;
        } else if (hasReadyClients) {
            startRoutineButton.textContent = 'Iniciar Rotina de Envio';
            startRoutineButton.disabled = false;
        } else {
            startRoutineButton.textContent = 'Iniciar Rotina de Envio';
            startRoutineButton.disabled = true;
        }
        minTimeInput.disabled = routineIsRunning;
        maxTimeInput.disabled = routineIsRunning;
        routineMessageSelect.disabled = routineIsRunning;
    }

    // --- Socket.IO Event Listeners ---

    socket.on('connect', () => {
        console.log('[SOCKET] Conectado ao servidor Socket.IO');
        // Solicita o estado atualizado do servidor logo após a conexão
        socket.emit('requestInitialClientStatus');
        socket.emit('requestRoutineStatus');
        socket.emit('requestReadyClients'); // Solicita a lista de clientes prontos ao conectar

        // Busca o número de clientes atualizado
        fetch('/api/get-num-clients')
            .then(response => {
                if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
                return response.json();
            })
            .then(data => {
                console.log('[API] /api/get-num-clients data:', data);
                if (data.numClients !== undefined) {
                    numClientsSelect.value = data.numClients;
                    clientConfigStatusDiv.textContent = `Número de Clientes atual: ${data.numClients}`;
                    clientConfigStatusDiv.className = 'status-message success';
                    saveNumClientsButton.disabled = false;
                } else {
                    clientConfigStatusDiv.textContent = 'Não foi possível carregar a configuração atual de clientes.';
                    clientConfigStatusDiv.className = 'status-message error';
                    saveNumClientsButton.disabled = false;
                }
            })
            .catch(error => {
                console.error('[API] Erro ao carregar NUM_CLIENTS após reconexão:', error);
                clientConfigStatusDiv.textContent = 'Erro ao verificar a configuração de clientes após a reinicialização.';
                clientConfigStatusDiv.className = 'status-message error';
                saveNumClientsButton.disabled = false;
            });
    });

    socket.on('initialClientStatus', (initialData) => {
        console.log('[SOCKET] initialClientStatus recebido. Tamanho dos dados:', initialData.length);
        updateClientDropdowns(initialData);
    });

    socket.on('clientStatusUpdate', (updatedClientInfo) => {
        console.log('[SOCKET] clientStatusUpdate recebido para Cliente:', updatedClientInfo.id, 'Status:', updatedClientInfo.status);
        clientsState[updatedClientInfo.id] = updatedClientInfo;
        const allClients = Object.values(clientsState);
        updateClientDropdowns(allClients); // Atualiza todos os dropdowns de cliente e o card QR

        if (parseInt(currentSelectedQrClientId) === updatedClientInfo.id) {
            updateQrDisplayCard(updatedClientInfo);
        }
    });

    socket.on('readyClientsForRoutine', (readyClients) => {
        console.log(`[SOCKET][readyClientsForRoutine] Evento recebido! Tipo: ${typeof readyClients}, Conteúdo:`, readyClients);

        if (Array.isArray(readyClients)) {
            availableReadyClients = readyClients; // Armazena a lista recebida
            console.log(`[SOCKET][readyClientsForRoutine] availableReadyClients atualizado para:`, availableReadyClients);
        } else {
            console.error(`[SOCKET][readyClientsForRoutine] Dados recebidos NÃO são um array:`, readyClients);
            availableReadyClients = []; // Garante que é um array vazio se os dados forem inválidos
        }

        let content = "Base de Clientes Prontos (Remetentes): [";
        if (availableReadyClients.length > 0) {
            content += availableReadyClients.map(c => `Cliente ${c.id} (${c.name})`).join(', ');
        } else {
            content += "Nenhum cliente 'Pronto' disponível para a rotina.";
        }
        content += "]";
        readyClientsPrompt.textContent = content;

        // ATUALIZA O DEBUG VISUAL
        if (debugReadyClientsDiv) { // Verificação para evitar o erro "Cannot set properties of null"
            debugReadyClientsDiv.textContent = `DEBUG: availableReadyClients.length = ${availableReadyClients.length}`;
        } else {
            console.error('[SCRIPT] Elemento #debug-ready-clients não encontrado no DOM!');
        }


        updateStartRoutineButtonStatus(); // Chama a função unificada de status do botão
    });

    socket.on('routineLogUpdate', (logEntry) => {
        const timestamp = new Date().toLocaleTimeString();
        routineLog.textContent += `[${timestamp}] ${logEntry}\n`;
        routineLog.scrollTop = routineLog.scrollHeight;
    });

    socket.on('routineStatus', (status) => {
        console.log('[SOCKET] routineStatus recebido:', status.isRunning);
        routineIsRunning = status.isRunning;
        updateStartRoutineButtonStatus(); // Chama a função unificada de status do botão
    });

    // --- Listener para o Dropdown de Seleção de QR Code ---
    qrClientSelect.addEventListener('change', (event) => {
        const selectedId = parseInt(event.target.value);
        console.log(`[SCRIPT] Cliente selecionado no QR dropdown: ${selectedId}`);
        currentSelectedQrClientId = selectedId;
        updateQrDisplayCard(clientsState[selectedId]);
    });

    // --- Formulário de Envio de Mensagem Manual ---
    sendMessageForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        sendMessageStatusDiv.textContent = 'Enviando mensagem...';
        sendMessageStatusDiv.className = 'status-message info';

        const formData = new FormData(sendMessageForm);
        const clientId = parseInt(formData.get('clientId'));
        const number = formData.get('number');
        const message = formData.get('message');

        if (!clientId || !number || !message) {
            sendMessageStatusDiv.textContent = 'Por favor, preencha todos os campos para enviar a mensagem.';
            sendMessageStatusDiv.className = 'status-message error';
            return;
        }
        console.log(`[SCRIPT][sendMessageForm] Tentando enviar mensagem via Cliente ${clientId} para ${number}`);
        try {
            const response = await fetch('/api/send-message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ clientId, number, message }),
            });

            const result = await response.json();

            if (result.success) {
                sendMessageStatusDiv.textContent = result.message;
                sendMessageStatusDiv.className = 'status-message success';
                sendMessageForm.reset();
                contactSelect.value = "";
                messageSelect.value = "";
            } else {
                sendMessageStatusDiv.textContent = `Erro: ${result.message}`;
                sendMessageStatusDiv.className = 'status-message error';
            }
        } catch (error) {
            console.error('[SCRIPT][sendMessageForm] Erro ao enviar mensagem:', error);
            sendMessageStatusDiv.textContent = `Erro ao conectar com o servidor: ${error.message}`;
            sendMessageStatusDiv.className = 'status-message error';
        }
    });

    // --- Listener para o botão Iniciar Rotina ---
    startRoutineButton.addEventListener('click', async () => {
        if (routineIsRunning) {
            alert('A rotina de envio já está em andamento.');
            return;
        }

        // Verifica a quantidade de clientes prontos ANTES de enviar a requisição ao backend
        // Agora usa a variável global `availableReadyClients`
        if (!availableReadyClients || availableReadyClients.length === 0) {
            alert('Não há clientes "Prontos" disponíveis para iniciar a rotina. Por favor, autentique um cliente WhatsApp primeiro.');
            return;
        }

        const selectedMessageText = routineMessageSelect.value;
        const minTime = parseInt(minTimeInput.value);
        const maxTime = parseInt(maxTimeInput.value);


        if (!selectedMessageText) {
            alert('Por favor, selecione uma mensagem para a rotina.');
            return;
        }
        if (isNaN(minTime) || isNaN(maxTime) || minTime <= 0 || maxTime <= 0 || minTime > maxTime) {
            alert('Por favor, insira tempos mínimo e máximo válidos (números positivos, mínimo <= máximo).');
            return;
        }
        console.log('[SCRIPT][startRoutineButton] Iniciando rotina...');
        routineLog.textContent = 'Iniciando nova rotina de envio...\n';

        try {
            const response = await fetch('/api/start-routine', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    message: selectedMessageText,
                    minTime: minTime,
                    maxTime: maxTime,
                    contacts: contacts
                }),
            });

            const result = await response.json();

            if (result.success) {
                console.log('[SCRIPT][startRoutineButton] Rotina iniciada com sucesso:', result.message);
            } else {
                console.error('[SCRIPT][startRoutineButton] Erro ao iniciar rotina:', result.message);
                alert(`Erro ao iniciar rotina: ${result.message}`);
            }
        } catch (error) {
            console.error('[SCRIPT][startRoutineButton] Erro na requisição para iniciar rotina:', error);
            alert(`Erro de comunicação ao iniciar rotina: ${error.message}`);
        }
    });

    // --- Listener para o botão Salvar Configuração de Clientes ---
    saveNumClientsButton.addEventListener('click', async () => {
        const numClients = parseInt(numClientsSelect.value);
        if (isNaN(numClients) || numClients < 1 || numClients > 10) {
            clientConfigStatusDiv.textContent = 'Por favor, selecione um número válido de clientes (1-10).';
            clientConfigStatusDiv.className = 'status-message error';
            return;
        }

        clientConfigStatusDiv.textContent = `Salvando configuração para ${numClients} clientes...`;
        clientConfigStatusDiv.className = 'status-message info';
        saveNumClientsButton.disabled = true; // Desabilita para evitar múltiplos cliques

        console.log(`[SCRIPT][saveNumClientsButton] Tentando salvar NUM_CLIENTS para: ${numClients}`);
        try {
            const response = await fetch('/api/set-num-clients', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ numClients: numClients }),
            });
            const result = await response.json();

            if (result.success) {
                console.log(`[SCRIPT][saveNumClientsButton] Sucesso: ${result.message}`);
                clientConfigStatusDiv.textContent = result.message + " Aguardando reinício do servidor...";
                clientConfigStatusDiv.className = 'status-message success';
                // A atualização final da UI virá via socket.on('connect') quando o servidor reiniciar.
            } else {
                console.error(`[SCRIPT][saveNumClientsButton] Erro: ${result.message}`);
                clientConfigStatusDiv.textContent = `Erro: ${result.message}`;
                clientConfigStatusDiv.className = 'status-message error';
                saveNumClientsButton.disabled = false; // Reabilita em caso de falha na API
            }
        } catch (error) {
            console.error('[SCRIPT][saveNumClientsButton] Erro ao salvar configuração:', error);
            clientConfigStatusDiv.textContent = `Erro de comunicação: ${error.message}. Verifique o console do servidor.`;
            clientConfigStatusDiv.className = 'status-message error';
            saveNumClientsButton.disabled = false; // Reabilita em caso de erro de comunicação
        }
    });

    // --- Chamadas iniciais para garantir o estado correto ao carregar a página ---
    console.log('[SCRIPT] DOMContentLoaded: Carregando NUM_CLIENTS inicial via fetch...');
    fetch('/api/get-num-clients')
        .then(response => {
            if (!response.ok) {
                console.error(`[API] /api/get-num-clients HTTP erro: ${response.status} ${response.statusText}`);
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('[SCRIPT] NUM_CLIENTS inicial recebido:', data);
            if (data.numClients !== undefined) {
                numClientsSelect.value = data.numClients;
                clientConfigStatusDiv.textContent = `Número de Clientes configurado: ${data.numClients}`;
                clientConfigStatusDiv.className = 'status-message info';
            }
        })
        .catch(error => {
            console.error('[SCRIPT] Erro ao carregar NUM_CLIENTS inicial:', error);
            clientConfigStatusDiv.textContent = 'Erro ao carregar a configuração inicial de clientes.';
            clientConfigStatusDiv.className = 'status-message error';
        });

    console.log('[SCRIPT] DOMContentLoaded: Carregando status inicial de clientes via fetch...');
    fetch('/api/clients/status')
        .then(response => {
            if (!response.ok) {
                console.error(`[API] /api/clients/status HTTP erro: ${response.status} ${response.statusText}`);
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('[SCRIPT] Dados iniciais de clientes recebidos via fetch:', data);
            updateClientDropdowns(data);
            // Também solicitamos a lista de clientes prontos logo após carregar o status inicial
            socket.emit('requestReadyClients');
        })
        .catch(error => {
            console.error('[SCRIPT] Erro ao carregar status inicial dos clientes no fetch:', error);
            qrClientSelect.innerHTML = '<option value="">Erro ao carregar clientes</option>';
            clientSelect.innerHTML = '<option value="">Erro ao carregar clientes</option>';
            qrDisplayCard.innerHTML = '<p class="status-message error">Erro ao carregar status dos clientes. Verifique o servidor.</p>';
        });
});