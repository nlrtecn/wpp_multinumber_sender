const socket = io();

let currentClients = []; // Armazena o estado atual dos clientes exibidos no frontend
let frontendRoutineLogs = []; // Histórico de logs da rotina no frontend
let selectedClientId = null; // Armazena o ID do cliente selecionado para a rotina

// --- Funções de Atualização da UI ---

function displayClients(clientsData) {
    const clientsContainer = document.getElementById('clients-container');
    clientsContainer.innerHTML = ''; // Limpa o conteúdo antes de adicionar novos cartões

    clientsData.sort((a, b) => parseInt(a.id) - parseInt(b.id)); // Ordena clientes por ID

    clientsData.forEach(client => {
        const clientCard = document.createElement('div');
        clientCard.className = 'client-card';
        clientCard.id = `client-${client.id}`;

        let statusText = client.status;
        let qrCodeDisplay = ''; // HTML para a imagem do QR Code
        // Não há validação explícita de QR aqui, assume-se que se client.qr existe, é válido
        if (client.status === 'QR_CODE' && client.qr) {
            qrCodeDisplay = `<img src="${client.qr}" alt="QR Code para Cliente ${client.id}" class="qr-code-img">`;
            statusText = 'Escaneie o QR Code';
        } else if (client.status === 'Pronto') {
            statusText = 'Pronto';
        } else if (client.status === 'Desconectado' || client.status === 'Falha na Autenticação' || client.status === 'Erro') {
            statusText = 'Desconectado / Erro';
        }

        const phoneNumberDisplay = client.phoneNumber && client.phoneNumber !== 'N/A' ? `(${client.phoneNumber})` : '';

        // Constrói o HTML do cartão do cliente
        clientCard.innerHTML = `
            <h4>Cliente ${client.id}</h4>
            <p>Status: <span class="status-${client.status.toLowerCase().replace(/ /g, '-') || 'unknown'}">${statusText} ${phoneNumberDisplay}</span></p>
            ${qrCodeDisplay} <button class="reauth-btn" data-client-id="${client.id}" ${client.status === 'Pronto' ? 'disabled' : ''}>Reautenticar</button>
            <button class="remove-btn" data-client-id="${client.id}">Remover Cliente</button>
        `;
        clientsContainer.appendChild(clientCard);
    });

    // CRÍTICO: Reanexar listeners aos botões após a recriação dos elementos DOM
    attachClientButtonListeners();
    currentClients = clientsData; // Atualiza a lista local de clientes no frontend
}

// Anexa ou reanexa listeners de eventos aos botões de ação do cliente
function attachClientButtonListeners() {
    document.querySelectorAll('.reauth-btn').forEach(button => {
        button.removeEventListener('click', handleReauthenticateClick); // Remove para evitar duplicação
        button.addEventListener('click', handleReauthenticateClick);
    });

    document.querySelectorAll('.remove-btn').forEach(button => {
        button.removeEventListener('click', handleRemoveClientClick); // Remove para evitar duplicação
        button.addEventListener('click', handleRemoveClientClick);
    });
}

// Manipulador de clique para o botão "Reautenticar"
async function handleReauthenticateClick(e) {
    const clientId = parseInt(e.target.dataset.clientId);
    if (confirm(`Tem certeza que deseja reautenticar o Cliente ${clientId}? Isso desconectará a sessão atual e exigirá um novo QR Code.`)) {
        try {
            const response = await fetch('/api/reauthenticate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ clientId })
            });
            const data = await response.json();
            if (!data.success) {
                alert('Erro ao reautenticar: ' + data.message);
            }
            // A atualização da UI será feita via evento Socket.IO 'clientStatusUpdate'
        } catch (error) {
            console.error('Erro de rede ao reautenticar:', error);
            alert('Erro de comunicação com o servidor ao reautenticar.');
        }
    }
}

// Manipulador de clique para o botão "Remover Cliente"
async function handleRemoveClientClick(e) {
    const clientId = parseInt(e.target.dataset.clientId);
    if (confirm(`Tem certeza que deseja remover o Cliente ${clientId} e seus dados de sessão? Esta ação é irreversível.`)) {
        try {
            // Calcula o número de clientes que restarão após a remoção
            const remainingClients = currentClients.filter(c => c.id !== clientId);
            const newNumClients = remainingClients.length;

            const response = await fetch(`/api/set-num-clients`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ numClients: newNumClients })
            });
            const data = await response.json();
            if (!data.success) {
                alert('Erro ao remover cliente: ' + data.message);
            }
            // A atualização da UI será feita via eventos Socket.IO (clientStatusUpdate e initialClientStatus)
        } catch (error) {
            console.error('Erro de rede ao remover cliente:', error);
            alert('Erro de comunicação com o servidor ao remover cliente.');
        }
    }
}

// Atualiza o dropdown de seleção de cliente para a rotina
function updateReadyClientsDropdown(readyClients) {
    const clientSelect = document.getElementById('selected-client-id');
    const previousSelectedValue = clientSelect.value; // Salva o valor selecionado anteriormente

    clientSelect.innerHTML = '<option value="">Automático (alternar entre prontos)</option>'; // Opção padrão

    readyClients.sort((a, b) => parseInt(a.id) - parseInt(b.id)); // Ordena clientes para exibição consistente

    readyClients.forEach(client => {
        const option = document.createElement('option');
        option.value = client.id;
        option.textContent = `Cliente ${client.id} (${client.phoneNumber}) - Pronto`;
        clientSelect.appendChild(option);
    });

    // Tenta re-selecionar o cliente que estava selecionado, se ainda estiver disponível
    if (selectedClientId && readyClients.some(c => String(c.id) === String(selectedClientId))) {
        clientSelect.value = String(selectedClientId);
    } else if (readyClients.some(c => String(c.id) === previousSelectedValue)) {
        clientSelect.value = previousSelectedValue;
    } else {
        clientSelect.value = ""; // Volta para 'Automático' se o cliente não estiver mais pronto
    }
}

// Atualiza a interface de usuário da rotina de envio
function updateRoutineUI(status) {
    if (!status) return;

    document.getElementById('routine-status-display').textContent = status.isRunning ? 'Em Andamento' : 'Inativa';
    document.getElementById('routine-progress-display').textContent = `${status.currentIndex}/${status.totalContacts}`;
    document.getElementById('routine-success-display').textContent = status.successCount;
    document.getElementById('routine-fail-display').textContent = status.failCount;

    const startButton = document.getElementById('start-routine-btn');
    const stopButton = document.getElementById('stop-routine-btn');

    // Elementos do formulário de configuração da rotina
    const contactsInput = document.getElementById('contacts-input');
    const messagesInput = document.getElementById('messages-input');
    const minDelayInput = document.getElementById('min-delay');
    const maxDelayInput = document.getElementById('max-delay');
    const selectedClientDropdown = document.getElementById('selected-client-id');
    const setNumClientsBtn = document.getElementById('set-num-clients-btn');
    const numClientsInput = document.getElementById('num-clients-input');

    const elementsToDisable = [
        contactsInput, messagesInput, minDelayInput, maxDelayInput,
        selectedClientDropdown, setNumClientsBtn, numClientsInput
    ];

    if (status.isRunning) {
        startButton.disabled = true;
        stopButton.disabled = false;

        // Desabilita os campos de configuração da rotina enquanto ela está ativa
        elementsToDisable.forEach(el => {
            if (el) el.disabled = true;
        });

        // Atualiza os campos de input com os valores da rotina em andamento
        const newContactsValue = status.contactsList.map(c => `${c.nome}:${c.numero}`).join('\n');
        if (contactsInput.value !== newContactsValue) {
             contactsInput.value = newContactsValue;
        }

        const newMessagesValue = status.messagesList.join('\n');
        if (messagesInput.value !== newMessagesValue) {
            messagesInput.value = newMessagesValue;
        }

        // Atualiza os delays (convertendo de milissegundos para segundos)
        if (minDelayInput.value !== String(status.minDelay / 1000)) {
            minDelayInput.value = status.minDelay / 1000;
        }
        if (maxDelayInput.value !== String(status.maxDelay / 1000)) {
            maxDelayInput.value = status.maxDelay / 1000;
        }

        // Mantém a seleção do cliente no dropdown
        selectedClientId = status.selectedClientId;
        if (selectedClientId && selectedClientDropdown.value !== String(selectedClientId)) {
            selectedClientDropdown.value = String(selectedClientId);
        } else if (!selectedClientId && selectedClientDropdown.value !== "") {
            selectedClientDropdown.value = "";
        }

    } else { // Rotina Inativa
        startButton.disabled = false;
        stopButton.disabled = true;

        // Habilita os campos de configuração da rotina
        elementsToDisable.forEach(el => {
            if (el) el.disabled = false;
        });
        
        // Limpa a seleção do cliente após a rotina terminar
        selectedClientId = null;
    }
}

// Adiciona uma entrada de log à área de logs da rotina no UI
function addRoutineLogToUI(logEntry) {
    const logContainer = document.getElementById('routine-log-output');
    const logElement = document.createElement('p');
    logElement.classList.add(`log-${logEntry.type}`); // Adiciona classe para estilização (e.g., cor)
    logElement.textContent = `[${logEntry.timestamp}] ${logEntry.message}`;
    logContainer.appendChild(logElement);
    logContainer.scrollTop = logContainer.scrollHeight; // Rola para o final para mostrar o log mais recente

    frontendRoutineLogs.push(logEntry); // Guarda o log no array do frontend
}

// --- Eventos Socket.IO ---

socket.on('connect', () => {
    console.log('[FRONTEND - SOCKET.IO] Conectado ao servidor.');
    // Ao conectar (ou reconectar), solicita o estado atual para sincronizar a UI
    socket.emit('requestInitialClientStatus');
    socket.emit('requestRoutineStatus');
    socket.emit('requestReadyClients');
});

socket.on('disconnect', () => {
    console.log('[FRONTEND - SOCKET.IO] Desconectado do servidor.');
});

// Recebe o status inicial de todos os clientes do backend
socket.on('initialClientStatus', (clientsData) => {
    console.log('[FRONTEND - SOCKET.IO] Initial Client Status Recebido:', clientsData);
    displayClients(clientsData); // Renderiza os cartões dos clientes
});

// Recebe atualizações de status de um cliente específico
socket.on('clientStatusUpdate', (clientData) => {
    console.log('[FRONTEND - SOCKET.IO] Client Status Update Recebido:', clientData);
    const existingClientIndex = currentClients.findIndex(c => c.id === clientData.id);
    if (existingClientIndex > -1) {
        currentClients[existingClientIndex] = clientData; // Atualiza dados do cliente existente
    } else {
        currentClients.push(clientData); // Adiciona novo cliente à lista
    }
    displayClients(currentClients); // Re-renderiza para refletir a mudança
});

// Recebe a lista de clientes 'prontos' para preencher o dropdown da rotina
socket.on('readyClientsForRoutine', (readyClients) => {
    console.log('[FRONTEND - SOCKET.IO] Ready Clients for Routine Recebido:', readyClients);
    updateReadyClientsDropdown(readyClients);
});

// Recebe o status completo da rotina de envio
socket.on('routineStatus', (status) => {
    console.log('[FRONTEND - SOCKET.IO] Rotina Status Recebido:', status);
    updateRoutineUI(status);
    // Limpa e reinicia a exibição dos logs a cada `routineStatus` completo
    // Isso garante que os logs sejam sincronizados corretamente em reconexões ou novas rotinas
    document.getElementById('routine-log-output').innerHTML = '';
    frontendRoutineLogs = [];
});

// Recebe uma nova entrada de log da rotina
socket.on('routineLogUpdate', (logEntry) => {
    addRoutineLogToUI(logEntry);
});

// --- Listeners de Eventos DOM (Botões/Inputs) ---

// Listener para o botão "Definir Clientes"
document.getElementById('set-num-clients-btn').addEventListener('click', async () => {
    const numClients = parseInt(document.getElementById('num-clients-input').value);
    if (isNaN(numClients) || numClients < 1 || numClients > 10) {
        alert('Por favor, insira um número válido de clientes (1 a 10).');
        return;
    }
    try {
        const response = await fetch('/api/set-num-clients', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ numClients })
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao definir clientes: ' + (data.message || 'Erro desconhecido.'));
        }
    } catch (error) {
        console.error('Erro ao comunicar com o backend para definir clientes:', error);
        alert('Erro de comunicação com o servidor ao definir clientes.');
    }
});

// Listener para o botão "Iniciar Rotina"
document.getElementById('start-routine-btn').addEventListener('click', async () => {
    const contactsInput = document.getElementById('contacts-input');
    const messagesInput = document.getElementById('messages-input');
    const minDelayInput = document.getElementById('min-delay');
    const maxDelayInput = document.getElementById('max-delay');
    const selectedClientDropdown = document.getElementById('selected-client-id');

    const contactsText = contactsInput.value;
    const messagesText = messagesInput.value;
    // Converte segundos para milissegundos para o backend
    const minDelay = parseInt(minDelayInput.value * 1000);
    const maxDelay = parseInt(maxDelayInput.value * 1000);
    const selectedClientIdRaw = selectedClientDropdown.value;
    const selectedClientId = selectedClientIdRaw ? parseInt(selectedClientIdRaw) : null;


    if (!contactsText || !messagesText) {
        alert('Por favor, preencha os contatos e as mensagens.');
        return;
    }

    if (isNaN(minDelay) || isNaN(maxDelay) || minDelay < 1000 || maxDelay < 1000 || minDelay > maxDelay) {
        alert('Por favor, insira um atraso mínimo e máximo válidos (em segundos, mínimo 1). O atraso mínimo deve ser menor ou igual ao máximo.');
        return;
    }

    // Processa a lista de contatos (espera "Nome:Número")
    const contacts = contactsText.split('\n').map(line => {
        const parts = line.split(':');
        if (parts.length >= 2) {
            return { nome: parts[0].trim(), numero: parts[1].trim() };
        }
        return null; // Linhas mal formatadas são ignoradas
    }).filter(c => c !== null && c.nome && c.numero); // Filtra entradas nulas e vazias

    // Processa a lista de mensagens (uma por linha)
    const messages = messagesText.split('\n').map(msg => msg.trim()).filter(msg => msg !== '');

    if (contacts.length === 0 || messages.length === 0) {
        alert('As listas de contatos ou mensagens estão vazias ou mal formatadas. Verifique o formato Nome:Número para contatos.');
        return;
    }

    try {
        const response = await fetch('/api/routine/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contacts, messages, selectedClientId, minDelay, maxDelay })
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao iniciar rotina: ' + (data.message || 'Erro desconhecido.'));
        }
    } catch (error) {
        console.error('Erro ao comunicar com o backend para iniciar rotina:', error);
        alert('Erro ao iniciar rotina. Verifique o console do servidor.');
    }
});

// Listener para o botão "Parar Rotina"
document.getElementById('stop-routine-btn').addEventListener('click', async () => {
    try {
        const response = await fetch('/api/routine/stop', {
            method: 'POST'
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao parar rotina: ' + (data.message || 'Erro desconhecido.'));
        }
    } catch (error) {
        console.error('Erro ao comunicar com o backend para parar rotina:', error);
        alert('Erro ao parar rotina. Verifique o console do servidor.');
    }
});

// --- Inicialização ao Carregar a Página ---
document.addEventListener('DOMContentLoaded', () => {
    // Ao carregar a página, solicita o número atual de clientes do backend
    fetch('/api/get-num-clients')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('num-clients-input').value = data.numClients;
            }
        })
        .catch(error => console.error('Erro ao obter número de clientes:', error));

    // Garante que os listeners dos botões de cliente sejam anexados (para botões que já existem ou serão criados)
    attachClientButtonListeners();
});