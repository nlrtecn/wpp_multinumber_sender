document.addEventListener('DOMContentLoaded', () => {
    const socket = io(); // Conecta ao servidor Socket.IO

    const clientsContainer = document.getElementById('clients-container');
    const setClientsForm = document.getElementById('set-clients-form');
    const numClientsInput = document.getElementById('numClients');
    
    const contactListInput = document.getElementById('contactList');
    const messageContentsInput = document.getElementById('messageContents');

    const startRoutineBtn = document.getElementById('startRoutineBtn');
    const stopRoutineBtn = document.getElementById('stopRoutineBtn');
    const routineLog = document.getElementById('routineLog');
    const saveLogBtn = document.getElementById('saveLogBtn'); // Manter o botão para salvamento manual
    const routineStatusSpan = document.getElementById('routineStatus');
    const availableClientsSelect = document.getElementById('availableClients');
    const routineProgressBar = document.getElementById('routineProgressBar');
    const routineProgressText = document.getElementById('routineProgressText');
    const minDelayInput = document.getElementById('minDelay');
    const maxDelayInput = document.getElementById('maxDelay');

    let allClients = {};
    let readyClientsForRoutine = [];
    let parsedContacts = [];
    let parsedMessages = [];
    let currentRoutineIndex = 0;
    let routineIsRunning = false;
    let routineIntervalId = null;

    // --- Funções de Utilitário do Frontend ---

    /**
     * Adiciona uma mensagem ao log da rotina.
     * @param {string} message - A mensagem a ser adicionada.
     * @param {string} type - 'info', 'success', 'error', 'warning'
     */
    function appendRoutineLog(message, type = 'info') {
        const p = document.createElement('p');
        p.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
        p.classList.add(`log-${type}`);
        routineLog.appendChild(p);
        routineLog.scrollTop = routineLog.scrollHeight;
    }

    /**
     * Atualiza a exibição de um card de cliente individual.
     * @param {object} client - O objeto cliente com as informações atualizadas.
     */
    function updateClientCard(client) {
        let clientCard = document.getElementById(`client-card-${client.id}`);

        if (!clientCard) {
            clientCard = document.createElement('div');
            clientCard.id = `client-card-${client.id}`;
            clientCard.classList.add('client-card');
            clientsContainer.appendChild(clientCard);
        }

        if (client.status === 'Removido') {
            if (clientCard) clientCard.remove();
            delete allClients[client.id];
            updateAvailableClientsForRoutine();
            appendRoutineLog(`Cliente ${client.id} foi removido.`, 'info');
            return;
        }

        allClients[client.id] = { ...allClients[client.id], ...client };

        clientCard.innerHTML = `
            <h3>Cliente ${client.id}</h3>
            <p><strong>Nome:</strong> ${client.name}</p>
            <p><strong>Status:</strong> <span id="status-${client.id}">${client.status}</span></p>
            <p><strong>Telefone:</strong> <span id="phone-${client.id}">${client.phoneNumber || 'N/A'}</span></p>
            <div class="qr-code-area" id="qr-area-${client.id}">
                ${client.status === 'QR_CODE' && client.qr ?
                    `<img src="${client.qr}" alt="QR Code para Cliente ${client.id}" style="width: 200px; height: 200px; display: block;">` :
                    `<p>${client.status === 'Pronto' ? 'Conectado!' : 'Aguardando QR Code...'}</p>`
                }
            </div>
            <button class="reauthenticate-btn" data-client-id="${client.id}" ${client.status === 'Conectado' || client.status === 'Autenticado' || client.status === 'Pronto' ? '' : 'disabled'}>Reautenticar</button>
        `;

        const reauthenticateBtn = clientCard.querySelector(`.reauthenticate-btn`);
        if (reauthenticateBtn) {
            reauthenticateBtn.onclick = async () => {
                appendRoutineLog(`Solicitando reautenticação para Cliente ${client.id}...`, 'info');
                try {
                    const response = await fetch('/api/reauthenticate', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ clientId: client.id })
                    });
                    const result = await response.json();
                    if (result.success) {
                        appendRoutineLog(`Reautenticação iniciada para Cliente ${client.id}: ${result.message}`, 'success');
                    } else {
                        appendRoutineLog(`Falha na reautenticação do Cliente ${client.id}: ${result.message}`, 'error');
                    }
                } catch (error) {
                    appendRoutineLog(`Erro de rede ao reautenticar Cliente ${client.id}: ${error.message}`, 'error');
                }
            };
        }

        updateAvailableClientsForRoutine();
    }

    /**
     * Atualiza a lista de clientes disponíveis para a rotina de envio.
     */
    function updateAvailableClientsForRoutine() {
        availableClientsSelect.innerHTML = '<option value="">Todos os Prontos (Rodízio)</option>';

        readyClientsForRoutine = Object.values(allClients).filter(client =>
            client.status === 'Pronto' && client.phoneNumber && client.phoneNumber !== 'N/A' && client.phoneNumber !== 'Erro ao obter Telefone'
        );

        if (readyClientsForRoutine.length === 0) {
            appendRoutineLog('Nenhum cliente pronto para a rotina de envio.', 'warning');
            startRoutineBtn.disabled = true;
            stopRoutineBtn.disabled = true;
            return;
        }

        readyClientsForRoutine.forEach(client => {
            const option = document.createElement('option');
            option.value = client.id;
            option.textContent = `Cliente ${client.id} (${client.phoneNumber})`;
            availableClientsSelect.appendChild(option);
        });

        startRoutineBtn.disabled = routineIsRunning;
        stopRoutineBtn.disabled = !routineIsRunning;
    }

    /**
     * Envia uma mensagem para um número específico usando um cliente específico.
     * @param {number} clientId - O ID do cliente WhatsApp a ser usado.
     * @param {string} number - O número de telefone de destino.
     * @param {string} message - O conteúdo da mensagem.
     * @returns {Promise<boolean>} - True se a mensagem foi enviada com sucesso, false caso contrário.
     */
    async function sendMessage(clientId, number, message) {
        try {
            const response = await fetch('/api/send-message', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ clientId, number, message })
            });
            const result = await response.json();
            return result.success;
        } catch (error) {
            appendRoutineLog(`Erro de rede ao enviar mensagem (Cliente ${clientId} para ${number}): ${error.message}`, 'error');
            return false;
        }
    }

    /**
     * Função para salvar o log da rotina.
     */
    async function saveRoutineLog() {
        const logContent = routineLog.innerText;
        if (!logContent) {
            appendRoutineLog('Não há conteúdo no log para salvar.', 'warning');
            return;
        }

        try {
            const response = await fetch('/api/save-routine-log', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ log: logContent })
            });
            const result = await response.json();
            if (result.success) {
                appendRoutineLog(`Log salvo com sucesso como ${result.filename}`, 'success');
            } else {
                appendRoutineLog(`Erro ao salvar log: ${result.message}`, 'error');
            }
        } catch (error) {
            appendRoutineLog(`Erro de rede ao salvar log: ${error.message}`, 'error');
        }
    }


    /**
     * Inicia a rotina de envio de mensagens.
     */
    async function startRoutineHandler() {
        const selectedClientId = availableClientsSelect.value;
        const rawContacts = contactListInput.value.trim();
        const rawMessages = messageContentsInput.value.trim();

        if (!rawContacts || !rawMessages) {
            alert('Por favor, preencha a lista de contatos e o conteúdo das mensagens.');
            return;
        }

        parsedContacts = rawContacts.split('\n')
                                    .map(line => {
                                        const parts = line.split(',');
                                        return {
                                            nome: parts[0] ? parts[0].trim() : '',
                                            numero: parts[1] ? parts[1].trim() : ''
                                        };
                                    })
                                    .filter(contact => contact.numero !== '');

        parsedMessages = rawMessages.split('\n')
                                     .map(message => message.trim())
                                     .filter(message => message !== '');

        if (parsedContacts.length === 0) {
            alert('A lista de contatos está vazia ou no formato incorreto. Use: Nome,Número');
            return;
        }
        if (parsedMessages.length === 0) {
            alert('A lista de mensagens está vazia.');
            return;
        }

        if (readyClientsForRoutine.length === 0) {
            appendRoutineLog('Não há clientes prontos para iniciar a rotina.', 'warning');
            return;
        }

        routineIsRunning = true;
        startRoutineBtn.disabled = true;
        stopRoutineBtn.disabled = false;
        routineStatusSpan.textContent = 'Ativa';
        routineStatusSpan.className = 'status-active';
        appendRoutineLog(`Rotina de envio iniciada para ${parsedContacts.length} contatos com ${parsedMessages.length} mensagens.`, 'info');

        currentRoutineIndex = 0;
        await processNextMessageInRoutine(selectedClientId);
    }

    /**
     * Processa a próxima mensagem na rotina.
     * @param {number} selectedClientId - O ID do cliente selecionado no dropdown, ou vazio para rodízio.
     */
    async function processNextMessageInRoutine(selectedClientId) {
        if (!routineIsRunning || currentRoutineIndex >= parsedContacts.length) {
            stopRoutineHandler();
            return;
        }

        updateProgressBar();

        const contact = parsedContacts[currentRoutineIndex];
        const rawMessage = parsedMessages[currentRoutineIndex % parsedMessages.length];
        
        let finalMessage = rawMessage.replace(/{nome}/g, contact.nome);

        let clientToSend;

        if (selectedClientId) {
            clientToSend = readyClientsForRoutine.find(c => c.id == selectedClientId);
            if (!clientToSend) {
                appendRoutineLog(`O cliente selecionado (${selectedClientId}) não está mais pronto. Parando rotina.`, 'error');
                stopRoutineHandler();
                return;
            }
        } else {
            clientToSend = readyClientsForRoutine[currentRoutineIndex % readyClientsForRoutine.length];
            if (!clientToSend) {
                appendRoutineLog('Nenhum cliente disponível para enviar mensagens. Parando rotina.', 'error');
                stopRoutineHandler();
                return;
            }
        }

        appendRoutineLog(`Tentando enviar (Cliente ${clientToSend.id}, Telefone: ${clientToSend.phoneNumber}) para ${contact.nome} (${contact.numero})...`, 'info');

        const success = await sendMessage(clientToSend.id, contact.numero, finalMessage);

        if (success) {
            appendRoutineLog(`Sucesso: Cliente ${clientToSend.id} enviou para ${contact.nome} (${contact.numero})`, 'success');
        } else {
            appendRoutineLog(`Falha: Cliente ${clientToSend.id} ao enviar para ${contact.nome} (${contact.numero}).`, 'error');
        }

        currentRoutineIndex++;

        if (routineIsRunning && currentRoutineIndex < parsedContacts.length) {
            const minDelay = parseInt(minDelayInput.value) * 1000;
            const maxDelay = parseInt(maxDelayInput.value) * 1000;
            const delay = Math.floor(Math.random() * (maxDelay - minDelay + 1)) + minDelay;

            appendRoutineLog(`Aguardando ${delay / 1000} segundos para a próxima mensagem...`, 'info');
            routineIntervalId = setTimeout(() => processNextMessageInRoutine(selectedClientId), delay);
        } else {
            // A rotina terminou (ou foi parada)
            stopRoutineHandler();
            appendRoutineLog('Rotina de envio concluída ou interrompida.', 'info');
        }
    }

    /**
     * Para a rotina de envio de mensagens e salva o log.
     */
    function stopRoutineHandler() {
        if (!routineIsRunning && currentRoutineIndex >= parsedContacts.length) {
            // Se a rotina já estava parada e já passou por todos os contatos, não faz nada.
            // Isso evita salvar o log múltiplas vezes se o botão "Parar" for clicado
            // depois que a rotina já terminou sozinha.
            return; 
        }

        routineIsRunning = false;
        clearTimeout(routineIntervalId);
        startRoutineBtn.disabled = false;
        stopRoutineBtn.disabled = true;
        routineStatusSpan.textContent = 'Inativa';
        routineStatusSpan.className = 'status-inactive';
        
        appendRoutineLog('Rotina de envio parada. Salvando log automaticamente...', 'info');
        saveRoutineLog(); // Chama a função para salvar o log
        updateProgressBar(true);
    }

    /**
     * Atualiza a barra de progresso da rotina.
     * @param {boolean} reset - Se true, reseta a barra de progresso.
     */
    function updateProgressBar(reset = false) {
        if (reset) {
            routineProgressBar.style.width = '0%';
            routineProgressText.textContent = '0/0 (0%)';
            return;
        }

        const total = parsedContacts.length;
        const current = currentRoutineIndex;
        const percentage = total > 0 ? (current / total) * 100 : 0;

        routineProgressBar.style.width = `${percentage}%`;
        routineProgressText.textContent = `${current}/${total} (${percentage.toFixed(2)}%)`;
    }

    // --- Listeners de Eventos Socket.IO ---

    socket.on('initialClientStatus', (clientsArray) => {
        console.log('[SOCKET] initialClientStatus recebido:', clientsArray);
        clientsArray.forEach(client => updateClientCard(client));
    });

    socket.on('clientStatusUpdate', (client) => {
        console.log(`[SOCKET] clientStatusUpdate recebido para Cliente: ${client.id} Status: ${client.status}`);
        updateClientCard(client);
    });

    socket.on('routineLogUpdate', (logMessage) => {
        appendRoutineLog(logMessage, 'info');
    });

    socket.on('routineStatus', (status) => {
        routineIsRunning = status.isRunning;
        startRoutineBtn.disabled = status.isRunning;
        stopRoutineBtn.disabled = !status.isRunning;
        routineStatusSpan.textContent = status.isRunning ? 'Ativa' : 'Inativa';
        routineStatusSpan.className = status.isRunning ? 'status-active' : 'status-inactive';
    });

    socket.on('readyClientsForRoutine', (clients) => {
        readyClientsForRoutine = clients;
        updateAvailableClientsForRoutine();
    });

    // --- Listeners de Eventos do DOM ---

    setClientsForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const newNumClients = parseInt(numClientsInput.value);
        if (isNaN(newNumClients) || newNumClients < 1 || newNumClients > 10) {
            alert('Por favor, insira um número válido de clientes entre 1 e 10.');
            return;
        }

        try {
            const response = await fetch('/api/set-num-clients', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ numClients: newNumClients })
            });
            const result = await response.json();
            if (result.success) {
                appendRoutineLog(`Número de clientes definido para ${newNumClients}.`, 'success');
            } else {
                appendRoutineLog(`Erro ao definir número de clientes: ${result.message}`, 'error');
            }
        } catch (error) {
            appendRoutineLog(`Erro de rede ao definir número de clientes: ${error.message}`, 'error');
        }
    });

    startRoutineBtn.addEventListener('click', startRoutineHandler);
    stopRoutineBtn.addEventListener('click', stopRoutineHandler);

    // O botão "Salvar Log" agora chama a função saveRoutineLog diretamente
    saveLogBtn.addEventListener('click', saveRoutineLog);

    // --- Inicialização ao Carregar a Página ---
    fetch('/api/get-num-clients')
        .then(response => response.json())
        .then(data => {
            if (data && typeof data.numClients === 'number') {
                numClientsInput.value = data.numClients;
            }
        })
        .catch(error => console.error('Erro ao obter número de clientes:', error));

    socket.emit('requestInitialClientStatus');
    socket.emit('requestRoutineStatus');
    socket.emit('requestReadyClients');
});