document.addEventListener('DOMContentLoaded', () => {
    const socket = io();

    // Elementos do Formulário de Mensagem Manual
    const clientSelect = document.getElementById('client-select');
    const numberInput = document.getElementById('number-input');
    const messageInput = document.getElementById('message-input');
    const sendMessageForm = document.getElementById('send-message-form');
    const sendMessageStatusDiv = document.getElementById('send-message-status');
    const contactSelect = document.getElementById('contact-select');
    const messageSelect = document.getElementById('message-select');

    // Elementos para o Card de QR Code Individual
    const qrClientSelect = document.getElementById('qr-client-select');
    const qrDisplayCard = document.getElementById('qr-display-card');

    // Elementos da Rotina de Envio
    const startRoutineButton = document.getElementById('start-routine-button');
    const routineMessageSelect = document.getElementById('routine-message-select');
    const minTimeInput = document.getElementById('min-time');
    const maxTimeInput = document.getElementById('max-time');
    const readyClientsPrompt = document.getElementById('ready-clients-prompt');
    const routineLog = document.getElementById('routine-log');
    const debugReadyClientsDiv = document.getElementById('debug-ready-clients'); // Elemento de debug

    // Elementos de Configuração de Clientes
    const numClientsSelect = document.getElementById('num-clients-select');
    const saveNumClientsButton = document.getElementById('save-num-clients-button');
    const clientConfigStatusDiv = document.getElementById('client-config-status');

    // Armazena o estado completo de todos os clientes no front-end
    let clientsState = {};
    let currentSelectedQrClientId = null;
    let routineIsRunning = false;
    let availableReadyClients = []; // Variável para armazenar os clientes prontos recebidos

    // Variável para a lógica de round-robin na rotina
    let lastUsedClientIndex = 0;
    // Constante para o número máximo de tentativas por contato antes de pular
    const MAX_RETRIES_PER_CONTACT = 3; 

    // --- BASE DE DADOS FICTÍCIA DE CONTATOS ---
    const contacts = [
        { nome: 'Move360', telefone: '554789168420' },
        { nome: 'NLR', telefone: '554784337343' },
        { nome: 'Errado', telefone: '554755555555' },
        { nome: 'Mae', telefone: '554797600064' },
    ];

    // --- BASE DE DADOS FICTÍCIA DE MENSAGENS (COM CAMPO 'props' VAZIO) ---
    const messages = [
        {
            id: 'saudacao_nova_compra',
            mensagem: `Olá! 👋 Agradecemos sua recente compra conosco.
Sua satisfação é nossa prioridade.
Qualquer dúvida ou feedback, estamos à disposição.
Tenha um ótimo dia! ✨`,
            props: ''
        },
        {
            id: 'lembrete_pagamento',
            mensagem: `🔔 Lembrete de pagamento: Sua fatura no valor de R$XX,XX vence em DD/MM.
Evite multas e juros.
Acesse nosso portal para mais detalhes ou entre em contato.
Obrigado! 🙏`,
            props: ''
        },
        {
            id: 'confirmacao_agendamento',
            mensagem: `✅ Confirmação de agendamento:
Seu horário com [Nome do Profissional] foi marcado para DD/MM às HH:MM.
Pedimos que chegue com 10 minutos de antecedência.
Até breve! 🗓️`,
            props: ''
        },
        {
            id: 'oferta_especial',
            mensagem: `🎉 Nova oferta exclusiva para você!
Use o código *DESCONTO20* e ganhe 20% OFF em sua próxima compra.
Válido até DD/MM. Não perca! 🎁
Acesse: [Link da Loja]`,
            props: ''
        },
        {
            id: 'suporte_tecnico',
            mensagem: `🛠️ Olá! Recebemos sua solicitação de suporte.
Nosso time técnico está analisando seu caso (#ABC123).
Em breve entraremos em contato com uma solução.
Agradecemos a paciência! 🧑‍💻`,
            props: ''
        },
        {
            id: 'pesquisa_satisfacao',
            mensagem: `Queremos ouvir você! 🗣️
Sua opinião é muito importante para melhorarmos nossos serviços.
Responda nossa breve pesquisa de satisfação:
[Link da Pesquisa]
Muito obrigado! 🙏`,
            props: ''
        },
        {
            id: 'boas_vindas_plataforma',
            mensagem: `Bem-vindo(a) à nossa plataforma! 🚀
Estamos felizes em tê-lo(a) conosco.
Explore todas as funcionalidades e descubra como podemos te ajudar.
Se precisar de algo, é só chamar! 💡`,
            props: ''
        },
        {
            id: 'avisos_manutencao',
            mensagem: `⚠️ Aviso Importante:
Informamos que haverá uma manutenção programada em nossos sistemas na data DD/MM, das HH:MM às HH:MM.
Durante este período, alguns serviços podem estar indisponívels.
Agradecemos a compreensão. 🔧`,
            props: ''
        },
        {
            id: 'feliz_aniversario',
            mensagem: `🥳 Feliz Aniversário, [Nome do Cliente]!
Que seu dia seja repleto de alegria e realizações.
Para celebrar, temos um presente especial para você: use o código *ANIVERSARIO10* para 10% de desconto! 🎂`,
            props: ''
        },
        {
            id: 'pedido_entregue',
            mensagem: `📦 Seu pedido (#XYZ987) foi entregue com sucesso!
Esperamos que você aproveite seus novos itens.
Deixe sua avaliação e nos ajude a crescer! ⭐⭐⭐⭐⭐
Qualquer problema, estamos aqui!`,
            props: ''
        }
    ];

    // Funções para popular os dropdowns
    function populateContactsDropdown() {
        contactSelect.innerHTML = '<option value="">Selecione um contato</option>';
        contacts.forEach(contact => {
            const option = document.createElement('option');
            option.value = contact.telefone;
            option.textContent = `${contact.nome} (${contact.telefone})`;
            contactSelect.appendChild(option);
        });
    }

    function populateMessagesDropdowns() {