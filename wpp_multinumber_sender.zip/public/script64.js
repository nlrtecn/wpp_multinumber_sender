document.addEventListener('DOMContentLoaded', () => {
    const socket = io();

    // ... (outras constantes e variáveis) ...

    // --- Funções de Utilitário do Frontend ---
    // ... (appendRoutineLog, updateClientCard, updateAvailableClientsForRoutine, etc.) ...

    // --- Listeners de Eventos Socket.IO ---

    socket.on('initialClientStatus', (clientsArray) => {
        console.log('[SOCKET] initialClientStatus recebido:', clientsArray);
        // Garante que o container de clientes seja limpo antes de adicionar os novos cards
        // Isso é crucial para "restaurar" a visualização sem duplicatas
        clientsContainer.innerHTML = '';
        allClients = {}; // Limpa o objeto de clientes interno do frontend

        clientsArray.forEach(client => updateClientCard(client));
    });

    // ... (outros listeners Socket.IO) ...

    // --- Inicialização ao Carregar a Página ---
    // ... (outros fetches de inicialização) ...

    // Solicita o status inicial dos clientes ao carregar a página
    socket.emit('requestInitialClientStatus'); 
    socket.emit('requestReadyClients'); 
});