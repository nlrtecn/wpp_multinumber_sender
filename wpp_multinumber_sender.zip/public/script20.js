document.addEventListener('DOMContentLoaded', () => {
    const socket = io();

    // ... (restante do seu código JavaScript existente) ...

    // Elementos de Configuração de Clientes
    const numClientsSelect = document.getElementById('num-clients-select');
    const saveNumClientsButton = document.getElementById('save-num-clients-button');
    const clientConfigStatusDiv = document.getElementById('client-config-status');

    // ... (restante do seu código JavaScript existente, incluindo as bases de dados de contatos e mensagens) ...

    // --- Listener para o botão Salvar Configuração de Clientes ---
    saveNumClientsButton.addEventListener('click', async () => {
        const numClients = parseInt(numClientsSelect.value);
        if (isNaN(numClients) || numClients < 1 || numClients > 10) {
            clientConfigStatusDiv.textContent = 'Por favor, selecione um número válido de clientes (1-10).';
            clientConfigStatusDiv.className = 'status-message error';
            return;
        }

        // Antes de enviar, mostra a mensagem de reinício
        clientConfigStatusDiv.textContent = `Salvando configuração para ${numClients} clientes... O servidor está reiniciando automaticamente para aplicar a mudança.`;
        clientConfigStatusDiv.className = 'status-message info';
        saveNumClientsButton.disabled = true; // Desabilita o botão enquanto salva

        try {
            const response = await fetch('/api/set-num-clients', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ numClients: numClients }),
            });
            const result = await response.json();

            if (result.success) {
                console.log(result.message); // Log para o console do navegador
                // Não precisamos mais setar uma mensagem final aqui, pois a página vai recarregar/reemitir o status
            } else {
                clientConfigStatusDiv.textContent = `Erro: ${result.message}`;
                clientConfigStatusDiv.className = 'status-message error';
                saveNumClientsButton.disabled = false; // Reabilita o botão em caso de erro na requisição
            }
        } catch (error) {
            console.error('Erro ao salvar configuração:', error);
            clientConfigStatusDiv.textContent = `Erro de comunicação: ${error.message}. Verifique o console do servidor.`;
            clientConfigStatusDiv.className = 'status-message error';
            saveNumClientsButton.disabled = false; // Reabilita o botão em caso de erro de rede
        }
    });

    // --- Requisição inicial para carregar o status dos clientes ---
    fetch('/api/clients/status')
        .then(response => response.json())
        .then(data => {
            // ... (código existente para popular clientSelect e qrClientSelect) ...

            // Limpa o estado global dos clientes antes de preencher
            for (const key in clientsState) {
                delete clientsState[key];
            }

            data.forEach(clientInfo => {
                clientsState[clientInfo.id] = clientInfo;

                const qrOption = document.createElement('option');
                qrOption.value = clientInfo.id;
                qrOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name}) - [${clientInfo.status}]`;
                qrClientSelect.appendChild(qrOption);

                const sendOption = document.createElement('option');
                sendOption.value = clientInfo.id;
                sendOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name})`;
                sendOption.disabled = (clientInfo.status !== 'Pronto');
                clientSelect.appendChild(sendOption);
            });

            if (data.length > 0) {
                currentSelectedQrClientId = data[0].id;
                qrClientSelect.value = currentSelectedQrClientId;
                updateQrDisplayCard(clientsState[currentSelectedQrClientId]);
            } else {
                updateQrDisplayCard(null);
            }
        })
        .catch(error => {
            console.error('Erro ao carregar status inicial dos clientes:', error);
            qrDisplayCard.innerHTML = '<p class="status-message error">Erro ao carregar status dos clientes. Verifique o servidor.</p>';
        });

    // --- Requisição para obter o NUM_CLIENTS atual do servidor ---
    fetch('/api/get-num-clients')
        .then(response => response.json())
        .then(data => {
            if (data.numClients !== undefined) {
                numClientsSelect.value = data.numClients;
                // **MUDANÇA AQUI:** Define a mensagem inicial com o valor lido do servidor e indica sucesso
                clientConfigStatusDiv.textContent = `O servidor foi reiniciado com sucesso! Número de Clientes atual: ${data.numClients}`;
                clientConfigStatusDiv.className = 'status-message success';
            }
        })
        .catch(error => {
            console.error('Erro ao carregar NUM_CLIENTS atual:', error);
            clientConfigStatusDiv.textContent = 'Não foi possível carregar a configuração atual de clientes.';
            clientConfigStatusDiv.className = 'status-message error';
        });

    socket.emit('requestRoutineStatus');
    socket.emit('requestReadyClients');
});