document.addEventListener('DOMContentLoaded', () => {
    const socket = io();

    // Elementos do Formulário de Mensagem (já existentes)
    const clientSelect = document.getElementById('client-select'); // Para o envio de mensagens
    const sendMessageForm = document.getElementById('send-message-form');
    const sendMessageStatusDiv = document.getElementById('send-message-status');

    // NOVOS Elementos para o Card de QR Code Individual
    const qrClientSelect = document.getElementById('qr-client-select'); // Novo dropdown para seleção do QR Code
    const qrDisplayCard = document.getElementById('qr-display-card'); // O único card para exibir o QR/status

    // Armazena o estado completo de todos os clientes no front-end
    const clientsState = {}; 
    let currentSelectedQrClientId = null; // Para saber qual cliente está sendo exibido no card QR

    /**
     * Atualiza o card de exibição do QR Code/Status.
     * Esta função será chamada sempre que o status de um cliente mudar OU
     * quando um novo cliente for selecionado no dropdown `qrClientSelect`.
     * @param {object} clientInfo Informações do cliente a serem exibidas.
     */
    function updateQrDisplayCard(clientInfo) {
        if (!clientInfo) {
            qrDisplayCard.innerHTML = '<p>Selecione um cliente acima para ver seu status e QR Code.</p>';
            return;
        }

        const showAuthButton = ['QR_CODE', 'Desconectado', 'Falha na Autenticação', 'Erro de Inicialização', 'Erro ao Reautenticar', 'Erro de Comunicação'].includes(clientInfo.status);
        const buttonText = clientInfo.status === 'QR_CODE' ? 'Autenticar' : 'Reautenticar';

        qrDisplayCard.innerHTML = `
            <h3>Cliente ${clientInfo.id} (${clientInfo.name})</h3>
            <p>Status: <span class="status-${clientInfo.status.toLowerCase().replace(/ /g, '-')}">${clientInfo.status}</span></p>
            <p>Sessão: <code>${clientInfo.sessionDir || 'N/A'}</code></p>
            <div class="qr-code-area">
                ${clientInfo.status === 'QR_CODE' && clientInfo.qr
                    ? `<img src="https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(clientInfo.qr)}" alt="QR Code para Cliente ${clientInfo.id}">`
                    : (clientInfo.status === 'QR_CODE' && !clientInfo.qr
                        ? '<p>Aguardando QR Code...</p>'
                        : ''
                    )
                }
            </div>
            ${showAuthButton 
                ? `<button class="auth-button" data-client-id="${clientInfo.id}">${buttonText}</button>`
                : ''
            }
        `;

        // Adiciona o event listener ao botão de autenticação/reautenticação no card único
        if (showAuthButton) {
            const authButton = qrDisplayCard.querySelector('.auth-button');
            if (authButton) {
                authButton.addEventListener('click', () => {
                    handleReauthenticate(clientInfo.id);
                });
            }
        }
    }

    /**
     * Lida com o clique no botão de reautenticação.
     * @param {number} clientId O ID do cliente a ser reautenticado.
     */
    async function handleReauthenticate(clientId) {
        // Atualiza o estado visualmente para "Reautenticando" no card exibido
        const currentClientInfo = clientsState[clientId];
        if (currentClientInfo) {
            updateQrDisplayCard({ ...currentClientInfo, status: 'Reautenticando', qr: null });
        }

        try {
            const response = await fetch('/api/reauthenticate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ clientId: clientId }),
            });

            const result = await response.json();

            if (result.success) {
                console.log(result.message);
                // O status real será atualizado pelo Socket.IO
            } else {
                console.error(`Erro ao reautenticar cliente ${clientId}:`, result.message);
                if (currentClientInfo) {
                    updateQrDisplayCard({ ...currentClientInfo, status: 'Erro ao Reautenticar', qr: null });
                }
                alert(`Erro ao reautenticar Cliente ${clientId}: ${result.message}`);
            }
        } catch (error) {
            console.error(`Erro na requisição de reautenticação para o cliente ${clientId}:`, error);
            if (currentClientInfo) {
                updateQrDisplayCard({ ...currentClientInfo, status: 'Erro de Comunicação', qr: null });
            }
            alert(`Erro de comunicação ao tentar reautenticar Cliente ${clientId}. Verifique o console do navegador e do servidor.`);
        }
    }

    // --- Socket.IO Event Listeners ---

    // Recebe o status inicial de todos os clientes ao conectar
    socket.on('initialClientStatus', (initialData) => {
        // Limpa e popula os dropdowns e o estado interno
        qrClientSelect.innerHTML = '<option value="">Selecione um cliente</option>';
        clientSelect.innerHTML = '<option value="">Selecione um cliente pronto</option>';
        
        initialData.forEach(clientInfo => {
            clientsState[clientInfo.id] = clientInfo; // Armazena o estado completo
            
            // Popula o dropdown de seleção de QR Code
            const qrOption = document.createElement('option');
            qrOption.value = clientInfo.id;
            qrOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name}) - [${clientInfo.status}]`;
            qrClientSelect.appendChild(qrOption);

            // Popula o dropdown de envio de mensagens (apenas prontos)
            const sendOption = document.createElement('option');
            sendOption.value = clientInfo.id;
            sendOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name})`;
            sendOption.disabled = (clientInfo.status !== 'Pronto');
            clientSelect.appendChild(sendOption);
        });

        // Tenta pré-selecionar o primeiro cliente ou o cliente ativo no card de QR
        if (initialData.length > 0) {
            currentSelectedQrClientId = initialData[0].id; // Seleciona o primeiro por padrão
            qrClientSelect.value = currentSelectedQrClientId;
            updateQrDisplayCard(clientsState[currentSelectedQrClientId]);
        } else {
            updateQrDisplayCard(null); // Nenhum cliente disponível
        }
    });

    // Recebe atualizações de status de clientes individuais
    socket.on('clientStatusUpdate', (updatedClientInfo) => {
        clientsState[updatedClientInfo.id] = updatedClientInfo; // Atualiza o estado completo

        // Atualiza a opção no dropdown de seleção de QR Code
        let qrOption = qrClientSelect.querySelector(`option[value="${updatedClientInfo.id}"]`);
        if (!qrOption) {
            qrOption = document.createElement('option');
            qrOption.value = updatedClientInfo.id;
            qrClientSelect.appendChild(qrOption);
        }
        qrOption.textContent = `Cliente ${updatedClientInfo.id} (${updatedClientInfo.name}) - [${updatedClientInfo.status}]`;

        // Atualiza a opção no dropdown de envio de mensagens
        let sendOption = clientSelect.querySelector(`option[value="${updatedClientInfo.id}"]`);
        if (!sendOption) {
            sendOption = document.createElement('option');
            sendOption.value = updatedClientInfo.id;
            clientSelect.appendChild(sendOption);
        }
        sendOption.textContent = `Cliente ${updatedClientInfo.id} (${updatedClientInfo.name})`;
        sendOption.disabled = (updatedClientInfo.status !== 'Pronto');

        // Se o cliente atualizado é o que está sendo exibido no card de QR, atualize o card
        if (parseInt(currentSelectedQrClientId) === updatedClientInfo.id) {
            updateQrDisplayCard(updatedClientInfo);
        }
    });

    // --- Listener para o Dropdown de Seleção de QR Code ---
    qrClientSelect.addEventListener('change', (event) => {
        const selectedId = parseInt(event.target.value);
        currentSelectedQrClientId = selectedId;
        updateQrDisplayCard(clientsState[selectedId]); // Exibe o cliente selecionado no card QR
    });


    // --- Formulário de Envio de Mensagem ---
    sendMessageForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        sendMessageStatusDiv.textContent = 'Enviando mensagem...';
        sendMessageStatusDiv.className = 'status-message info';

        const formData = new FormData(sendMessageForm);
        const clientId = formData.get('clientId');
        const number = formData.get('number');
        const message = formData.get('message');

        if (!clientId || !number || !message) {
            sendMessageStatusDiv.textContent = 'Por favor, preencha todos os campos para enviar a mensagem.';
            sendMessageStatusDiv.className = 'status-message error';
            return;
        }

        try {
            const response = await fetch('/api/send-message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ clientId, number, message }),
            });

            const result = await response.json();

            if (result.success) {
                sendMessageStatusDiv.textContent = result.message;
                sendMessageStatusDiv.className = 'status-message success';
                sendMessageForm.reset();
            } else {
                sendMessageStatusDiv.textContent = `Erro: ${result.message}`;
                sendMessageStatusDiv.className = 'status-message error';
            }
        } catch (error) {
            console.error('Erro ao enviar mensagem:', error);
            sendMessageStatusDiv.textContent = `Erro ao conectar com o servidor: ${error.message}`;
            sendMessageStatusDiv.className = 'status-message error';
        }
    });

    // Requisição inicial para carregar o status dos clientes
    fetch('/api/clients/status')
        .then(response => response.json())
        .then(data => {
            // Só processa se o estado dos clientes ainda estiver vazio (evita duplicação se o socket já inicializou)
            if (Object.keys(clientsState).length === 0) { 
                qrClientSelect.innerHTML = '<option value="">Selecione um cliente</option>';
                clientSelect.innerHTML = '<option value="">Selecione um cliente pronto</option>';
                data.forEach(clientInfo => {
                    clientsState[clientInfo.id] = clientInfo;
                    
                    const qrOption = document.createElement('option');
                    qrOption.value = clientInfo.id;
                    qrOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name}) - [${clientInfo.status}]`;
                    qrClientSelect.appendChild(qrOption);

                    const sendOption = document.createElement('option');
                    sendOption.value = clientInfo.id;
                    sendOption.textContent = `Cliente ${clientInfo.id} (${clientInfo.name})`;
                    sendOption.disabled = (clientInfo.status !== 'Pronto');
                    clientSelect.appendChild(sendOption);
                });

                if (data.length > 0) {
                    currentSelectedQrClientId = data[0].id;
                    qrClientSelect.value = currentSelectedQrClientId;
                    updateQrDisplayCard(clientsState[currentSelectedQrClientId]);
                } else {
                    updateQrDisplayCard(null);
                }
            }
        })
        .catch(error => {
            console.error('Erro ao carregar status inicial dos clientes:', error);
            qrDisplayCard.innerHTML = '<p class="status-message error">Erro ao carregar status dos clientes. Verifique o servidor.</p>';
        });
});