const socket = io();

let currentClients = [];
let frontendRoutineLogs = [];
let selectedClientId = null; // Armazena o ID do cliente selecionado para a rotina

// --- Funções de Atualização da UI ---

function displayClients(clientsData) {
    const clientsContainer = document.getElementById('clients-container');
    clientsContainer.innerHTML = ''; // Limpa antes de adicionar

    clientsData.sort((a, b) => parseInt(a.id) - parseInt(b.id)); // Ordena por ID

    clientsData.forEach(client => {
        const clientCard = document.createElement('div');
        clientCard.className = 'client-card';
        clientCard.id = `client-${client.id}`;

        let statusText = client.status;
        let qrCodeDisplay = ''; // Inicializa vazio
        let qrCodeError = ''; // Para exibir mensagens de erro do QR no UI

        // **AJUSTE CRÍTICO AQUI:** Adiciona validação e feedback visual
        if (client.status === 'QR_CODE') {
            // Valida se client.qr existe, é uma string e começa com o prefixo base64 correto
            if (client.qr && typeof client.qr === 'string' && client.qr.startsWith('data:image/png;base64,')) {
                // Adiciona um manipulador de erro para a imagem
                qrCodeDisplay = `<img src="${client.qr}" alt="QR Code para Cliente ${client.id}" class="qr-code-img" onerror="this.onerror=null;this.src=''; console.error('Erro ao carregar QR Code para Cliente ${client.id}'); this.alt='Falha ao carregar QR Code';">`;
                console.log(`[FRONTEND DEBUG] QR Code para Cliente ${client.id} é válido e será exibido. Tamanho da string: ${client.qr.length}`);
            } else {
                qrCodeError = '<p style="color: red; font-size: 0.9em; margin-top: 5px;">Erro: QR Code inválido ou ausente.</p>';
                console.error(`[FRONTEND ERROR] QR Code inválido/ausente para Cliente ${client.id}. Tipo: ${typeof client.qr}, Valor:`, client.qr);
            }
            statusText = 'Escaneie o QR Code';
        } else if (client.status === 'Pronto') {
            statusText = 'Pronto';
        } else if (client.status === 'Desconectado' || client.status === 'Falha na Autenticação' || client.status === 'Erro') {
            statusText = 'Desconectado / Erro';
        }

        const phoneNumberDisplay = client.phoneNumber && client.phoneNumber !== 'N/A' ? `(${client.phoneNumber})` : '';

        clientCard.innerHTML = `
            <h4>Cliente ${client.id}</h4>
            <p>Status: <span class="status-${client.status.toLowerCase().replace(/ /g, '-') || 'unknown'}">${statusText} ${phoneNumberDisplay}</span></p>
            ${qrCodeDisplay} ${qrCodeError} <button class="reauth-btn" data-client-id="${client.id}" ${client.status === 'Pronto' ? 'disabled' : ''}>Reautenticar</button>
            <button class="remove-btn" data-client-id="${client.id}">Remover Cliente</button>
        `;
        clientsContainer.appendChild(clientCard);
    });

    // CRÍTICO: Reanexar listeners após (re)criação dos elementos
    attachClientButtonListeners();
    currentClients = clientsData; // Atualiza a lista de clientes atual no frontend
}

// Função para anexar/reanexar listeners aos botões de cliente
function attachClientButtonListeners() {
    document.querySelectorAll('.reauth-btn').forEach(button => {
        // Remover listener anterior para evitar duplicação (boa prática)
        button.removeEventListener('click', handleReauthenticateClick);
        button.addEventListener('click', handleReauthenticateClick);
    });

    document.querySelectorAll('.remove-btn').forEach(button => {
        // Remover listener anterior para evitar duplicação
        button.removeEventListener('click', handleRemoveClientClick);
        button.addEventListener('click', handleRemoveClientClick);
    });
}

// Funções de tratamento de clique separadas para reuso e remoção de listeners
async function handleReauthenticateClick(e) {
    const clientId = parseInt(e.target.dataset.clientId);
    if (confirm(`Tem certeza que deseja reautenticar o Cliente ${clientId}? Isso desconectará a sessão atual.`)) {
        try {
            const response = await fetch('/api/reauthenticate', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ clientId })
            });
            const data = await response.json();
            if (!data.success) {
                alert('Erro ao reautenticar: ' + data.message);
            }
            // Não precisa recarregar a página, o socket já fará a atualização.
        } catch (error) {
            console.error('Erro de rede ao reautenticar:', error);
            alert('Erro de comunicação com o servidor ao reautenticar.');
        }
    }
}

async function handleRemoveClientClick(e) {
    const clientId = parseInt(e.target.dataset.clientId);
    if (confirm(`Tem certeza que deseja remover o Cliente ${clientId} e seus dados de sessão?`)) {
        try {
            // Calcula o número de clientes que restarão
            const remainingClients = currentClients.filter(c => c.id !== clientId);
            const newNumClients = remainingClients.length;

            const response = await fetch(`/api/set-num-clients`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ numClients: newNumClients })
            });
            const data = await response.json();
            if (!data.success) {
                alert('Erro ao remover cliente: ' + data.message);
            }
            // O socket 'clientStatusUpdate' com 'Removido' e a atualização de 'initialClientStatus'
            // já irão refletir a mudança, então não precisa de recarregamento manual da página.
        } catch (error) {
            console.error('Erro de rede ao remover cliente:', error);
            alert('Erro de comunicação com o servidor ao remover cliente.');
        }
    }
}

function updateReadyClientsDropdown(readyClients) {
    const clientSelect = document.getElementById('selected-client-id');
    const previousSelectedValue = clientSelect.value; // Mantém o valor selecionado, se possível

    clientSelect.innerHTML = '<option value="">Automático (alternar entre prontos)</option>';

    readyClients.sort((a, b) => parseInt(a.id) - parseInt(b.id)); // Ordena por ID para consistência

    readyClients.forEach(client => {
        const option = document.createElement('option');
        option.value = client.id;
        option.textContent = `Cliente ${client.id} (${client.phoneNumber}) - Pronto`;
        clientSelect.appendChild(option);
    });

    // Tenta re-selecionar o cliente que estava selecionado, se ainda estiver pronto
    if (selectedClientId && readyClients.some(c => String(c.id) === String(selectedClientId))) {
        clientSelect.value = String(selectedClientId);
    } else if (readyClients.some(c => String(c.id) === previousSelectedValue)) {
        clientSelect.value = previousSelectedValue;
    } else {
        clientSelect.value = ""; // Volta para 'Automático' se o cliente não estiver mais pronto
    }
}

function updateRoutineUI(status) {
    if (!status) return;

    document.getElementById('routine-status-display').textContent = status.isRunning ? 'Em Andamento' : 'Inativa';
    document.getElementById('routine-progress-display').textContent = `${status.currentIndex}/${status.totalContacts}`;
    document.getElementById('routine-success-display').textContent = status.successCount;
    document.getElementById('routine-fail-display').textContent = status.failCount;

    const startButton = document.getElementById('start-routine-btn');
    const stopButton = document.getElementById('stop-routine-btn');

    // Elementos do formulário da rotina que devem ser desabilitados/habilitados
    const contactsInput = document.getElementById('contacts-input');
    const messagesInput = document.getElementById('messages-input');
    const minDelayInput = document.getElementById('min-delay');
    const maxDelayInput = document.getElementById('max-delay');
    const selectedClientDropdown = document.getElementById('selected-client-id');
    const setNumClientsBtn = document.getElementById('set-num-clients-btn');
    const numClientsInput = document.getElementById('num-clients-input');

    const elementsToDisable = [
        contactsInput, messagesInput, minDelayInput, maxDelayInput,
        selectedClientDropdown, setNumClientsBtn, numClientsInput
    ];

    if (status.isRunning) {
        startButton.disabled = true;
        stopButton.disabled = false;

        elementsToDisable.forEach(el => {
            if (el) el.disabled = true; // Desabilita todos os campos de configuração da rotina
        });

        // Atualiza os campos de input com os valores da rotina em andamento (somente se diferentes)
        const newContactsValue = status.contactsList.map(c => `${c.nome}:${c.numero}`).join('\n');
        if (contactsInput.value !== newContactsValue) {
             contactsInput.value = newContactsValue;
        }

        const newMessagesValue = status.messagesList.join('\n');
        if (messagesInput.value !== newMessagesValue) {
            messagesInput.value = newMessagesValue;
        }

        // Atualiza os delays (convertendo de ms para segundos)
        if (minDelayInput.value !== String(status.minDelay / 1000)) {
            minDelayInput.value = status.minDelay / 1000;
        }
        if (maxDelayInput.value !== String(status.maxDelay / 1000)) {
            maxDelayInput.value = maxDelayInput.value = status.maxDelay / 1000;
        }

        // Mantém o cliente selecionado no dropdown, se houver
        selectedClientId = status.selectedClientId;
        if (selectedClientId && selectedClientDropdown.value !== String(selectedClientId)) {
            selectedClientDropdown.value = String(selectedClientId);
        } else if (!selectedClientId && selectedClientDropdown.value !== "") {
            selectedClientDropdown.value = "";
        }

    } else { // Rotina Inativa
        startButton.disabled = false;
        stopButton.disabled = true;

        elementsToDisable.forEach(el => {
            if (el) el.disabled = false; // Habilita os campos de configuração da rotina
        });
        
        // Limpa a seleção do cliente após a rotina terminar
        selectedClientId = null;
    }
}

function addRoutineLogToUI(logEntry) {
    const logContainer = document.getElementById('routine-log-output');
    const logElement = document.createElement('p');
    logElement.classList.add(`log-${logEntry.type}`);
    logElement.textContent = `[${logEntry.timestamp}] ${logEntry.message}`;
    logContainer.appendChild(logElement);
    // Rola para o final para mostrar o log mais recente
    logContainer.scrollTop = logContainer.scrollHeight;

    frontendRoutineLogs.push(logEntry); // Guarda os logs no frontend também
}

// --- Eventos Socket.IO ---

socket.on('connect', () => {
    console.log('[FRONTEND - SOCKET.IO] Conectado ao servidor.');
    // Ao reconectar, solicita o estado atual para sincronizar a UI
    socket.emit('requestInitialClientStatus');
    socket.emit('requestRoutineStatus');
    socket.emit('requestReadyClients');
});

socket.on('disconnect', () => {
    console.log('[FRONTEND - SOCKET.IO] Desconectado do servidor.');
});

socket.on('initialClientStatus', (clientsData) => {
    console.log('[FRONTEND - SOCKET.IO] Initial Client Status Recebido:', clientsData);
    displayClients(clientsData); // Re-renderiza e reanexa listeners
});

socket.on('clientStatusUpdate', (clientData) => {
    console.log('[FRONTEND - SOCKET.IO] Client Status Update Recebido:', clientData);
    const existingClientIndex = currentClients.findIndex(c => c.id === clientData.id);
    if (existingClientIndex > -1) {
        // Atualiza dados do cliente existente
        currentClients[existingClientIndex] = clientData;
    } else {
        // Adiciona novo cliente
        currentClients.push(clientData);
    }
    displayClients(currentClients); // Re-renderiza e reanexa listeners
});

socket.on('readyClientsForRoutine', (readyClients) => {
    console.log('[FRONTEND - SOCKET.IO] Ready Clients for Routine Recebido:', readyClients);
    updateReadyClientsDropdown(readyClients);
});

socket.on('routineStatus', (status) => {
    console.log('[FRONTEND - SOCKET.IO] Rotina Status Recebido:', status);
    updateRoutineUI(status);
    // Limpa logs anteriores e os reinicia a cada `routineStatus` completo
    // Isso evita duplicidade em re-conexões ou re-inicializações da rotina
    document.getElementById('routine-log-output').innerHTML = '';
    frontendRoutineLogs = [];
});

socket.on('routineLogUpdate', (logEntry) => {
    addRoutineLogToUI(logEntry);
});

// --- Listeners de Botões/Inputs Principais (Permanecem aqui) ---

document.getElementById('set-num-clients-btn').addEventListener('click', async () => {
    const numClients = parseInt(document.getElementById('num-clients-input').value);
    if (isNaN(numClients) || numClients < 1 || numClients > 10) {
        alert('Por favor, insira um número válido de clientes (1 a 10).');
        return;
    }
    try {
        const response = await fetch('/api/set-num-clients', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ numClients })
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao definir clientes: ' + (data.message || 'Erro desconhecido.'));
        }
    } catch (error) {
        console.error('Erro ao comunicar com o backend para definir clientes:', error);
        alert('Erro de comunicação com o servidor ao definir clientes.');
    }
});

document.getElementById('start-routine-btn').addEventListener('click', async () => {
    const contactsInput = document.getElementById('contacts-input');
    const messagesInput = document.getElementById('messages-input');
    const minDelayInput = document.getElementById('min-delay');
    const maxDelayInput = document.getElementById('max-delay');
    const selectedClientDropdown = document.getElementById('selected-client-id');

    const contactsText = contactsInput.value;
    const messagesText = messagesInput.value;
    // Converte segundos para milissegundos
    const minDelay = parseInt(minDelayInput.value * 1000);
    const maxDelay = parseInt(maxDelayInput.value * 1000);
    const selectedClientIdRaw = selectedClientDropdown.value;
    const selectedClientId = selectedClientIdRaw ? parseInt(selectedClientIdRaw) : null;


    if (!contactsText || !messagesText) {
        alert('Por favor, preencha os contatos e as mensagens.');
        return;
    }

    if (isNaN(minDelay) || isNaN(maxDelay) || minDelay < 1000 || maxDelay < 1000 || minDelay > maxDelay) {
        alert('Por favor, insira um atraso mínimo e máximo válidos (em segundos, mínimo 1). O atraso mínimo deve ser menor ou igual ao máximo.');
        return;
    }

    // Processa a lista de contatos (Nome:Número)
    const contacts = contactsText.split('\n').map(line => {
        const parts = line.split(':');
        if (parts.length >= 2) {
            return { nome: parts[0].trim(), numero: parts[1].trim() };
        }
        return null; // Retorna null para linhas mal formatadas
    }).filter(c => c !== null && c.nome && c.numero); // Filtra linhas nulas e incompletas

    // Processa a lista de mensagens
    const messages = messagesText.split('\n').map(msg => msg.trim()).filter(msg => msg !== '');

    if (contacts.length === 0 || messages.length === 0) {
        alert('As listas de contatos ou mensagens estão vazias ou mal formatadas.');
        return;
    }

    try {
        const response = await fetch('/api/routine/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ contacts, messages, selectedClientId, minDelay, maxDelay })
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao iniciar rotina: ' + (data.message || 'Erro desconhecido.'));
        }
    } catch (error) {
        console.error('Erro ao comunicar com o backend para iniciar rotina:', error);
        alert('Erro ao iniciar rotina. Verifique o console do servidor.');
    }
});

document.getElementById('stop-routine-btn').addEventListener('click', async () => {
    try {
        const response = await fetch('/api/routine/stop', {
            method: 'POST'
        });
        const data = await response.json();
        if (!data.success) {
            alert('Erro ao parar rotina: ' + (data.message || 'Erro desconhecido.'));
        }
    } catch (error) {
        console.error('Erro ao comunicar com o backend para parar rotina:', error);
        alert('Erro ao parar rotina. Verifique o console do servidor.');
    }
});

// --- Inicialização ao carregar a página ---
document.addEventListener('DOMContentLoaded', () => {
    // Ao carregar a página, tenta obter o número atual de clientes do backend
    fetch('/api/get-num-clients')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                document.getElementById('num-clients-input').value = data.numClients;
            }
        })
        .catch(error => console.error('Erro ao obter número de clientes:', error));

    // Garante que os listeners dos botões de cliente sejam anexados logo no início também
    // (Mesmo que não haja clientes, eles estarão prontos para quando aparecerem)
    attachClientButtonListeners();
});